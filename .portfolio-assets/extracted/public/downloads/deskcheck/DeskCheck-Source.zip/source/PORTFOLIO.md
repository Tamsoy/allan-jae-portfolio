# DeskCheck — PC Diagnostics & Support Reports

**Category:** Personal project / Side Quest  
**Creator:** Allan Jae Eparwa  
**Version:** 1.0.0  
**Platform:** Windows 11 x64  
**Development workflow:** AI-assisted

DeskCheck is an installable Windows utility that turns routine PC information gathering into a clear support report. It checks Windows and processor details, memory availability, fixed local disk space, and network adapter configuration, with optional DNS, ping, and TCP tests for a chosen destination.

Findings include an explicit status, a plain-language explanation, and a practical next step. Users can preview, copy, or export TXT and static HTML reports. Device and network identifiers are omitted from exports by default.

I created DeskCheck to explore an everyday IT support problem: collecting useful troubleshooting context without requiring users to copy information from several Windows tools. My contribution included defining the workflow, directing AI-assisted implementation, and evaluating the diagnostic and reporting experience.

The project uses C#, WPF/XAML, .NET Framework 4.8, native Windows APIs, managed networking, and a per-user installer. It runs without an account, API key, or backend service. Its scope is information gathering and explanation; it does not automatically repair or certify the health of a computer.

The development audit recorded 219 passing automated assertions across engine behavior, inputs, exports, layout simulations, installation, and HTML rendering, plus hands-on installed-app checks. This is validation on the development PC, not universal device certification. The current download is unsigned.

**Portfolio card:** A Windows diagnostic utility that checks system details, memory, storage, and connectivity, then generates a support report with clear next steps and identifiers omitted by default.

Suggested case study assets: screenshot of the Overview tab, sample redacted report, installer, portable ZIP, source ZIP, PROJECT-FLOW.md, and AUDIT.md. Use sample screenshots labeled as examples; do not claim real customers, measured time savings, or broad compatibility without evidence.
