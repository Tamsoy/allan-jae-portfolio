# DeskCheck UI/UX update

This update applies a minimal glassmorphism direction to DeskCheck while preserving the existing diagnostic workflow and permissions.

## Design direction

- A dark graphite canvas (#0B1120) establishes a quiet diagnostic workspace.
- Translucent navy cards and fine blue-gray borders create the glass surfaces without heavy shadows or decorative gradients.
- Mint is reserved for the primary Run action and positive/ready states. Amber is reserved for attention/error copy.
- The page uses one strong headline, one primary action, and a short status line before the detailed tabs.
- The layout remains native WPF so keyboard focus, access keys, live status text, and normal Windows scaling continue to work.

## 21st.dev inspiration

The 21st.dev inspiration search was used for the “Glassmorphism Minimal Metrics” direction (58% match) and its focused metric/card hierarchy. The catalog component itself targets React/shadcn and was not pasted into this WPF project. Its useful visual idea was adapted into native WPF glass cards, a readiness badge, and clearer action/status grouping.

## UX changes

- Run controls are grouped inside a single glass action surface with read-only and permissions context beside the action.
- Snapshot status is elevated into a dedicated tinted summary surface.
- Report, overview, system, storage, network, and about sections retain their original names and keyboard navigation.
- Text contrast, focusable native controls, wrapped copy, vertical scrolling, and disabled/loading states remain explicit.
- The redesigned surface was checked at 480, 768, 1140, and 1440 pixel widths and at 100%, 150%, and 200% simulated content scale.

This is a visual and interaction refinement, not a change to the diagnostic collection scope or the app's local-only permission model.

## Logo v3

The enhanced logo adds a simplified monitor frame and stand behind the DC monogram. A mint pulse line and amber endpoint make the PC-diagnostic purpose visible without adding a literal computer illustration or extra text. The v3 mark is now embedded as a resolution-independent WPF vector in the native header, while the source mark and lockup remain available as SVG for app icons, portfolio cards, and documentation.
