using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DeskCheck {
    public static class UiAudit {
        public static int Run(string output) {
            output=Path.GetFullPath(output);Directory.CreateDirectory(output);var log=new AuditLog();var app=new Application { ShutdownMode=ShutdownMode.OnExplicitShutdown };
            app.Startup+=async delegate {
                Workspace ui=null;
                try {
                    ui=new Workspace();ui.Window.Show(); await Task.Delay(150);
                    log.Check("cold start renders window",ui.Window.IsVisible && ui.Get<Button>("RunButton").IsEnabled);
                    var theme=ui.Get<Button>("ThemeButton");
                    log.Check("theme toggle has an accessible name",new ButtonAutomationPeer(theme).GetName().Contains("light"));
                    theme.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); await Task.Delay(40);
                    var lightCanvas=(SolidColorBrush)ui.Window.Resources["Canvas"];
                    log.Check("light theme applies semantic tokens",lightCanvas.Color==Color.FromRgb(0xF3,0xF7,0xFA) && new ButtonAutomationPeer(theme).GetName().Contains("dark"));
                    log.Check("theme transition provides feedback",ui.Get<Border>("ThemeFlash").Opacity>0);
                    theme.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); await Task.Delay(40);
                    log.Check("dark theme restores semantic tokens",((SolidColorBrush)ui.Window.Resources["Canvas"]).Color==Color.FromRgb(0x0B,0x11,0x20));
                    log.Check("exports disabled before first scan",!ui.Get<Button>("SaveText").IsEnabled && !ui.Get<Button>("SaveHtml").IsEnabled && !ui.Get<Button>("CopyReport").IsEnabled);
                    log.Check("network probes default off",ui.Get<CheckBox>("ProbeToggle").IsChecked!=true && ui.Get<StackPanel>("ProbePanel").Visibility==Visibility.Collapsed);
                    Shot(ui,Path.Combine(output,"deskcheck-ready.png"));
                    ui.Get<CheckBox>("ProbeToggle").IsChecked=true; log.Check("probe toggle reveals labeled fields",ui.Get<StackPanel>("ProbePanel").Visibility==Visibility.Visible);
                    ui.Get<TextBox>("HostInput").Text="example.com;bad";await ui.StartScan();
                    log.Check("invalid input blocks scan and shows error",!ui.Busy && ui.Get<TextBlock>("InputError").Visibility==Visibility.Visible);
                    ui.Get<CheckBox>("ProbeToggle").IsChecked=false;
                    ui.ShowReport(SelfTest.Fixture());
                    var old=ui.Report;
                    Click(ui.Get<Button>("RunButton"));var pending=ui.CurrentRun;
                    log.Check("scan has loading state and duplicate protection",ui.Busy && !ui.Get<Button>("RunButton").IsEnabled && ui.Get<Button>("CancelButton").Visibility==Visibility.Visible);
                    await ui.StartScan();log.Check("second run does not replace active task",ui.CurrentRun==pending);
                    Click(ui.Get<Button>("CancelButton"));await pending;
                    log.Check("cancellation preserves prior snapshot",ui.Report==old && ui.Get<TextBlock>("RunStatus").Text.StartsWith("Scan cancelled"));
                    log.Check("controls recover after cancellation",!ui.Busy && ui.Get<Button>("RunButton").IsEnabled && ui.Get<Button>("SaveText").IsEnabled);
                    Click(ui.Get<Button>("RunButton"));await ui.CurrentRun;
                    log.Check("real scan completes from Run button",ui.Report!=null && ui.Report!=old && !ui.Busy && ui.Get<TextBlock>("RunStatus").Text.StartsWith("Snapshot complete"));
                    Shot(ui,Path.Combine(output,"deskcheck-live-overview.png"));
                    ui.ShowReport(SelfTest.Fixture());
                    ui.Get<TextBox>("NotesInput").Text="Sample screenshot — not a real device report.";
                    log.Check("notes update exact preview",ui.Get<TextBox>("Preview").Text.Contains("Sample screenshot"));
                    ui.Get<CheckBox>("IncludeIdentifiers").IsChecked=true;log.Check("identifier opt-in updates preview",ui.Get<TextBox>("Preview").Text.Contains("PRIVATE-PC-EXAMPLE"));
                    ui.Get<CheckBox>("IncludeIdentifiers").IsChecked=false;log.Check("identifier opt-out removes values",!ui.Get<TextBox>("Preview").Text.Contains("PRIVATE-PC-EXAMPLE"));
                    var preview=ui.Get<TextBox>("Preview").Text;
                    log.Check("report preview and exporter use same text",preview==Reports.Plain(ui.Report,false,ui.Get<TextBox>("NotesInput").Text));
                    log.Check("input fields expose accessible names",new TextBoxAutomationPeer(ui.Get<TextBox>("HostInput")).GetName()=="Hostname or IP" && new TextBoxAutomationPeer(ui.Get<TextBox>("NotesInput")).GetName()=="Issue notes");
                    log.Check("primary action has accessible name",new ButtonAutomationPeer(ui.Get<Button>("RunButton")).GetName().Contains("Run checks"));
                    var tabs=ui.Get<TabControl>("Tabs");
                    ui.Get<CheckBox>("ProbeToggle").IsChecked=true;
                    ui.Get<TextBox>("HostInput").Text="example.com";
                    foreach(int width in new[]{480,768,1100,1440}) {
                        ui.Window.Width=width;ui.Window.Height=800;
                        foreach(double scale in new[]{1d,1.5d,2d}) {
                            ui.Get<StackPanel>("RootContent").LayoutTransform=new ScaleTransform(scale,scale);
                            for(int i=0;i<tabs.Items.Count;i++) {
                                tabs.SelectedIndex=i;ui.Window.UpdateLayout();
                                var scroll=ui.Get<ScrollViewer>("OuterScroll");
                                bool fits=scale>1 || scroll.ExtentWidth<=scroll.ViewportWidth+2;
                                log.Check("tab "+((TabItem)tabs.Items[i]).Header+" fits "+width+" / scale "+scale,fits);
                            }
                            if(width==480 && scale==2) Shot(ui,Path.Combine(output,"deskcheck-extreme-scale-sample.png"));
                        }
                    }
                    ui.Get<CheckBox>("ProbeToggle").IsChecked=false;
                    ui.Get<StackPanel>("RootContent").LayoutTransform=Transform.Identity;
                    ui.Window.Width=1100;ui.Window.Height=820;
                    for(int i=0;i<tabs.Items.Count;i++) {
                        tabs.SelectedIndex=i;ui.Window.UpdateLayout();ui.Get<ScrollViewer>("OuterScroll").ScrollToVerticalOffset(i==0?0:380);await Task.Delay(40);ui.Window.UpdateLayout();
                        Shot(ui,Path.Combine(output,"deskcheck-"+((TabItem)tabs.Items[i]).Header.ToString().ToLowerInvariant()+"-sample.png"));
                    }
                    ui.Window.Width=480;ui.Window.Height=740;tabs.SelectedIndex=4;ui.Window.UpdateLayout();ui.Get<ScrollViewer>("OuterScroll").ScrollToVerticalOffset(480);await Task.Delay(50);Shot(ui,Path.Combine(output,"deskcheck-narrow-sample.png"));
                    // Avoid modifying the user's clipboard in this audit. Native copy action is checked separately.
                    log.Check("copy action wired and enabled",ui.Get<Button>("CopyReport").IsEnabled);
                    ui.Get<TextBox>("NotesInput").Text=new string('x',2000);ui.UpdatePreview();log.Check("maximum length notes render",ui.Get<TextBox>("Preview").Text.Contains(new string('x',2000)));
                    var task=ui.StartScan();ui.Window.Close();await task;
                    log.Check("closing during scan cancels worker",!ui.Busy);
                } catch(Exception e) { log.Check("UI audit exception: "+e.ToString(),false); }
                finally { if(ui!=null && ui.Window.IsVisible) ui.Window.Close();log.Finish(Path.Combine(output,"ui-results.txt"));app.Shutdown(log.Failed==0?0:1); }
            };
            return app.Run();
        }
        static void Click(Button button) { button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); }
                static bool ControlsFit(FrameworkElement root) {
                    return Descendants(root).OfType<FrameworkElement>().Where(x=>x.IsVisible && (x is TextBox || x is Button || x is TextBlock || x is CheckBox || x is Label || x is TabItem)).All(x=>{
                        var bounds=x.TransformToAncestor(root).TransformBounds(new Rect(0,0,x.ActualWidth,x.ActualHeight));
                        if(bounds.Left < -2 || bounds.Right > root.ActualWidth+2) { System.Diagnostics.Debug.WriteLine(x.GetType().Name+" "+bounds.Left+" "+bounds.Right+" root "+root.ActualWidth); }
                        return bounds.Left>=-2 && bounds.Right<=root.ActualWidth+2;
            });
        }
        static System.Collections.Generic.IEnumerable<DependencyObject> Descendants(DependencyObject root) {
            for(int i=0;i<VisualTreeHelper.GetChildrenCount(root);i++) { var child=VisualTreeHelper.GetChild(root,i);yield return child;foreach(var nested in Descendants(child)) yield return nested; }
        }
        static void Shot(Workspace ui,string path) {
            ui.Window.UpdateLayout();
            var content=(FrameworkElement)ui.Window.Content;
            var bitmap=new RenderTargetBitmap((int)Math.Ceiling(content.ActualWidth),(int)Math.Ceiling(content.ActualHeight),96,96,PixelFormats.Pbgra32);bitmap.Render(content);
            var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));using(var stream=File.Create(path)) encoder.Save(stream);
        }
    }
}
