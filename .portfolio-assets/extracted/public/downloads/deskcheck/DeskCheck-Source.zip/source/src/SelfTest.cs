using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace DeskCheck {
    public sealed class AuditLog {
        public readonly List<string> Lines=new List<string>();
        public int Passed,Failed;
        public void Check(string name,bool condition) { if(condition) { Passed++; Lines.Add("PASS: "+name); } else { Failed++; Lines.Add("FAIL: "+name); } }
        public void Test(string name,Action action) { try { action(); Check(name,true); } catch(Exception e) { Failed++;Lines.Add("FAIL: "+name+" — "+e.GetType().Name+": "+e.Message); } }
        public void Finish(string path) { Lines.Add("RESULT: "+Passed+" passed; "+Failed+" failed.");File.WriteAllLines(path,Lines); }
    }
    public static class SelfTest {
        static void Require(bool b) { if(!b) throw new Exception("Assertion failed"); }
        static void Throws<T>(Action f) where T:Exception { try { f(); } catch(T) { return; } throw new Exception("Expected "+typeof(T).Name); }
        public static ScanReport Fixture() {
            var r=new ScanReport { CollectedUtc="2026-09-14T10:20:00.0000000Z",NetworkTests=false };
            r.Fact("System","Computer name","PRIVATE-PC-EXAMPLE",true);
            r.Fact("System","Windows","Windows 11 Pro (sample)");r.Fact("System","Processor","Sample 8-core processor");r.Fact("System","Physical memory","16.0 GiB");
            r.Findings.Add(Rules.Memory(16UL<<30,8UL<<30));r.Findings.Add(Rules.Disk("C:\\",500UL<<30,25UL<<30));
            r.Fact("Network","Adapter 1 name","PRIVATE-ADAPTER",true);r.Fact("Network","Adapter 1 addresses","192.0.2.10",true);r.Fact("Network","Probe destination","private.example",true);
            r.Fact("Network","Adapter 1 state","Ethernet / Up");
            r.Check("Network","Adapter connection","Pass","One adapter reports an active link.","Use optional probes to investigate a destination.");
            r.Check("Network","Connectivity probes","Info","Not requested in this sample.","Enable the option before running a check.");return r;
        }
        public static int Run(string output) {
            output=Path.GetFullPath(output);Directory.CreateDirectory(output);var log=new AuditLog();
            foreach(string host in new[]{"example.com","LOCALHOST","a-b.example","127.0.0.1","192.168.1.1","::1","2001:db8::1","  example.com  "}) {
                Target t;string error;log.Check("accept host "+host,Target.TryParse(host,"443",out t,out error));
            }
            foreach(string host in new[]{""," ","https://example.com","example.com/path","example.com:443","a;calc.exe","x & whoami","$(whoami)","a\nb","a b","a..b","-a.com","a-.com","999.0.0.1","127.1","0127.0.0.1","1234","[::1]","fe80::1%12","<script>","日本語.example",new string('a',64)+".com",new string('a',254)}) {
                Target t;string error;log.Check("reject malformed host "+Text.Safe(host,35).Replace("\n","\\n"),!Target.TryParse(host,"443",out t,out error));
            }
            foreach(string port in new[]{"0","65536","-1","1.5","1e2","+80","443;exit","","   ","123456"}) { Target t;string e;log.Check("reject port "+port,!Target.TryParse("example.com",port,out t,out e)); }
            foreach(string port in new[]{"1","65535","443"," 80 "}) { Target t;string e;log.Check("accept port "+port,Target.TryParse("example.com",port,out t,out e)); }
            log.Check("disk under 10% warns",Rules.Disk("C",100UL<<30,9UL<<30).Status=="Attention");
            log.Check("disk under 5 GiB warns despite percentage",Rules.Disk("C",10UL<<30,4UL<<30).Status=="Attention");
            log.Check("disk threshold equality passes",Rules.Disk("C",50UL<<30,5UL<<30).Status=="Pass");
            log.Check("zero disk capacity is unknown",Rules.Disk("C",0,0).Status=="Unknown");
            log.Check("impossible disk capacity is unknown",Rules.Disk("C",1,2).Status=="Unknown");
            log.Check("large disk capacity does not overflow",Rules.Disk("C",UInt64.MaxValue,UInt64.MaxValue/2).Status=="Pass");
            log.Check("90% memory warns",Rules.Memory(100,10).Status=="Attention");
            log.Check("below memory threshold passes",Rules.Memory(100,11).Status=="Pass");
            log.Check("zero memory is unknown",Rules.Memory(0,0).Status=="Unknown");
            log.Check("impossible available memory is unknown",Rules.Memory(100,101).Status=="Unknown");
            log.Check("no active adapters produces actionable attention",Rules.Adapter(0).Status=="Attention");
            log.Check("multiple active adapters do not imply Internet success",Rules.Adapter(3).Status=="Pass" && Rules.Adapter(3).Detail.Contains("does not prove Internet"));
            log.Test("permission failure becomes Unknown",()=>{var r=Fixture();Diagnostics.Section(r,"Storage",()=>{throw new UnauthorizedAccessException("private path");});Require(r.Findings.Last().Status=="Unknown" && !Reports.Plain(r,false,"").Contains("private path"));});
            log.Test("device failure becomes Unknown",()=>{var r=Fixture();Diagnostics.Section(r,"System",()=>{throw new IOException("private device");});Require(r.Findings.Last().Status=="Unknown");});
            var fixture=Fixture();string plain=Reports.Plain(fixture,false,"");
            log.Check("default report omits device and network identifiers",!new[]{"PRIVATE-PC","PRIVATE-ADAPTER","192.0.2.10","private.example"}.Any(x=>plain.Contains(x)));
            log.Check("opt-in report includes identifiers",Reports.Plain(fixture,true,"").Contains("PRIVATE-PC-EXAMPLE") && Reports.Plain(fixture,true,"").Contains("192.0.2.10"));
            log.Check("notes are labeled and preserved",Reports.Plain(fixture,false,"My issue — café").Contains("My issue — café"));
            log.Check("notes limited to 2000 characters",!Reports.Plain(fixture,false,new string('x',2001)).Contains(new string('x',2001)));
            log.Check("control characters removed",Text.Safe("a\0b\u0001c",10)=="abc");
            log.Check("HTML escapes script and quotes",Reports.Html("<script>alert('x')</script> & \"").Contains("&lt;script&gt;") && !Reports.Html("<script>x</script>").Contains("<script>"));
            log.Check("HTML has no remote assets or executable script",!Reports.Html(plain).Contains("src=") && Reports.Html(plain).Contains("default-src 'none'"));
            log.Test("JSON roundtrip retains report",()=>Require(Reports.Parse(Reports.Json(fixture)).Findings.Count==fixture.Findings.Count));
            log.Test("malformed JSON rejected",()=>Throws<ArgumentException>(()=>Reports.Parse("{broken")));
            log.Test("null JSON rejected",()=>Throws<InvalidDataException>(()=>Reports.Parse("null")));
            log.Test("oversized JSON rejected",()=>Throws<InvalidDataException>(()=>Reports.Parse(new string('x',1048577))));
            log.Test("unknown schema rejected",()=>{var r=Fixture();r.Schema=7;Throws<InvalidDataException>(()=>Reports.Parse(Reports.Json(r)));});
            log.Test("unrecognized status rejected",()=>{var r=Fixture();r.Findings[0].Status="Healthy forever";Throws<InvalidDataException>(()=>Reports.Parse(Reports.Json(r)));});
            log.Test("missing timestamp rejected",()=>{var r=Fixture();r.CollectedUtc=null;Throws<InvalidDataException>(()=>Reports.Parse(Reports.Json(r)));});
            log.Test("save UTF-8 text",()=>{string p=Path.Combine(output,"sample-report.txt");Reports.Save(p,Reports.Plain(fixture,false,"Sample report — café"));Require(File.ReadAllText(p).Contains("café"));});
            log.Test("save static HTML",()=>{string p=Path.Combine(output,"sample-report.html");Reports.Save(p,Reports.Html(plain));Require(File.ReadAllText(p).StartsWith("<!doctype html>"));});
            log.Test("atomic overwrite produces exact new report",()=>{string p=Path.Combine(output,"overwrite.txt");Reports.Save(p,"old");Reports.Save(p,"new");Require(File.ReadAllText(p)=="new");});
            log.Test("locked destination keeps old report",()=>{string p=Path.Combine(output,"locked.txt");Reports.Save(p,"old");using(var s=File.Open(p,FileMode.Open,FileAccess.Read,FileShare.None)) Throws<IOException>(()=>Reports.Save(p,"new"));Require(File.ReadAllText(p)=="old");});
            log.Test("read-only destination preserves old content",()=>{string p=Path.Combine(output,"readonly.txt");Reports.Save(p,"old");File.SetAttributes(p,FileAttributes.ReadOnly);try{Throws<UnauthorizedAccessException>(()=>Reports.Save(p,"new"));Require(File.ReadAllText(p)=="old");}finally{File.SetAttributes(p,FileAttributes.Normal);}});
            log.Test("unsupported extension rejected",()=>Throws<IOException>(()=>Reports.Save(Path.Combine(output,"report.exe"),"x")));
            log.Test("missing destination directory reports failure",()=>Throws<DirectoryNotFoundException>(()=>Reports.Save(Path.Combine(output,"missing-"+Guid.NewGuid().ToString("N"),"r.txt"),"x")));
            log.Check("no orphan atomic-write files",!Directory.GetFiles(output,".deskcheck-*.tmp").Any());
            log.Test("local scan succeeds without probes",()=>{var r=Diagnostics.Collect(null);Require(!r.NetworkTests && r.Facts.Count>0 && r.Findings.Any(x=>x.Title=="Connectivity probes"));Reports.Parse(Reports.Json(r));Reports.Save(Path.Combine(output,"live-redacted-report.txt"),Reports.Plain(r,false,""));});
            log.Test("worker normal completion",()=>{var r=Runner.Run(null,CancellationToken.None).GetAwaiter().GetResult();Require(r.Schema==1 && r.Facts.Count>0);});
            log.Test("worker timeout is bounded",()=>{var s=Stopwatch.StartNew();Throws<TimeoutException>(()=>Runner.RunChild("--test-worker-delay",CancellationToken.None,250));Require(s.ElapsedMilliseconds<4000);});
            log.Test("worker cancellation is bounded",()=>{using(var c=new CancellationTokenSource()){c.CancelAfter(150);var s=Stopwatch.StartNew();Throws<OperationCanceledException>(()=>Runner.RunChild("--test-worker-delay",c.Token,5000));Require(s.ElapsedMilliseconds<4000);}});
            log.Test("pre-cancelled worker never starts",()=>{using(var c=new CancellationTokenSource()){c.Cancel();Throws<OperationCanceledException>(()=>Runner.RunChild("--collect",c.Token,2000));}});
            log.Test("worker exit failure handled",()=>Throws<IOException>(()=>Runner.RunChild("--test-worker-fail",CancellationToken.None,2000)));
            log.Test("retry after worker failure",()=>Require(Runner.Run(null,CancellationToken.None).GetAwaiter().GetResult().Facts.Count>0));
            log.Test("TCP success against local listener",()=>{var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();try{int port=((IPEndPoint)listener.LocalEndpoint).Port;var r=Diagnostics.Collect(new Target{Host="127.0.0.1",Port=port});Require(r.Findings.Any(x=>x.Title=="TCP connection" && x.Status=="Pass"));Require(r.Findings.Any(x=>x.Title=="DNS lookup" && x.Status=="Info"));}finally{listener.Stop();}});
            log.Test("closed TCP port produces Unknown",()=>{var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();int port=((IPEndPoint)listener.LocalEndpoint).Port;listener.Stop();var r=Diagnostics.Collect(new Target{Host="127.0.0.1",Port=port});Require(r.Findings.Any(x=>x.Title=="TCP connection" && x.Status=="Unknown"));});
            log.Test("hostname DNS and TCP success against local listener",()=>{var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();try{var r=Diagnostics.Collect(new Target{Host="localhost",Port=((IPEndPoint)listener.LocalEndpoint).Port});Require(r.Findings.Any(x=>x.Title=="DNS lookup" && x.Status=="Pass") && r.Findings.Any(x=>x.Title=="TCP connection" && x.Status=="Pass"));}finally{listener.Stop();}});
            log.Test("invalid DNS preserves local facts and skips TCP",()=>{var r=Diagnostics.Collect(new Target{Host="deskcheck-does-not-exist.invalid",Port=443});Require(r.Facts.Any(x=>x.Area=="System") && r.Findings.Any(x=>x.Title=="DNS lookup" && x.Status=="Unknown") && !r.Findings.Any(x=>x.Title=="TCP connection"));});
            log.Finish(Path.Combine(output,"test-results.txt"));return log.Failed==0?0:1;
        }
    }
}
