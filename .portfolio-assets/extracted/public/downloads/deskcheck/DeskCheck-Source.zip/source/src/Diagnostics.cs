using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace DeskCheck {
    public static class Diagnostics {
        [StructLayout(LayoutKind.Sequential)] sealed class MemoryInfo {
            public uint Length=64,Load; public ulong Total,Available,TotalPage,AvailablePage,TotalVirtual,AvailableVirtual,Extended;
        }
        [DllImport("kernel32.dll",SetLastError=true)] static extern bool GlobalMemoryStatusEx([In,Out] MemoryInfo info);
        [DllImport("kernel32.dll")] static extern ulong GetTickCount64();
        public static ScanReport Collect(Target target) {
            var r=new ScanReport { CollectedUtc=DateTime.UtcNow.ToString("o"),NetworkTests=target!=null };
            Section(r,"System",()=>SystemInfo(r)); Section(r,"Storage",()=>Storage(r)); Section(r,"Network",()=>Network(r));
            if(target!=null) Section(r,"Network",()=>Probe(r,target));
            else r.Check("Network","Connectivity probes","Info","No outbound diagnostic probes were requested.","Enable connectivity tests to check DNS, one ping, and one TCP connection.");
            return r;
        }
        internal static void Section(ScanReport r,string area,Action action) { try { action(); } catch(Exception e) { r.Check(area,area+" collection","Unknown","Some information was unavailable ("+e.GetType().Name+").","Retry the check. Your Windows policy or an unavailable device may restrict this information."); } }
        static void SystemInfo(ScanReport r) {
            r.Fact("System","Computer name",Environment.MachineName,true);
            using(var k=Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion")) {
                if(k==null) r.Check("System","Windows details","Unknown","Windows version details were unavailable.","Check Windows Settings > System > About.");
                else {
                    string build=Convert.ToString(k.GetValue("CurrentBuildNumber","Unknown")); int b; Int32.TryParse(build,out b);
                    string edition=Convert.ToString(k.GetValue("EditionID",""));
                    r.Fact("System","Windows",(b>=22000?"Windows 11":Convert.ToString(k.GetValue("ProductName","Windows")))+" "+edition);
                    r.Fact("System","Version / build",Convert.ToString(k.GetValue("DisplayVersion",""))+" / "+build+"."+Convert.ToString(k.GetValue("UBR","")));
                }
            }
            using(var k=Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0")) r.Fact("System","Processor",k==null?"Unavailable":Convert.ToString(k.GetValue("ProcessorNameString","Unavailable")).Trim());
            r.Fact("System","Architecture",Environment.Is64BitOperatingSystem?"64-bit Windows":"32-bit Windows");
            r.Fact("System","Logical processors",Environment.ProcessorCount.ToString());
            ulong mins=GetTickCount64()/60000;
            r.Fact("System","Kernel uptime",(mins/1440)+"d "+(mins/60%24)+"h "+(mins%60)+"m (Fast Startup may preserve uptime)");
            var m=new MemoryInfo();
            if(GlobalMemoryStatusEx(m)) { r.Fact("System","Physical memory",Text.Bytes(m.Total)); r.Findings.Add(Rules.Memory(m.Total,m.Available)); }
            else r.Findings.Add(Rules.Memory(0,0));
        }
        static void Storage(ScanReport r) {
            int found=0;
            foreach(var d in DriveInfo.GetDrives()) {
                if(d.DriveType!=DriveType.Fixed) continue; found++;
                try {
                    if(!d.IsReady) { r.Check("Storage",d.Name+" availability","Unknown","This fixed drive is not ready.","Check the drive in Windows Explorer."); continue; }
                    r.Fact("Storage",d.Name+" format",d.DriveFormat);
                    r.Findings.Add(Rules.Disk(d.Name,(ulong)d.TotalSize,(ulong)d.AvailableFreeSpace));
                } catch(Exception e) { r.Check("Storage",d.Name+" availability","Unknown","This drive could not be read ("+e.GetType().Name+").","Check access to this drive. Other drives can still be checked."); }
            }
            if(found==0) r.Check("Storage","Fixed drives","Unknown","No fixed local drives were reported.","Network and removable drives are outside this check's scope.");
        }
        static void Network(ScanReport r) {
            int count=0,up=0;
            foreach(var n in NetworkInterface.GetAllNetworkInterfaces()) {
                if(n.NetworkInterfaceType==NetworkInterfaceType.Loopback) continue;
                count++; if(n.OperationalStatus==OperationalStatus.Up) up++;
                string label="Adapter "+count;
                r.Fact("Network",label+" name",n.Name,true);
                r.Fact("Network",label+" state",n.NetworkInterfaceType+" / "+n.OperationalStatus);
                try {
                    var props=n.GetIPProperties();
                    r.Fact("Network",label+" addresses",String.Join(", ",props.UnicastAddresses.Select(x=>x.Address.ToString()).ToArray()),true);
                    r.Fact("Network",label+" gateways",String.Join(", ",props.GatewayAddresses.Select(x=>x.Address.ToString()).ToArray()),true);
                    r.Fact("Network",label+" DNS servers",String.Join(", ",props.DnsAddresses.Select(x=>x.ToString()).ToArray()),true);
                } catch { r.Check("Network",label+" details","Unknown","IP configuration could not be read.","Check the adapter's Windows network settings."); }
            }
            r.Fact("Network","Adapters reported",count.ToString());
            r.Findings.Add(Rules.Adapter(up));
        }
        static bool Wait(Task t,int ms) { return t.Wait(ms); }
        static void Probe(ScanReport r,Target target) {
            r.Fact("Network","Probe destination",target.Host+" (TCP "+target.Port+")",true);
            IPAddress ip; IPAddress[] addresses;
            if(IPAddress.TryParse(target.Host,out ip)) { addresses=new[]{ip}; r.Check("Network","DNS lookup","Info","Skipped because the destination is an IP address.","Use a hostname to test DNS resolution."); }
            else {
                try {
                    var dns=Dns.GetHostAddressesAsync(target.Host);
                    if(!Wait(dns,4000)) { r.Check("Network","DNS lookup","Unknown","No DNS result within 4 seconds.","Check DNS settings or try another destination."); SkippedProbes(r); return; }
                    addresses=dns.Result.Where(x=>x.AddressFamily==AddressFamily.InterNetwork || x.AddressFamily==AddressFamily.InterNetworkV6).ToArray();
                    if(addresses.Length==0) throw new SocketException();
                    r.Check("Network","DNS lookup","Pass","The hostname resolved to "+addresses.Length+" address(es).","A DNS result alone does not establish service availability.");
                } catch { r.Check("Network","DNS lookup","Unknown","The hostname could not be resolved.","Check the spelling, network connection, and DNS configuration."); SkippedProbes(r); return; }
            }
            // One selected address, one echo, one TCP port. No subnet or port scanning.
            ip=addresses.FirstOrDefault(x=>x.AddressFamily==AddressFamily.InterNetwork)??addresses[0];
            r.Fact("Network","Selected probe address",ip.ToString(),true);
            try {
                using(var ping=new Ping()) {
                    var reply=ping.Send(ip,2000,new byte[16]);
                    bool ok=reply.Status==IPStatus.Success;
                    r.Check("Network","ICMP echo",ok?"Pass":"Unknown",ok?"One echo reply arrived in "+reply.RoundtripTime+" ms.":"No successful echo reply ("+reply.Status+").","ICMP may be blocked even when the destination is reachable. Compare the TCP result.");
                }
            } catch { r.Check("Network","ICMP echo","Unknown","The echo request could not complete.","ICMP may be blocked by local or remote policy. Compare the TCP result."); }
            try {
                using(var tcp=new TcpClient(ip.AddressFamily)) {
                    var connect=tcp.ConnectAsync(ip,target.Port);
                    if(!Wait(connect,3000)) { r.Check("Network","TCP connection","Unknown","No connection within 3 seconds.","Check the destination, port, firewall, VPN, or network. A timeout alone does not locate the fault."); return; }
                    r.Check("Network","TCP connection","Pass","A TCP connection was established to the selected address and port.","This tests transport reachability only; TLS, sign-in, and application responses were not tested.");
                }
            } catch { r.Check("Network","TCP connection","Unknown","The selected address and port did not accept a connection.","The service may be unavailable or filtered. Other addresses returned by DNS were not tested."); }
        }
        static void SkippedProbes(ScanReport r) { r.Check("Network","ICMP / TCP","Info","Not attempted because DNS did not produce an address.","Resolve the DNS issue and run again."); }
    }
    public static class Runner {
        public static Task<ScanReport> Run(Target target,CancellationToken token) {
            string args="--collect"+(target==null?"":" "+target.Host+" "+target.Port);
            return Task.Run(()=>Reports.Parse(RunChild(args,token,25000)),token);
        }
        internal static string RunChild(string args,CancellationToken token,int deadline) {
            var info=new ProcessStartInfo(System.Reflection.Assembly.GetExecutingAssembly().Location,args) { UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true };
            using(var p=new Process { StartInfo=info }) {
                token.ThrowIfCancellationRequested(); p.Start();
                try {
                    var output=ReadBounded(p.StandardOutput,1024*1024); var errors=ReadBounded(p.StandardError,16384); var clock=Stopwatch.StartNew();
                    while(!p.WaitForExit(50)) { token.ThrowIfCancellationRequested(); if(output.IsFaulted || errors.IsFaulted) throw new IOException("Diagnostic output exceeded its limits or could not be read."); if(clock.ElapsedMilliseconds>deadline) throw new TimeoutException("The diagnostic worker exceeded its time limit. Try again; a Windows device call may be stalled."); }
                    token.ThrowIfCancellationRequested();
                    if(!Task.WaitAll(new Task[]{output,errors},2000)) throw new IOException("The diagnostic worker did not close its output stream.");
                    if(p.ExitCode!=0) throw new IOException("The diagnostic worker could not finish. Try again.");
                    if(output.Result.Length>1024*1024) throw new IOException("The diagnostic output exceeded its size limit.");
                    return output.Result;
                } finally { if(!p.HasExited) { p.Kill(); p.WaitForExit(2000); } }
            }
        }
        static async Task<string> ReadBounded(StreamReader reader,int max) {
            var b=new System.Text.StringBuilder(); var chars=new char[4096]; int n;
            while((n=await reader.ReadAsync(chars,0,chars.Length).ConfigureAwait(false))>0) { if(b.Length+n>max) throw new IOException("Diagnostic output exceeded its limit."); b.Append(chars,0,n); }
            return b.ToString();
        }
    }
}
