using System;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Linq;
using Microsoft.Win32;

namespace DeskCheck {
    public static class Program {
        [STAThread] public static int Main(string[] args) {
            try {
                if(args.Length>0) {
                    if(args[0]=="--collect") {
                        Target t=null; string error;
                        if(args.Length!=1 && (args.Length!=3 || !Target.TryParse(args[1],args[2],out t,out error))) return 2;
                        Console.Write(Reports.Json(Diagnostics.Collect(t))); return 0;
                    }
                    if(args[0]=="--test-worker-delay") { Thread.Sleep(10000); return 0; }
                    if(args[0]=="--test-worker-fail") return 3;
                    if(args[0]=="--self-test" && args.Length==2) return SelfTest.Run(args[1]);
                    if(args[0]=="--ui-audit" && args.Length==2) return UiAudit.Run(args[1]);
                    return 2;
                }
                var app=new Application();
                var ui=new Workspace(); app.Run(ui.Window); return 0;
            } catch(Exception e) {
                if(args.Length>0) { Console.Error.WriteLine(e.GetType().Name+": "+e.Message); return 1; }
                MessageBox.Show("DeskCheck could not start.\n\n"+e.Message+"\n\nTry extracting the portable package again, or reinstall DeskCheck.","DeskCheck",MessageBoxButton.OK,MessageBoxImage.Error); return 1;
            }
        }
    }
    public sealed class Workspace {
        public Window Window;
        public ScanReport Report;
        public bool Busy { get { return cancellation!=null; } }
        public Task CurrentRun { get; private set; }
        CancellationTokenSource cancellation;
        TaskCompletionSource<bool> scanFinished;
        bool closingRequested;
        bool closed;
        bool darkTheme = true;
        public T Get<T>(string name) where T:class { return Window.FindName(name) as T; }
        public Workspace() {
            using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("Main.xaml")) Window=(Window)XamlReader.Load(s);
            using(var icon=Assembly.GetExecutingAssembly().GetManifestResourceStream("app.ico")) if(icon!=null) Window.Icon=BitmapFrame.Create(icon,BitmapCreateOptions.PreservePixelFormat,BitmapCacheOption.OnLoad);
            Window.Width=Math.Min(Window.Width,SystemParameters.WorkArea.Width);
            Window.Height=Math.Min(Window.Height,SystemParameters.WorkArea.Height);
            ApplyTheme(darkTheme);
            SystemParameters.StaticPropertyChanged+=OnSystemChanged;
            Get<Button>("ThemeButton").Click+=delegate { darkTheme=!darkTheme; ApplyTheme(darkTheme); AnimateTheme(); };
            Get<Button>("RunButton").Click+=delegate { CurrentRun=StartScan(); };
            Get<Button>("CancelButton").Click+=delegate { if(cancellation!=null) { cancellation.Cancel(); Get<TextBlock>("RunStatus").Text="Cancelling the diagnostic worker…"; } };
            Get<CheckBox>("ProbeToggle").Checked+=delegate { Get<StackPanel>("ProbePanel").Visibility=Visibility.Visible; };
            Get<CheckBox>("ProbeToggle").Unchecked+=delegate { Get<StackPanel>("ProbePanel").Visibility=Visibility.Collapsed; Get<TextBlock>("InputError").Visibility=Visibility.Collapsed; };
            Get<CheckBox>("IncludeIdentifiers").Checked+=delegate { UpdatePreview(); };
            Get<CheckBox>("IncludeIdentifiers").Unchecked+=delegate { UpdatePreview(); };
            Get<TextBox>("NotesInput").TextChanged+=delegate { UpdatePreview(); };
            Get<Button>("SaveText").Click+=delegate { Save(false); };
            Get<Button>("SaveHtml").Click+=delegate { Save(true); };
            Get<Button>("CopyReport").Click+=delegate {
                try { Clipboard.SetText(Get<TextBox>("Preview").Text); Get<TextBlock>("ExportStatus").Text="Report copied. You control where it is pasted."; }
                catch { Get<TextBlock>("ExportStatus").Text="The clipboard is busy or unavailable. Save a TXT report instead."; }
            };
            Window.Closing+=async delegate(object sender,System.ComponentModel.CancelEventArgs e) {
                if(!Busy) return;
                e.Cancel=true;
                if(closingRequested) return;
                closingRequested=true; cancellation.Cancel();
                await scanFinished.Task;
                Window.Close();
            };
            Window.Closed+=delegate { closed=true; SystemParameters.StaticPropertyChanged-=OnSystemChanged; };
            foreach(var name in new[]{"OverviewPanel","SystemPanel","StoragePanel","NetworkPanel"}) {
                var p=Get<StackPanel>(name); p.Children.Add(Heading(name=="OverviewPanel"?"Ready when you are":"No snapshot yet"));
                p.Children.Add(Body("Run checks to see your PC's current information. The scan will not change Windows settings."));
            }
        }
        void OnSystemChanged(object sender,System.ComponentModel.PropertyChangedEventArgs e) { if(e.PropertyName=="HighContrast") Window.Dispatcher.BeginInvoke(new Action(delegate { ApplyTheme(darkTheme); })); }
        void ApplyTheme(bool dark) {
            string[] keys={"Canvas","Surface","Glass","Ink","Muted","Accent","OnAccent","Line","Tint","Glow","Danger"};
            string[] colors=dark
                ?new[]{"#0B1120","#E61A2940","#D9162940","#F8FAFC","#B9C5D6","#63E6BE","#06101D","#44607A","#162942","#63E6BE","#FF8D85"}
                :new[]{"#F3F7FA","#F2FFFFFF","#E6FFFFFF","#102238","#536B80","#139B78","#FFFFFF","#B8CBD8","#E8F1F5","#4FD1A1","#B33A3A"};
            Brush[] high={SystemColors.WindowBrush,SystemColors.WindowBrush,SystemColors.WindowBrush,SystemColors.WindowTextBrush,SystemColors.WindowTextBrush,SystemColors.HighlightBrush,SystemColors.HighlightTextBrush,SystemColors.WindowTextBrush,SystemColors.WindowBrush,SystemColors.HighlightBrush,SystemColors.WindowTextBrush};
            for(int i=0;i<keys.Length;i++) Window.Resources[keys[i]]=SystemParameters.HighContrast?high[i]:(Brush)new BrushConverter().ConvertFromString(colors[i]);
            var moon=Get<FrameworkElement>("ThemeMoon"); var sun=Get<FrameworkElement>("ThemeSun");
            if(moon!=null) moon.Visibility=dark?Visibility.Visible:Visibility.Collapsed;
            if(sun!=null) sun.Visibility=dark?Visibility.Collapsed:Visibility.Visible;
            var toggle=Get<Button>("ThemeButton");
            if(toggle!=null) { toggle.ToolTip=dark?"Switch to light mode":"Switch to dark mode"; AutomationProperties.SetName(toggle,dark?"Switch to light mode":"Switch to dark mode"); }
        }
        void AnimateTheme() {
            var flash=Get<Border>("ThemeFlash");
            if(flash==null) return;
            flash.BeginAnimation(UIElement.OpacityProperty,null); flash.Opacity=0.22;
            flash.BeginAnimation(UIElement.OpacityProperty,new DoubleAnimation(0.22,0,TimeSpan.FromMilliseconds(360)) { EasingFunction=new CubicEase { EasingMode=EasingMode.EaseOut } });
        }
        public async Task StartScan() {
            if(Busy) return;
            Target target=null; string error;
            if(Get<CheckBox>("ProbeToggle").IsChecked==true && !Target.TryParse(Get<TextBox>("HostInput").Text,Get<TextBox>("PortInput").Text,out target,out error)) {
                Get<TextBlock>("InputError").Text=error; Get<TextBlock>("InputError").Visibility=Visibility.Visible; Get<TextBox>("HostInput").Focus(); return;
            }
            Get<TextBlock>("InputError").Visibility=Visibility.Collapsed;
            cancellation=new CancellationTokenSource(); scanFinished=new TaskCompletionSource<bool>(); SetBusy(true);
            Get<TextBlock>("RunStatus").Text=target==null?"Collecting local system, storage, and adapter information…":"Collecting local details, then checking DNS, ICMP, and TCP…";
            try {
                var next=await Runner.Run(target,cancellation.Token);
                if(!closed) { ShowReport(next); Get<TextBlock>("RunStatus").Text="Snapshot complete. Review the findings and report below."; }
            } catch(OperationCanceledException) { if(!closed) Get<TextBlock>("RunStatus").Text="Scan cancelled."+(Report==null?" No snapshot was saved.":" The previous snapshot is still displayed."); }
            catch(Exception e) { if(!closed) Get<TextBlock>("RunStatus").Text="Scan could not complete. "+e.Message+(Report==null?"":" The previous snapshot is still displayed."); }
            finally { cancellation.Dispose(); cancellation=null; if(!closed) SetBusy(false); scanFinished.TrySetResult(true); }
        }
        void SetBusy(bool value) {
            Get<Button>("RunButton").IsEnabled=!value;
            Get<Button>("RunButton").Content=value?"Scanning…":"_Run checks";
            Get<Button>("CancelButton").Visibility=value?Visibility.Visible:Visibility.Collapsed;
            Get<CheckBox>("ProbeToggle").IsEnabled=!value; Get<TextBox>("HostInput").IsEnabled=!value; Get<TextBox>("PortInput").IsEnabled=!value;
            var progress=Get<ProgressBar>("ScanProgress"); if(progress!=null) progress.Visibility=value?Visibility.Visible:Visibility.Collapsed;
            var pulse=Get<Border>("ScanPulse");
            if(pulse!=null) {
                pulse.BeginAnimation(UIElement.OpacityProperty,null);
                pulse.Opacity=value?0.42:0;
                if(value) pulse.BeginAnimation(UIElement.OpacityProperty,new DoubleAnimation(0.18,0.72,TimeSpan.FromMilliseconds(900)) { AutoReverse=true,RepeatBehavior=RepeatBehavior.Forever });
            }
            foreach(var name in new[]{"SaveText","SaveHtml","CopyReport"}) Get<Button>(name).IsEnabled=!value && Report!=null;
        }
        public void ShowReport(ScanReport r) {
            Report=r; int a=r.Findings.Count(x=>x.Status=="Attention"),u=r.Findings.Count(x=>x.Status=="Unknown"),p=r.Findings.Count(x=>x.Status=="Pass");
            Get<TextBlock>("SummaryTitle").Text=a>0?a+" item(s) to review":u>0?"Some checks need another look":"Your snapshot is ready";
            Get<TextBlock>("SummaryDetail").Text=p+" passed  /  "+a+" attention  /  "+u+" unknown\nCollected "+DateTime.Parse(r.CollectedUtc).ToLocalTime().ToString("MMM d, yyyy 'at' h:mm:ss tt")+". Results describe only the checks listed below.";
            foreach(var name in new[]{"OverviewPanel","SystemPanel","StoragePanel","NetworkPanel"}) Get<StackPanel>(name).Children.Clear();
            var overview=Get<StackPanel>("OverviewPanel"); overview.Children.Add(Heading("Findings & next steps"));
            foreach(var c in r.Findings.OrderBy(x=>x.Status=="Attention"?0:x.Status=="Unknown"?1:2)) overview.Children.Add(CheckCard(c));
            foreach(var area in new[]{"System","Storage","Network"}) {
                var panel=Get<StackPanel>(area+"Panel"); panel.Children.Add(Heading(area+" details"));
                foreach(var f in r.Facts.Where(x=>x.Area==area)) {
                    panel.Children.Add(Body(f.Label+(f.Sensitive?" · omitted from default report":""),true));
                    panel.Children.Add(Body(String.IsNullOrEmpty(f.Value)?"None reported":f.Value));
                }
                foreach(var c in r.Findings.Where(x=>x.Area==area)) panel.Children.Add(CheckCard(c));
            }
            UpdatePreview(); SetBusy(Busy);
        }
        TextBlock Heading(string text) { return new TextBlock { Text=text,FontSize=21,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,14),TextWrapping=TextWrapping.Wrap }; }
        TextBlock Body(string text,bool label=false) { var t=new TextBlock { Text=text,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,label?8:0,0,10),FontWeight=label?FontWeights.SemiBold:FontWeights.Normal }; t.SetResourceReference(TextBlock.ForegroundProperty,label?"Ink":"Muted"); return t; }
        Border CheckCard(Finding c) {
            var p=new StackPanel(); p.Children.Add(Body("["+c.Status+"]  "+c.Title,true)); p.Children.Add(Body(c.Detail)); p.Children.Add(Body("Next step: "+c.Advice));
            var b=new Border { Child=p,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(12),Padding=new Thickness(16,8,16,8),Margin=new Thickness(0,0,0,12) }; b.SetResourceReference(Border.BorderBrushProperty,"Line"); b.SetResourceReference(Border.BackgroundProperty,"Glass"); return b;
        }
        public void UpdatePreview() {
            if(Report==null) return;
            Get<TextBox>("Preview").Text=Reports.Plain(Report,Get<CheckBox>("IncludeIdentifiers").IsChecked==true,Get<TextBox>("NotesInput").Text);
            Get<TextBlock>("ExportStatus").Text="Preview updated. "+(Get<CheckBox>("IncludeIdentifiers").IsChecked==true?"Device and network identifiers will be included.":"Device and network identifiers are omitted.");
        }
        void Save(bool html) {
            if(Report==null || Busy) return;
            var dialog=new SaveFileDialog { Title="Save DeskCheck support report",Filter=html?"HTML report (*.html)|*.html":"Text report (*.txt)|*.txt",DefaultExt=html?".html":".txt",AddExtension=true,OverwritePrompt=true,FileName="DeskCheck-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+(html?".html":".txt") };
            try {
                if(dialog.ShowDialog(Window)!=true) return;
                var plain=Get<TextBox>("Preview").Text; Reports.Save(dialog.FileName,html?Reports.Html(plain):plain);
                Get<TextBlock>("ExportStatus").Text="Report saved to "+dialog.FileName;
            } catch(Exception e) { Get<TextBlock>("ExportStatus").Text="Report was not saved. "+e.Message+" Choose a writable local folder and try again."; }
        }
    }
}
