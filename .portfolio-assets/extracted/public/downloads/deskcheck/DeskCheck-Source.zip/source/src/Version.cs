using System.Reflection;
[assembly:AssemblyTitle("DeskCheck")]
[assembly:AssemblyDescription("Local PC diagnostics and support reports")]
[assembly:AssemblyCompany("Allan Jae Eparwa")]
[assembly:AssemblyProduct("DeskCheck")]
[assembly:AssemblyVersion("1.0.0.0")]
[assembly:AssemblyFileVersion("1.0.0.0")]
