using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Script.Serialization;

namespace DeskCheck {
    public sealed class Fact {
        public string Area { get; set; }
        public string Label { get; set; }
        public string Value { get; set; }
        public bool Sensitive { get; set; }
    }
    public sealed class Finding {
        public string Area { get; set; }
        public string Title { get; set; }
        public string Status { get; set; }
        public string Detail { get; set; }
        public string Advice { get; set; }
    }
    public sealed class ScanReport {
        public int Schema { get; set; }
        public string CollectedUtc { get; set; }
        public bool NetworkTests { get; set; }
        public List<Fact> Facts { get; set; }
        public List<Finding> Findings { get; set; }
        public ScanReport() { Schema = 1; Facts = new List<Fact>(); Findings = new List<Finding>(); }
        public void Fact(string area, string label, string value, bool sensitive = false) { Facts.Add(new Fact { Area=area, Label=label, Value=Text.Safe(value,2048), Sensitive=sensitive }); }
        public void Check(string area, string title, string status, string detail, string advice) { Findings.Add(new Finding { Area=area,Title=title,Status=status,Detail=detail,Advice=advice }); }
    }
    public sealed class Target {
        public string Host;
        public int Port;
        public static bool TryParse(string host, string port, out Target target, out string error) {
            target=null; error=null;
            host=(host??"").Trim(); port=(port??"").Trim();
            if (host.Length==0 || host.Length>253) { error="Enter one hostname or IP address (up to 253 characters)."; return false; }
            IPAddress ip;
            if (IPAddress.TryParse(host,out ip)) {
                if (host.Contains("%") || host.StartsWith("[") || host.EndsWith("]")) { error="Use an IP without brackets or a scope ID."; return false; }
                if (ip.AddressFamily==System.Net.Sockets.AddressFamily.InterNetwork && !Regex.IsMatch(host,@"^(0|[1-9][0-9]{0,2})(\.(0|[1-9][0-9]{0,2})){3}$")) { error="IPv4 addresses need four decimal parts, such as 192.168.1.1."; return false; }
                host=ip.ToString();
            } else {
                if (!Regex.IsMatch(host,@"^[a-zA-Z0-9](?:[a-zA-Z0-9.-]*[a-zA-Z0-9])?$") || Regex.IsMatch(host,@"^[0-9.]+$") || host.Split('.').Any(x=>x.Length==0 || x.Length>63 || x.StartsWith("-") || x.EndsWith("-"))) {
                    error="Use a hostname or IP only. URLs, spaces, paths, and port suffixes are not accepted."; return false;
                }
                host=host.ToLowerInvariant();
            }
            int n;
            if (!Regex.IsMatch(port,@"^[0-9]{1,5}$") || !Int32.TryParse(port,out n) || n<1 || n>65535) { error="Enter a TCP port from 1 to 65535."; return false; }
            target=new Target { Host=host,Port=n }; return true;
        }
    }
    public static class Text {
        public static string Safe(string value, int max) {
            value=value??"";
            return new string(value.Where(c=>!Char.IsControl(c) || c=='\n' || c=='\r' || c=='\t').Take(max).ToArray());
        }
        public static string Bytes(ulong value) { return (value/1073741824d).ToString("0.0",CultureInfo.InvariantCulture)+" GiB"; }
        public static string Percent(double value) { return value.ToString("0.0",CultureInfo.InvariantCulture)+"%"; }
    }
    public static class Rules {
        public static Finding Adapter(int up) {
            return new Finding { Area="Network",Title="Adapter connection",Status=up>0?"Pass":"Attention",Detail=up>0?up+" non-loopback adapter(s) report an active link. This alone does not prove Internet access.":"No non-loopback adapter reports an active link.",Advice=up>0?"Use the optional probes to check a specific destination.":"Check Wi-Fi, Ethernet, airplane mode, or VPN settings." };
        }
        public static Finding Disk(string label, ulong total, ulong available) {
            if (total==0 || available>total) return new Finding { Area="Storage", Title=label+" free space", Status="Unknown", Detail="Capacity could not be evaluated.", Advice="Check the drive in Windows Settings." };
            double pct=100d*available/total;
            bool low=pct<10 || available<5UL*1024*1024*1024;
            return new Finding { Area="Storage",Title=label+" free space",Status=low?"Attention":"Pass",Detail=Text.Bytes(available)+" available of "+Text.Bytes(total)+" ("+Text.Percent(pct)+" free).",Advice=low?"Review Storage settings and your files. DeskCheck does not delete anything.":"Available space is above the alert thresholds: 10% and 5 GiB. This is not a disk-health test." };
        }
        public static Finding Memory(ulong total, ulong available) {
            if (total==0 || available>total) return new Finding { Area="System",Title="Memory availability",Status="Unknown",Detail="Physical memory could not be evaluated.",Advice="Try again after Windows finishes starting." };
            double used=100d*(total-available)/total;
            return new Finding { Area="System",Title="Memory availability",Status=used>=90?"Attention":"Pass",Detail=Text.Percent(used)+" in use; "+Text.Bytes(available)+" available of "+Text.Bytes(total)+".",Advice=used>=90?"Review memory use in Task Manager. One snapshot does not diagnose a memory leak.":"Memory use is below the 90% alert threshold at the time of this check." };
        }
    }
    public static class Reports {
        public static JavaScriptSerializer Serializer() { return new JavaScriptSerializer { MaxJsonLength=1024*1024, RecursionLimit=32 }; }
        public static string Json(ScanReport report) { return Serializer().Serialize(report); }
        public static ScanReport Parse(string json) {
            if (String.IsNullOrEmpty(json) || json.Length>1024*1024) throw new InvalidDataException("Invalid diagnostic output size.");
            var r=Serializer().Deserialize<ScanReport>(json);
            DateTime when;
            if (r==null || r.Schema!=1 || !DateTime.TryParse(r.CollectedUtc,CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind,out when) || r.Facts==null || r.Findings==null || r.Facts.Count>2048 || r.Findings.Count>1024) throw new InvalidDataException("The diagnostic result was not valid.");
            foreach(var f in r.Facts) if(f==null || !ValidArea(f.Area) || f.Label==null || f.Label.Length>200 || f.Value==null || f.Value.Length>2048) throw new InvalidDataException("Invalid diagnostic fact.");
            foreach(var f in r.Findings) if(f==null || !ValidArea(f.Area) || !new[]{"Pass","Attention","Unknown","Info"}.Contains(f.Status) || f.Title==null || f.Title.Length>200 || f.Detail==null || f.Detail.Length>4096 || f.Advice==null || f.Advice.Length>4096) throw new InvalidDataException("Invalid diagnostic finding.");
            return r;
        }
        static bool ValidArea(string a) { return a=="System" || a=="Storage" || a=="Network"; }
        public static string Plain(ScanReport r,bool identifiers,string notes) {
            var b=new StringBuilder(); b.AppendLine("DESKCHECK 1.0 | SUPPORT REPORT"); b.AppendLine("Collected (UTC): "+r.CollectedUtc);
            b.AppendLine("Device/network identifiers: "+(identifiers?"INCLUDED":"OMITTED"));
            b.AppendLine("Connectivity probes: "+(r.NetworkTests?"Requested by user":"Not requested"));
            b.AppendLine("Point-in-time observations; not a repair, security, or hardware-health certification.");
            notes=Text.Safe(notes,2000).Trim();
            if(notes.Length>0) { b.AppendLine(); b.AppendLine("USER NOTES (may contain information entered by you)"); b.AppendLine(notes); }
            foreach(var area in new[]{"System","Storage","Network"}) {
                b.AppendLine(); b.AppendLine(area.ToUpperInvariant()); b.AppendLine(new string('-',32));
                foreach(var f in r.Facts.Where(x=>x.Area==area && (identifiers || !x.Sensitive))) b.AppendLine(f.Label+": "+f.Value);
                foreach(var c in r.Findings.Where(x=>x.Area==area)) { b.AppendLine("["+c.Status+"] "+c.Title); b.AppendLine(c.Detail); b.AppendLine("Next step: "+c.Advice); }
            }
            b.AppendLine(); b.AppendLine("Scope: OS/CPU details, memory availability, fixed local disk space, network adapter state, and optional DNS/ICMP/TCP probes. No telemetry, repair actions, or automatic uploads.");
            return b.ToString();
        }
        public static string Html(string plain) {
            return "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'\"><title>DeskCheck support report</title><style>body{margin:0;background:#f3f6f8;color:#172b3a;font:16px/1.6 system-ui,sans-serif}main{max-width:900px;margin:auto;padding:32px}h1{font-size:28px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.65 Consolas,monospace;background:white;padding:24px;border:1px solid #b8c7cd;border-radius:12px}@media(max-width:600px){main{padding:12px}pre{padding:16px}}@media print{body{background:white}main{padding:0}pre{border:0}}</style></head><body><main><h1>DeskCheck / Support report</h1><pre>"+HttpUtility.HtmlEncode(plain)+"</pre></main></body></html>";
        }
        public static void Save(string path,string content) {
            path=Path.GetFullPath(path);
            string ext=Path.GetExtension(path).ToLowerInvariant();
            if(ext!=".txt" && ext!=".html") throw new IOException("Choose a .txt or .html report file.");
            string temp=Path.Combine(Path.GetDirectoryName(path),".deskcheck-"+Guid.NewGuid().ToString("N")+".tmp");
            try {
                using(var s=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)) using(var w=new StreamWriter(s,new UTF8Encoding(false))) { w.Write(content); w.Flush(); s.Flush(true); }
                if(File.Exists(path)) File.Replace(temp,path,null); else File.Move(temp,path);
            } finally { if(File.Exists(temp)) File.Delete(temp); }
        }
    }
}
