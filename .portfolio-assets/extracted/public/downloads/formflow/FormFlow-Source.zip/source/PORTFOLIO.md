# FormFlow portfolio description

FormFlow is a privacy-first desktop form workflow workspace I designed for admin, VA, operations, and support workflows. It keeps form fields, owners, deadlines, review status, and handoff notes in a focused two-column interface.

The project demonstrates native WPF UI development, responsive layout, light/dark theming, animation, local JSON persistence, safe import/export validation, clipboard workflows, per-user installation, and automated regression auditing. It deliberately avoids accounts, API keys, telemetry, and automatic uploads.
