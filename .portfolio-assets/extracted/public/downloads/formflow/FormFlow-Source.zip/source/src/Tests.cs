using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web.Script.Serialization;
namespace FormFlow {
 public sealed class AuditLog{public List<string>Lines=new List<string>();public int Passed,Failed;public void Check(string n,bool ok){if(ok){Passed++;Lines.Add("PASS: "+n);}else{Failed++;Lines.Add("FAIL: "+n);}}public void Test(string n,Action a){try{a();Check(n,true);}catch(Exception e){Failed++;Lines.Add("FAIL: "+n+" — "+e.GetType().Name+": "+e.Message);}}public void Finish(string p){Lines.Add("RESULT: "+Passed+" passed; "+Failed+" failed.");File.WriteAllLines(p,Lines);}}
 public static class Tests{
  static void Need(bool b){if(!b)throw new Exception("Assertion failed");}static void Reject<T>(Action a)where T:Exception{try{a();}catch(T){return;}throw new Exception("Expected "+typeof(T).Name);}
  public static int Run(string dir){dir=Path.GetFullPath(dir);Directory.CreateDirectory(dir);var l=new AuditLog();var sample=FormRules.Sample();
   l.Test("sample forms",()=>Need(sample.Count==4&&sample.Any(x=>x.Favorite)&&sample.Any(FormRules.IsOverdue)));
   l.Test("required title",()=>{var f=sample[0].Clone();f.Title=" ";Need(FormRules.Validate(f)=="Add a form title.");});
   l.Test("email validation",()=>{var f=sample[0].Clone();f.Email="bad";Need(FormRules.Validate(f).Contains("valid email"));});
   l.Test("date validation",()=>{var f=sample[0].Clone();f.DueDate="tomorrow-ish";Need(FormRules.Validate(f).Contains("valid date"));});
   l.Test("approved overdue excluded",()=>{var f=sample[3];Need(!FormRules.IsOverdue(f));});
   l.Test("summary includes fields",()=>Need(FormRules.Summary(sample[0]).Contains(sample[0].Fields)&&FormRules.Summary(sample[0]).Contains(sample[0].DueDate)));
   l.Test("search owner",()=>Need(Forms.Filter(sample,"northstar","All",false,CancellationToken.None).Count==1));
   l.Test("status filter",()=>Need(Forms.Filter(sample,"","Draft",false,CancellationToken.None).Count==1));
   l.Test("priority filter",()=>Need(Forms.Filter(sample,"","All",true,CancellationToken.None).Count==2));
   l.Test("no results",()=>Need(Forms.Filter(sample,"missing","All",false,CancellationToken.None).Count==0));
   l.Test("clone independent",()=>{var f=sample[0].Clone();f.Title="Changed";Need(sample[0].Title!="Changed");});
   l.Test("json roundtrip",()=>{var p=Path.Combine(dir,"workspace.json");Files.Save(p,sample,CancellationToken.None);Need(Files.Load(p,CancellationToken.None).Count==4);});
   l.Test("invalid json",()=>{var p=Path.Combine(dir,"bad.json");File.WriteAllText(p,"bad");Reject<InvalidDataException>(()=>Files.Load(p,CancellationToken.None));});
   l.Test("duplicate IDs",()=>{var p=Path.Combine(dir,"dup.json");var x=sample.Select(f=>f.Clone()).ToList();x[1].Id=x[0].Id;var wrapper=new Dictionary<string,object>{{"Version",1},{"Forms",x}};File.WriteAllText(p,new JavaScriptSerializer().Serialize(wrapper));Reject<InvalidDataException>(()=>Files.Load(p,CancellationToken.None));});
   l.Test("network path rejected",()=>Reject<IOException>(()=>Files.Load(@"\\server\share\forms.json",CancellationToken.None)));
   l.Test("extension rejected",()=>Reject<InvalidDataException>(()=>Files.Save(Path.Combine(dir,"forms.txt"),sample,CancellationToken.None)));
   l.Test("cancelled export",()=>{var c=new CancellationTokenSource();c.Cancel();Reject<OperationCanceledException>(()=>Files.Save(Path.Combine(dir,"cancel.json"),sample,c.Token));});
   var many=Enumerable.Range(0,FormRules.MaxForms+1).Select(i=>new FormRecord{Id=Guid.NewGuid().ToString(),Title="x",Status="Draft"}).ToList();l.Test("form count limit",()=>Reject<InvalidDataException>(()=>Files.Save(Path.Combine(dir,"many.json"),many,CancellationToken.None)));
   for(int i=0;i<35;i++)l.Test("round trip "+i,()=>{var p=Path.Combine(dir,"round"+i+".json");var x=FormRules.Sample();x[0].Notes="note "+i+" with \"quotes\"";Files.Save(p,x,CancellationToken.None);Need(Files.Load(p,CancellationToken.None)[0].Notes==x[0].Notes);});
   l.Finish(Path.Combine(dir,"test-results.txt"));return l.Failed==0?0:1;}
 }
}
