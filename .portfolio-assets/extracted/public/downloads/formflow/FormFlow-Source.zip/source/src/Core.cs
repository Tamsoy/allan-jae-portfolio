using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
namespace FormFlow {
 public sealed class FormRecord {
  public string Id{get;set;} public string Title{get;set;} public string Owner{get;set;} public string Email{get;set;} public string Status{get;set;} public string DueDate{get;set;} public string Fields{get;set;} public string Notes{get;set;} public bool Favorite{get;set;} public DateTime EditedUtc{get;set;}
  public FormRecord Clone(){return new FormRecord{Id=Id,Title=Title,Owner=Owner,Email=Email,Status=Status,DueDate=DueDate,Fields=Fields,Notes=Notes,Favorite=Favorite,EditedUtc=EditedUtc};}
 }
 public static class FormRules {
  public const int MaxForms=500,MaxText=160,MaxLongText=32768,MaxFile=10*1024*1024;
  static readonly string[] Statuses={"Draft","In Review","Approved","Archived"};
  public static string Validate(FormRecord f){
   if(f==null)return "Choose a form.";if(String.IsNullOrWhiteSpace(f.Title))return "Add a form title.";if(f.Title.Trim().Length>MaxText)return "Form title is limited to 160 characters.";
   if((f.Owner??"").Trim().Length>MaxText)return "Owner is limited to 160 characters.";if((f.Email??"").Trim().Length>MaxText)return "Email is limited to 160 characters.";
   if(!String.IsNullOrWhiteSpace(f.Email)&&!Regex.IsMatch(f.Email.Trim(),@"^[^\s@]+@[^\s@]+\.[^\s@]+$"))return "Enter a valid email address or leave it blank.";
   if(!Statuses.Contains(f.Status??""))return "Choose a valid form status.";DateTime due;if(!String.IsNullOrWhiteSpace(f.DueDate)&&!DateTime.TryParse(f.DueDate,out due))return "Due date must be a valid date.";
   if((f.Fields??"").Length>MaxLongText)return "Form fields are limited to 32,768 characters.";if((f.Notes??"").Length>MaxLongText)return "Notes are limited to 32,768 characters.";return null;
  }
  public static bool IsOverdue(FormRecord f){DateTime d;return f!=null&&!String.IsNullOrWhiteSpace(f.DueDate)&&DateTime.TryParse(f.DueDate,out d)&&d.Date<DateTime.Today&&!String.Equals(f.Status,"Archived",StringComparison.OrdinalIgnoreCase)&&!String.Equals(f.Status,"Approved",StringComparison.OrdinalIgnoreCase);}
  public static List<FormRecord> Sample(){return new List<FormRecord>{Item("Website intake form","Maya Chen","maya@northstar.example","In Review",DateTime.Today.AddDays(2),"Brand goals\nTarget audience\nContent inventory","Waiting for final copy and asset links."),Item("New client onboarding","Jordan Lee","jordan@brightpath.example","Draft",DateTime.Today.AddDays(7),"Contact details\nAccess checklist\nKickoff notes","Send the secure intake link after the discovery call."),Item("Invoice approval request","Riley Santos","riley@harbor.example","In Review",DateTime.Today.AddDays(-3),"Invoice number\nLine items\nApproval owner","Budget confirmation is still pending."),Item("Project handoff checklist","Avery Morgan","avery@pinepaper.example","Approved","","Deliverables\nCredentials handoff\nArchive links","Approved and ready for the project archive.")};}
  static FormRecord Item(string t,string o,string e,string s,DateTime d,string fields,string notes){return new FormRecord{Id=Guid.NewGuid().ToString("N"),Title=t,Owner=o,Email=e,Status=s,DueDate=d.ToString("yyyy-MM-dd"),Fields=fields,Notes=notes,Favorite=s=="In Review",EditedUtc=DateTime.UtcNow};}
  static FormRecord Item(string t,string o,string e,string s,string d,string fields,string notes){return new FormRecord{Id=Guid.NewGuid().ToString("N"),Title=t,Owner=o,Email=e,Status=s,DueDate=d,Fields=fields,Notes=notes,Favorite=false,EditedUtc=DateTime.UtcNow};}
  public static string Summary(FormRecord f){var b=new StringBuilder();b.AppendLine(f.Title);if(!String.IsNullOrWhiteSpace(f.Owner))b.AppendLine("Owner: "+f.Owner);if(!String.IsNullOrWhiteSpace(f.Email))b.AppendLine(f.Email);b.AppendLine("Status: "+f.Status);if(!String.IsNullOrWhiteSpace(f.DueDate))b.AppendLine("Due: "+f.DueDate);if(!String.IsNullOrWhiteSpace(f.Fields)){b.AppendLine();b.AppendLine("Fields");b.AppendLine(f.Fields);}if(!String.IsNullOrWhiteSpace(f.Notes)){b.AppendLine();b.AppendLine(f.Notes);}return b.ToString().Trim();}
  public static string[] AllStatuses(){return Statuses.ToArray();}
 }
 public static class Forms {
  public static List<FormRecord> Filter(IEnumerable<FormRecord> all,string query,string status,bool favorites,CancellationToken token){var q=(query??"").Trim().ToLowerInvariant();var result=new List<FormRecord>();foreach(var f in all??Enumerable.Empty<FormRecord>()){token.ThrowIfCancellationRequested();if(favorites&&!f.Favorite)continue;if(!String.IsNullOrEmpty(status)&&status!="All"&&!String.Equals(f.Status,status,StringComparison.OrdinalIgnoreCase))continue;string hay=(f.Title+"\n"+f.Owner+"\n"+f.Email+"\n"+f.Status+"\n"+f.DueDate+"\n"+f.Fields+"\n"+f.Notes).ToLowerInvariant();if(q.Length==0||hay.Contains(q))result.Add(f);}return result.OrderByDescending(x=>x.Favorite).ThenBy(x=>x.DueDate??"9999",StringComparer.OrdinalIgnoreCase).ThenBy(x=>x.Title,StringComparer.OrdinalIgnoreCase).ToList();}
 }
}
