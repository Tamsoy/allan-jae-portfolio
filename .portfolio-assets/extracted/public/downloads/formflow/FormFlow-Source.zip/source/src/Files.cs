using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
namespace FormFlow {
 public static class Files {
  sealed class Package { public int Version{get;set;} public List<FormRecord> Forms{get;set;} }
  public static void Save(string path,IEnumerable<FormRecord> forms,CancellationToken token){Guard(path);var p=new Package{Version=1,Forms=(forms??Enumerable.Empty<FormRecord>()).Select(x=>x.Clone()).ToList()};if(p.Forms.Count>FormRules.MaxForms)throw new InvalidDataException("The workspace cannot contain more than 500 forms.");foreach(var f in p.Forms){var e=FormRules.Validate(f);if(e!=null)throw new InvalidDataException(e);}var json=new JavaScriptSerializer().Serialize(p);var tmp=path+"."+Guid.NewGuid().ToString("N")+".tmp";try{token.ThrowIfCancellationRequested();File.WriteAllText(tmp,json,new UTF8Encoding(false));token.ThrowIfCancellationRequested();if(File.Exists(path))File.Replace(tmp,path,null);else File.Move(tmp,path);}finally{if(File.Exists(tmp))File.Delete(tmp);}}
  public static List<FormRecord> Load(string path,CancellationToken token){Guard(path);var info=new FileInfo(path);if(!info.Exists)throw new FileNotFoundException("Choose an existing FormFlow JSON file.",path);if(info.Length>FormRules.MaxFile)throw new InvalidDataException("The selected file is larger than 10 MiB.");token.ThrowIfCancellationRequested();Package p;try{p=new JavaScriptSerializer().Deserialize<Package>(File.ReadAllText(path,Encoding.UTF8));}catch(Exception e){throw new InvalidDataException("The JSON file is malformed: "+e.Message);}if(p==null||p.Version!=1||p.Forms==null)throw new InvalidDataException("This is not a supported FormFlow workspace.");if(p.Forms.Count>FormRules.MaxForms)throw new InvalidDataException("The workspace cannot contain more than 500 forms.");var ids=new HashSet<string>(StringComparer.OrdinalIgnoreCase);foreach(var f in p.Forms){token.ThrowIfCancellationRequested();if(f==null||String.IsNullOrWhiteSpace(f.Id)||!ids.Add(f.Id))throw new InvalidDataException("Forms must have unique IDs.");var e=FormRules.Validate(f);if(e!=null)throw new InvalidDataException(e);}return p.Forms.Select(x=>x.Clone()).ToList();}
  static void Guard(string path){if(String.IsNullOrWhiteSpace(path))throw new ArgumentException("A file path is required.");var full=Path.GetFullPath(path);if(!String.Equals(Path.GetExtension(full),".json",StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Only .json files are supported.");var root=Path.GetPathRoot(full);if(String.IsNullOrWhiteSpace(root))throw new InvalidDataException("The file path is invalid.");var d=new DirectoryInfo(root);while(d!=null){if(d.Exists&&(d.Attributes&FileAttributes.ReparsePoint)!=0)throw new IOException("FormFlow cannot use a redirected or linked folder.");d=d.Parent;}}
 }
}
