using System.Reflection;
[assembly: AssemblyTitle("FormFlow")]
[assembly: AssemblyDescription("Offline form workflow workspace for fields, routes, and results")]
[assembly: AssemblyCompany("Allan Jae Eparwa")]
[assembly: AssemblyProduct("FormFlow")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
