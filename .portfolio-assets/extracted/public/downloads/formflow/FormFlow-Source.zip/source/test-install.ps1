$ErrorActionPreference = 'Stop'
$buildDir = Join-Path $PSScriptRoot 'build'
$testDir = Join-Path $PSScriptRoot 'install-tests'
New-Item -ItemType Directory -Force $testDir | Out-Null
$productDir = Join-Path $env:LOCALAPPDATA 'Programs/FormFlow'
$setup = Join-Path $buildDir 'FormFlow-Setup.exe'
$app = Join-Path $productDir 'FormFlow.exe'
$shortcut = Join-Path ([Environment]::GetFolderPath('Programs')) 'FormFlow.lnk'
$lines = [Collections.Generic.List[string]]::new()
function Check([string]$name, [bool]$pass) { $lines.Add($(if ($pass) { 'PASS: ' } else { 'FAIL: ' }) + $name) }
function Setup([string[]]$arguments) { $p=Start-Process -FilePath $setup -ArgumentList $arguments -WindowStyle Hidden -Wait -PassThru; return $p.ExitCode }
Check 'initial per-user install' ((Setup @('--quiet')) -eq 0)
foreach ($name in @('FormFlow.exe','FormFlow.exe.config','README.md','LICENSE.txt')) { Check "installed payload matches $name" ((Get-FileHash (Join-Path $buildDir $name)).Hash -eq (Get-FileHash (Join-Path $productDir $name)).Hash) }
Check 'Start menu shortcut exists' (Test-Path -LiteralPath $shortcut)
$reg = Get-ItemProperty 'HKCU:/Software/Microsoft/Windows/CurrentVersion/Uninstall/FormFlow'
Check 'Installed apps metadata correct' ($reg.DisplayVersion -eq '1.0.0' -and $reg.InstallLocation -eq $productDir)
Check 'repeat install succeeds' ((Setup @('--quiet')) -eq 0)
$originalHash = (Get-FileHash -LiteralPath $app).Hash
$lockedFile = [IO.File]::Open((Join-Path $productDir 'README.md'),[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
try { Check 'locked payload safely rejects update' ((Setup @('--quiet')) -ne 0) } finally { $lockedFile.Dispose() }
Check 'failed update restores earlier payload' ((Get-FileHash -LiteralPath $app).Hash -eq $originalHash)
Check 'failed update cleans staging directory' (@(Get-ChildItem -LiteralPath $productDir -Directory -Filter '.install-*').Count -eq 0)
$p=Start-Process -FilePath $app -ArgumentList '--self-test', ('"'+(Join-Path $testDir 'installed-engine')+'"') -WindowStyle Hidden -Wait -PassThru
Check 'installed executable self-tests' ($p.ExitCode -eq 0)
$running=Start-Process -FilePath $app -PassThru
try {[void]$running.WaitForInputIdle(5000);$startupClock=[Diagnostics.Stopwatch]::StartNew();do{$running.Refresh();if($running.MainWindowHandle -ne 0 -or $running.HasExited){break};Start-Sleep -Milliseconds 100}while($startupClock.ElapsedMilliseconds -lt 5000);Check 'installed app opens a window' ($running.MainWindowHandle -ne 0);Check 'in-use installation safely rejected' ((Setup @('--quiet')) -ne 0);Check 'in-use uninstall safely rejected' ((Setup @('--quiet','--uninstall')) -ne 0)} finally {[void]$running.CloseMainWindow();if(-not $running.WaitForExit(5000)){throw 'App failed to close normally'};$running.Dispose()}
$sentinel = Join-Path $productDir ('audit-preserve-' + [Guid]::NewGuid().ToString('N') + '.txt')
[IO.File]::WriteAllText($sentinel,'FormFlow uninstall preservation test')
Check 'uninstall succeeds' ((Setup @('--quiet','--uninstall')) -eq 0)
Check 'uninstall removes only app payload' (-not (Test-Path -LiteralPath $app))
Check 'uninstall preserves unrelated files' (Test-Path -LiteralPath $sentinel)
Check 'uninstall removes Start menu shortcut' (-not (Test-Path -LiteralPath $shortcut))
Check 'uninstall removes Installed apps entry' (-not (Test-Path 'HKCU:/Software/Microsoft/Windows/CurrentVersion/Uninstall/FormFlow'))
Move-Item -LiteralPath $sentinel -Destination (Join-Path $testDir ([IO.Path]::GetFileName($sentinel)))
Check 'final install succeeds' ((Setup @('--quiet')) -eq 0)
$failed = @($lines | Where-Object { $_.StartsWith('FAIL:') }).Count
$lines.Add('RESULT: '+($lines.Count-$failed)+' passed; '+$failed+' failed.')
$lines | Set-Content (Join-Path $testDir 'install-results.txt')
$lines
if ($failed -gt 0) { exit 1 }
