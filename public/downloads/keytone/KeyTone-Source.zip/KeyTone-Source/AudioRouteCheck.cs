using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using KeyTone;
class AudioRouteCheck {
 [ComImport,Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]class Enumerator{}
 [ComImport,Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]interface IEnum{
  [PreserveSig]int EnumAudioEndpoints(int flow,uint state,out ICollection devices);
  [PreserveSig]int GetDefaultAudioEndpoint(int flow,int role,out IDevice device);
 }
 [ComImport,Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]interface ICollection{
  [PreserveSig]int GetCount(out uint count);[PreserveSig]int Item(uint index,out IDevice device);
 }
 [ComImport,Guid("D666063F-1587-4E43-81F1-B948E807363F"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]interface IDevice{
  [PreserveSig]int Activate(ref Guid iid,uint context,IntPtr options,[MarshalAs(UnmanagedType.IUnknown)]out object value);
  [PreserveSig]int OpenPropertyStore(uint access,out IntPtr store);
  [PreserveSig]int GetId([MarshalAs(UnmanagedType.LPWStr)]out string id);
 }
 [ComImport,Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]interface IMeter{
  [PreserveSig]int GetPeakValue(out float peak);
 }
 static float Read(List<IMeter> meters){float peak=0;foreach(var meter in meters){float p;Marshal.ThrowExceptionForHR(meter.GetPeakValue(out p));peak=Math.Max(peak,p);}return peak;}
 [STAThread]static int Main(){var meters=new List<IMeter>();IEnum e=null;ICollection c=null;try{
  e=(IEnum)new Enumerator();Marshal.ThrowExceptionForHR(e.EnumAudioEndpoints(0,1,out c));uint count;c.GetCount(out count);
  for(uint i=0;i<count;i++){IDevice d;c.Item(i,out d);try{Guid g=new Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064");object o;Marshal.ThrowExceptionForHR(d.Activate(ref g,23,IntPtr.Zero,out o));meters.Add((IMeter)o);}finally{Marshal.ReleaseComObject(d);}}
  int failures=0;var names=AudioEngine.Devices();for(int i=-1;i<names.Count-1;i++){
   Thread.Sleep(400);float baseline=0;for(int n=0;n<15;n++){baseline=Math.Max(baseline,Read(meters));Thread.Sleep(10);}
   using(var audio=new AudioEngine(i)){float peak=0;for(int n=0;n<100;n++){if(n%12==0)audio.Play(RecordedBank.Get("Blue Switch",30,false,1),.25f);Thread.Sleep(10);peak=Math.Max(peak,Read(meters));}
    bool pass=audio.Error==null&&audio.CompletedFrames>0&&peak>.0001&&peak>baseline+.0001;
    Console.WriteLine((pass?"PASS":"INCONCLUSIVE")+": "+names[i+1]+" Windows endpoint peak: baseline="+baseline.ToString("F6")+", playback="+peak.ToString("F6")+", completed nonzero frames="+audio.CompletedFrames);
    if(!pass)failures++;
   }
  }return failures==0?0:1;
 }catch(Exception ex){Console.WriteLine(ex);return 1;}finally{foreach(var m in meters)Marshal.ReleaseComObject(m);if(c!=null)Marshal.ReleaseComObject(c);if(e!=null)Marshal.ReleaseComObject(e);}}
}
