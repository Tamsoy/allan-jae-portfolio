using System;
using System.Reflection;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using ShapePath=System.Windows.Shapes.Path;

namespace KeyTone {
 public sealed partial class Studio {
  int themeRevision;
  void InitializeDesign(){
   using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("KeyTone-logo.png")){
    var logo=new BitmapImage();logo.BeginInit();logo.CacheOption=BitmapCacheOption.OnLoad;logo.StreamSource=stream;logo.EndInit();logo.Freeze();C<Image>("BrandLogo").Source=logo;
   }
   SetTheme(settings.DarkMode,false);
   C<Button>("ThemeToggle").Click+=delegate{SetTheme(!settings.DarkMode,true);ScheduleSave();};
   Window.Width=Math.Min(Window.Width,SystemParameters.WorkArea.Width);Window.Height=Math.Min(Window.Height,SystemParameters.WorkArea.Height);
   Window.SizeChanged+=delegate{ArrangeWorkspace();};
   Window.Loaded+=delegate{ArrangeWorkspace();StartDesignMotion();};
   SystemParameters.StaticPropertyChanged+=DesignPreferenceChanged;
  }
  void DesignPreferenceChanged(object sender,System.ComponentModel.PropertyChangedEventArgs e){
   if(e.PropertyName=="HighContrast"||e.PropertyName=="ClientAreaAnimation")Window.Dispatcher.BeginInvoke(new Action(delegate{SetTheme(settings.DarkMode,false);StartDesignMotion();}));
  }
  void ArrangeWorkspace(){
   var grid=C<Grid>("EditorGrid");var inspector=C<Border>("InspectorCard");bool narrow=C<StackPanel>("RootContent").ActualWidth<900;
   Grid.SetColumn(inspector,narrow?0:2);Grid.SetRow(inspector,narrow?1:0);Grid.SetColumnSpan(inspector,narrow?3:1);
   inspector.Margin=narrow?new Thickness(0,18,0,0):new Thickness(0);
   grid.ColumnDefinitions[1].Width=new GridLength(narrow?0:18);grid.ColumnDefinitions[2].Width=new GridLength(narrow?0:280);
   double width=C<StackPanel>("RootContent").ActualWidth;
   C<System.Windows.Controls.Primitives.UniformGrid>("Presets").Columns=width<400?1:width<750?2:5;
   C<System.Windows.Controls.Primitives.UniformGrid>("SwitchPresets").Columns=width<440?1:3;
  }
  internal void SetTheme(bool dark,bool animate){
   settings.DarkMode=dark;int revision=++themeRevision;animate=animate&&SystemParameters.ClientAreaAnimation&&!SystemParameters.HighContrast;
   string[] names={"Canvas","Ink","Muted","Surface","Glass","Line","Accent","OnAccent","Tint","BlueSurface","RedSurface","BrownSurface","GlowBlue","GlowWarm","ThemeSurface","ThemeLine","ThemeInk"};
   string[] day={"#F5F7FB","#172536","#536176","#FFFFFF","#DAFFFFFF","#B4C2D3","#2370BF","#FFFFFF","#E4EFFC","#E0EDFC","#FBE5E7","#EEE1D1","#61ABF5","#D2A881","#FFFFFF","#D4D4D4","#111111"};
   string[] night={"#0D1420","#E9F1FC","#AFBCD0","#202D40","#D91B283A","#4B5E77","#8EC9FF","#102333","#283E59","#25486C","#653440","#594633","#468DE0","#BE916D","#111111","#303030","#F4F4F5"};
   for(int i=0;i<names.Length;i++){
    var previous=Window.Resources[names[i]] as SolidColorBrush;
    var target=(System.Windows.Media.Color)ColorConverter.ConvertFromString((dark?night:day)[i]);
    if(SystemParameters.HighContrast){bool ink=names[i]=="Ink"||names[i]=="Muted"||names[i]=="Line"||names[i]=="ThemeInk"||names[i]=="ThemeLine";target=ink?SystemColors.WindowTextColor:names[i]=="Accent"?SystemColors.HighlightColor:names[i]=="OnAccent"?SystemColors.HighlightTextColor:SystemColors.WindowColor;}
    var from=previous==null?target:previous.Color;var brush=new SolidColorBrush(animate?from:target);
    if(animate){var transition=new ColorAnimation(from,target,TimeSpan.FromMilliseconds(240)){EasingFunction=new SineEase{EasingMode=EasingMode.EaseInOut}};transition.Completed+=delegate{brush.Color=target;brush.BeginAnimation(SolidColorBrush.ColorProperty,null);};brush.BeginAnimation(SolidColorBrush.ColorProperty,transition);}
    Window.Resources[names[i]]=brush;
   }
   var toggle=C<Button>("ThemeToggle");toggle.ToolTip=dark?"Switch to light mode":"Switch to night mode";AutomationProperties.SetName(toggle,(string)toggle.ToolTip);
   FadeIcon(C<ShapePath>("MoonIcon"),!dark,animate,revision);FadeIcon(C<ShapePath>("SunIcon"),dark,animate,revision);
  }
  void FadeIcon(ShapePath icon,bool show,bool animate,int revision){
   double from=icon.Opacity,target=show?1:0;icon.BeginAnimation(UIElement.OpacityProperty,null);icon.Opacity=animate?from:target;
   if(!animate)return;
   var transition=new DoubleAnimation(from,target,TimeSpan.FromMilliseconds(180)){EasingFunction=new SineEase{EasingMode=EasingMode.EaseInOut}};
   transition.Completed+=delegate{if(themeRevision!=revision)return;icon.Opacity=target;icon.BeginAnimation(UIElement.OpacityProperty,null);};icon.BeginAnimation(UIElement.OpacityProperty,transition);
  }
  void StartDesignMotion(){
   var root=C<StackPanel>("RootContent");var glow=C<FrameworkElement>("AmbientGlow");
   root.BeginAnimation(UIElement.OpacityProperty,null);root.Opacity=1;glow.BeginAnimation(UIElement.OpacityProperty,null);glow.Opacity=.15;
   if(!SystemParameters.ClientAreaAnimation||SystemParameters.HighContrast)return;
   root.BeginAnimation(UIElement.OpacityProperty,new DoubleAnimation(0,1,TimeSpan.FromMilliseconds(220)){FillBehavior=FillBehavior.Stop});
   // A single gentle entrance for the background avoids perpetual animation while typing.
   glow.BeginAnimation(UIElement.OpacityProperty,new DoubleAnimation(.05,.15,TimeSpan.FromMilliseconds(700)){EasingFunction=new SineEase{EasingMode=EasingMode.EaseOut},FillBehavior=FillBehavior.Stop});
  }
  void PulseKey(int code){
   Button key;if(!Window.IsVisible||!SystemParameters.ClientAreaAnimation||SystemParameters.HighContrast||!keys.TryGetValue(code,out key))return;
   var scale=key.RenderTransform as ScaleTransform;
   if(scale==null){scale=new ScaleTransform(1,1);key.RenderTransformOrigin=new Point(.5,.5);key.RenderTransform=scale;}
   var press=new DoubleAnimation(.94,1,TimeSpan.FromMilliseconds(140)){EasingFunction=new QuadraticEase{EasingMode=EasingMode.EaseOut},FillBehavior=FillBehavior.Stop};
   scale.BeginAnimation(ScaleTransform.ScaleXProperty,press);scale.BeginAnimation(ScaleTransform.ScaleYProperty,press);
  }
 }
}
