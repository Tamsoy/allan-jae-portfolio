using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

namespace KeyTone {
    public sealed class AudioEngine : IDisposable {
        [StructLayout(LayoutKind.Sequential, Pack=2)] struct WaveFormat { public ushort tag, channels; public uint rate, average; public ushort align, bits, extra; }
        [StructLayout(LayoutKind.Sequential)] struct Header { public IntPtr data; public uint length, recorded; public IntPtr user; public uint flags, loops; public IntPtr next, reserved; }
        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)] struct Caps { public ushort mid, pid; public uint version; [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string name; public uint formats; public ushort channels, reserved; public uint support; }
        [DllImport("winmm.dll")] static extern uint waveOutOpen(out IntPtr h,uint id,ref WaveFormat f,IntPtr callback,IntPtr instance,uint flags);
        [DllImport("winmm.dll")] static extern uint waveOutPrepareHeader(IntPtr h,IntPtr p,uint size);
        [DllImport("winmm.dll")] static extern uint waveOutUnprepareHeader(IntPtr h,IntPtr p,uint size);
        [DllImport("winmm.dll")] static extern uint waveOutWrite(IntPtr h,IntPtr p,uint size);
        [DllImport("winmm.dll")] static extern uint waveOutReset(IntPtr h);
        [DllImport("winmm.dll")] static extern uint waveOutClose(IntPtr h);
        [DllImport("winmm.dll")] static extern uint waveOutGetNumDevs();
        [DllImport("winmm.dll",CharSet=CharSet.Unicode)] static extern uint waveOutGetDevCapsW(UIntPtr id,out Caps caps,uint size);
        public static List<string> Devices() { var names=new List<string>{"System default"}; for(uint i=0;i<waveOutGetNumDevs();i++){Caps c;names.Add(waveOutGetDevCapsW(new UIntPtr(i),out c,(uint)Marshal.SizeOf(typeof(Caps)))==0?c.name:"Output "+(i+1));}return names; }
        class Voice { public float[] Samples; public double Position; public float Gain; }
        readonly object gate=new object(); readonly List<Voice> voices=new List<Voice>(64);
        readonly IntPtr[] headers=new IntPtr[3], buffers=new IntPtr[3];
        readonly long[] queuedNonzero=new long[3];
        readonly int headerSize=Marshal.SizeOf(typeof(Header));
        const int Frames=480;
        IntPtr handle; Thread thread; volatile bool running; bool disposed; int channels; uint rate;
        public volatile string Error;
        public long Played,NonzeroFrames,Blocks,CompletedFrames;
        public string OutputDescription { get { return "Windows PCM mixer · "+rate+" Hz"; } }
        public AudioEngine(int device) {
            string last="No output device is available.";
            foreach(uint hz in new uint[]{48000,44100}) foreach(ushort ch in new ushort[]{2,1}) {
                var format=new WaveFormat{tag=1,channels=ch,rate=hz,average=hz*ch*2,align=(ushort)(ch*2),bits=16};
                try { Open(device,format); return; } catch(Exception e) { last=e.Message; CloseNative(); }
            }
            throw new InvalidOperationException("Audio unavailable: "+last+" Connect speakers or earphones; KeyTone will retry automatically.");
        }
        void Open(int device,WaveFormat format) {
            Check(waveOutOpen(out handle,device<0?UInt32.MaxValue:(uint)device,ref format,IntPtr.Zero,IntPtr.Zero,0));
            channels=format.channels;rate=format.rate;
            int bytes=Frames*channels*2;
            for(int i=0;i<3;i++) {
                buffers[i]=Marshal.AllocHGlobal(bytes);Marshal.Copy(new byte[bytes],0,buffers[i],bytes);
                headers[i]=Marshal.AllocHGlobal(headerSize);
                Marshal.StructureToPtr(new Header{data=buffers[i],length=(uint)bytes},headers[i],false);
                Check(waveOutPrepareHeader(handle,headers[i],(uint)headerSize));
                Check(waveOutWrite(handle,headers[i],(uint)headerSize));
            }
            Error=null;running=true;
            thread=new Thread(Pump){IsBackground=true,Name="KeyTone audio",Priority=ThreadPriority.AboveNormal};thread.Start();
        }
        static void Check(uint result) { if(result!=0)throw new InvalidOperationException("Windows audio error "+result+"."); }
        public void Play(float[] samples,float gain) {
            if(samples==null||samples.Length==0||Single.IsNaN(gain)||Single.IsInfinity(gain)||gain<=0)return;
            lock(gate){if(!running||disposed)return;if(voices.Count>=64)voices.RemoveAt(0);voices.Add(new Voice{Samples=samples,Gain=gain});Interlocked.Increment(ref Played);}
        }
        public void Clear() { lock(gate)voices.Clear(); }
        void Pump() {
            var pcm=new short[Frames*channels];var mix=new float[Frames];int next=0;var progress=Stopwatch.StartNew();
            try {
                while(running) {
                    Header h=(Header)Marshal.PtrToStructure(headers[next],typeof(Header));
                    if((h.flags&1)==0){if(progress.ElapsedMilliseconds>2000)throw new InvalidOperationException("Audio output stopped responding.");Thread.Sleep(2);continue;}
                    progress.Restart();Interlocked.Add(ref CompletedFrames,queuedNonzero[next]);queuedNonzero[next]=0;
                    Array.Clear(mix,0,mix.Length);
                    lock(gate) {
                        for(int v=voices.Count-1;v>=0;v--) {
                            Voice voice=voices[v];
                            for(int i=0;i<Frames&&voice.Position<voice.Samples.Length;i++) {
                                int at=(int)voice.Position;double part=voice.Position-at;
                                float a=voice.Samples[at],b=voice.Samples[Math.Min(at+1,voice.Samples.Length-1)];
                                mix[i]+=(float)(a+(b-a)*part)*voice.Gain;voice.Position+=SoundBank.Rate/(double)rate;
                            }
                            if(voice.Position>=voice.Samples.Length)voices.RemoveAt(v);
                        }
                    }
                    long nonzero=0;
                    for(int i=0;i<Frames;i++) {
                        short value=(short)(Math.Max(-.98f,Math.Min(.98f,mix[i]))*32767);
                        if(value!=0)nonzero++;
                        for(int c=0;c<channels;c++)pcm[i*channels+c]=value;
                    }
                    // Marshal.Copy counts Int16 elements, not bytes. WinMM takes sizeof(WAVEHDR).
                    Marshal.Copy(pcm,0,buffers[next],pcm.Length);
                    Check(waveOutWrite(handle,headers[next],(uint)headerSize));
                    queuedNonzero[next]=nonzero;Interlocked.Add(ref NonzeroFrames,nonzero);Interlocked.Increment(ref Blocks);
                    next=(next+1)%headers.Length;
                }
            } catch(Exception e) { Error=e.Message;running=false; }
        }
        void CloseNative() {
            running=false;if(thread!=null&&thread!=Thread.CurrentThread){thread.Join();thread=null;}
            if(handle!=IntPtr.Zero)waveOutReset(handle);
            for(int i=0;i<headers.Length;i++) {
                if(headers[i]!=IntPtr.Zero){if(handle!=IntPtr.Zero)waveOutUnprepareHeader(handle,headers[i],(uint)headerSize);Marshal.FreeHGlobal(headers[i]);headers[i]=IntPtr.Zero;}
                if(buffers[i]!=IntPtr.Zero){Marshal.FreeHGlobal(buffers[i]);buffers[i]=IntPtr.Zero;}
            }
            if(handle!=IntPtr.Zero){waveOutClose(handle);handle=IntPtr.Zero;}
        }
        public void Dispose(){lock(gate){if(disposed)return;disposed=true;running=false;voices.Clear();}CloseNative();}

        // Poll the Windows default endpoint as well as device arrival/removal messages.
        // A default-route change in Settings need not send WM_DEVICECHANGE.
        [ComImport,Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class Enumerator {}
        [ComImport,Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IEnum {
            [PreserveSig]int EnumAudioEndpoints(int flow,uint state,out IntPtr devices);
            [PreserveSig]int GetDefaultAudioEndpoint(int flow,int role,out IDevice device);
        }
        [ComImport,Guid("D666063F-1587-4E43-81F1-B948E807363F"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IDevice {
            [PreserveSig]int Activate(ref Guid iid,uint context,IntPtr options,out IntPtr value);
            [PreserveSig]int OpenPropertyStore(uint access,out IntPtr store);
            [PreserveSig]int GetId([MarshalAs(UnmanagedType.LPWStr)]out string id);
        }
        public static string RouteFingerprint() {
            IEnum enumerator=null;IDevice device=null;string id="unavailable";
            try{enumerator=(IEnum)new Enumerator();if(enumerator.GetDefaultAudioEndpoint(0,1,out device)>=0)device.GetId(out id);}
            catch(COMException){} finally{if(device!=null)Marshal.ReleaseComObject(device);if(enumerator!=null)Marshal.ReleaseComObject(enumerator);}
            return id+"|"+String.Join("|",Devices());
        }
    }
}
