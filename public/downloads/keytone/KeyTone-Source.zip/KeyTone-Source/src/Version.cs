using System.Reflection;
[assembly: AssemblyTitle("KeyTone")]
[assembly: AssemblyDescription("Mechanical keyboard sounds, tuned to you")]
[assembly: AssemblyProduct("KeyTone")]
[assembly: AssemblyVersion("1.3.1.0")]
[assembly: AssemblyFileVersion("1.3.1.0")]
