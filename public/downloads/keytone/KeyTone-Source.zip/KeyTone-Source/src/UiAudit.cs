using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using ShapePath=System.Windows.Shapes.Path;

namespace KeyTone {
 public static class UiAudit {
  public static int Run(string directory){
   directory=Path.GetFullPath(directory);Directory.CreateDirectory(directory);
   var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};
   app.Startup+=async delegate{Studio studio=null;try{studio=new Studio(Path.Combine(directory,"isolated-profile"),false);await studio.AuditDesign(directory);}catch(Exception e){File.WriteAllText(Path.Combine(directory,"fatal.txt"),e.ToString());app.Shutdown(1);}};
   return app.Run();
  }
 }
 public sealed partial class Studio {
  internal async Task AuditDesign(string directory){
   var results=new List<string>();int failures=0;
   Action<string,bool> check=delegate(string name,bool pass){results.Add((pass?"PASS: ":"FAIL: ")+name);if(!pass)failures++;};
   Action<string> click=delegate(string name){C<Button>(name).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));};
   try{
    await Task.Delay(400);SetTheme(false,false);
    check("embedded enhanced logo loads",C<Image>("BrandLogo").Source!=null&&Window.Icon!=null);
    check("all eight presets and physical keys available",presetButtons.Count==8&&keys.Count>70);
    var theme=C<Button>("ThemeToggle");var moon=C<ShapePath>("MoonIcon");var sun=C<ShapePath>("SunIcon");
    var viewport=C<Viewbox>("ThemeIconViewport");Window.UpdateLayout();var center=viewport.TranslatePoint(new Point(viewport.ActualWidth/2,viewport.ActualHeight/2),theme);
    check("small circular theme button centers icons",Math.Abs(center.X-theme.ActualWidth/2)<1&&Math.Abs(center.Y-theme.ActualHeight/2)<1&&Math.Abs(theme.ActualWidth-38)<1);
    check("complete moon and sun outlines fit viewport",new Rect(0,0,24,24).Contains(sun.Data.GetRenderBounds(new Pen(Brushes.Black,1.8)))&&new Rect(0,0,24,24).Contains(moon.Data.GetRenderBounds(new Pen(Brushes.Black,1.8))));
    click("ThemeToggle");await Task.Delay(90);var middle=((SolidColorBrush)Window.Resources["Canvas"]).Color;
    bool motion=SystemParameters.ClientAreaAnimation&&!SystemParameters.HighContrast;
    check("palette interpolates and icons crossfade",!motion||(middle.R>13&&middle.R<245&&sun.Opacity>0&&sun.Opacity<1&&moon.Opacity>0&&moon.Opacity<1));
    await Task.Delay(300);
    check("night palette settles and action is labeled",sun.Opacity==1&&moon.Opacity==0&&((SolidColorBrush)Window.Resources["Canvas"]).Color==System.Windows.Media.Color.FromRgb(13,20,32)&&AutomationProperties.GetName(theme)=="Switch to light mode");
    ShotDesign(directory,"keytone-night.png");
    click("ThemeToggle");await Task.Delay(60);var before=((SolidColorBrush)Window.Resources["Canvas"]).Color;click("ThemeToggle");
    check("rapid reversal starts at current color",!motion||before==((SolidColorBrush)Window.Resources["Canvas"]).Color);
    for(int i=0;i<5;i++){click("ThemeToggle");await Task.Delay(30);}await Task.Delay(320);
    check("rapid clicks honor final light mode",!settings.DarkMode&&theme.IsEnabled&&moon.Opacity==1&&sun.Opacity==0);
    click("ThemeToggle");await Task.Delay(40);SetTheme(false,false);await Task.Delay(300);
    check("nonanimated selection cancels obsolete callbacks",moon.Opacity==1&&sun.Opacity==0&&((SolidColorBrush)Window.Resources["Canvas"]).Color==System.Windows.Media.Color.FromRgb(245,247,251));
    theme.Focus();check("theme keyboard focus and accessible name",theme.IsKeyboardFocused&&((FrameworkElement)theme.Template.FindName("FocusRing",theme)).Visibility==Visibility.Visible&&new ButtonAutomationPeer(theme).GetName()=="Switch to night mode");
    C<Button>("EnableButton").Focus();ShotDesign(directory,"keytone-light.png");
    click("AllBlue");check("all blue assigns every key",Current.Keys.Count==0&&Current.Preset=="Blue Switch");
    keys[30].RaiseEvent(new RoutedEventArgs(Button.ClickEvent));click("KeyRed");check("red A keeps other keys blue",Current.EffectivePreset(30)=="Red Switch"&&Current.EffectivePreset(31)=="Blue Switch");
    keys[57].RaiseEvent(new RoutedEventArgs(Button.ClickEvent));click("KeyBrown");check("brown space mixes with red A and blue S",Current.EffectivePreset(57)=="Brown Switch"&&Current.EffectivePreset(30)=="Red Switch"&&Current.EffectivePreset(31)=="Blue Switch");
    C<Slider>("Pitch").Value=3;C<Slider>("Tone").Value=-.5;C<Slider>("KeyVolume").Value=.7;
    check("key tuning changes selected key only",Current.Get(57).Pitch==3&&Current.Get(57).Tone==-.5&&Current.Get(57).Volume==.7&&Current.Get(30).Pitch==0);
    click("AllRed");click("UndoSwitch");check("undo restores mixed switch tuning",Current.Get(57).Pitch==3&&Current.EffectivePreset(57)=="Brown Switch"&&Current.EffectivePreset(31)=="Blue Switch");
    click("AllBrown");check("all brown replaces overrides",Current.Keys.Count==0&&Current.Preset=="Brown Switch");click("UndoSwitch");
    click("ResetKey");check("reset inherits keyboard default",!Current.Keys.ContainsKey("57"));
    click("CaptureButton");OnKey(32,false);check("select by typing selects physical key",selected==32&&!capture);click("CaptureButton");OnKey(1,false);check("escape cancels capture",!capture&&selected==32);
    foreach(var pair in presetButtons){pair.Value.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));check("preset preview "+pair.Key,Current.Preset==pair.Key);}await Task.Delay(200);
    C<Slider>("MasterVolume").Value=.2;check("master volume setting",Current.Volume==.2);
    bool enabled=settings.Enabled;click("EnableButton");check("mute state",settings.Enabled!=enabled);click("EnableButton");
    if(audio!=null){audio.Clear();await Task.Delay(300);var played=audio.Played;var completed=audio.CompletedFrames;OnKey(30,false);OnKey(30,true);await Task.Delay(250);check("typing callback completes non-silent driver buffers",audio.Played>=played+2&&audio.Error==null&&audio.CompletedFrames>completed);}else check("native audio output available",false);
    C<TextBox>("TypingTest").Text="audit text never persist 9876";click("ClearTest");check("clear typing room",C<TextBox>("TypingTest").Text=="");
    C<TextBox>("TypingTest").Text="audit text never persist 9876";SetTheme(true,false);Save();string warning;var saved=Store.Read(settingsFile,out warning);
    check("theme and profile persist",saved.DarkMode&&saved.Profiles[saved.Active].Volume==.2&&warning==null);
    check("typing text excluded from saved settings",!File.ReadAllText(settingsFile).Contains("audit text never persist"));C<TextBox>("TypingTest").Clear();SetTheme(false,false);
    foreach(bool dark in new[]{false,true})foreach(int width in new[]{580,800,1024,1440})foreach(double scale in new[]{1d,1.5d}){
     C<Expander>("MoreStyles").IsExpanded=true;SetTheme(dark,false);Window.Width=width;Window.Height=850;C<StackPanel>("RootContent").LayoutTransform=new ScaleTransform(scale,scale);Window.UpdateLayout();ArrangeWorkspace();Window.UpdateLayout();
     var scroll=C<ScrollViewer>("OuterScroll");check((dark?"night":"light")+" layout "+width+" at "+scale,scroll.ExtentWidth<=scroll.ViewportWidth+2&&Fits(C<StackPanel>("RootContent")));
    }
    C<Expander>("MoreStyles").IsExpanded=false;C<StackPanel>("RootContent").LayoutTransform=Transform.Identity;Window.Width=580;Window.UpdateLayout();ArrangeWorkspace();C<ScrollViewer>("OuterScroll").ScrollToTop();ShotDesign(directory,"keytone-narrow.png");
    check("narrow layout stacks inspector",Grid.GetRow(C<Border>("InspectorCard"))==1);
    Window.Width=1220;SetTheme(false,false);Window.UpdateLayout();ArrangeWorkspace();C<ScrollViewer>("OuterScroll").ScrollToVerticalOffset(390);ShotDesign(directory,"keytone-keyboard.png");
    var settingsInspection=Window.Dispatcher.BeginInvoke(new Action(delegate{var dialog=Window.OwnedWindows.Cast<Window>().FirstOrDefault();if(dialog==null){check("settings window opens",false);return;}check("settings follows selected palette",((SolidColorBrush)dialog.Background).Color==((SolidColorBrush)Window.Resources["Canvas"]).Color);var controls=Descendants(dialog).OfType<Button>().ToArray();check("settings profile and output controls available",controls.Any(b=>(string)b.Content=="Duplicate")&&Descendants(dialog).OfType<ComboBox>().Count()>=2);controls.First(b=>(string)b.Content=="Duplicate").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));check("profile duplication works",settings.Profiles.Count==2);dialog.Close();}));
    click("SettingsButton");await settingsInspection.Task;
   }catch(Exception e){check("UI audit exception: "+e,false);}
   results.Add("RESULT: "+(results.Count-failures)+" passed; "+failures+" failed.");File.WriteAllLines(Path.Combine(directory,"ui-results.txt"),results);Quit(failures==0?0:1);
  }
  static IEnumerable<DependencyObject> Descendants(DependencyObject root){for(int i=0;i<VisualTreeHelper.GetChildrenCount(root);i++){var child=VisualTreeHelper.GetChild(root,i);yield return child;foreach(var nested in Descendants(child))yield return nested;}}
  static bool Fits(FrameworkElement root){return Descendants(root).OfType<FrameworkElement>().Where(e=>e.IsVisible&&(e is Button||e is Slider||e is ComboBox)).All(e=>{var r=e.TransformToAncestor(root).TransformBounds(new Rect(0,0,e.ActualWidth,e.ActualHeight));return r.Left>=-2&&r.Right<=root.ActualWidth+2;});}
  void ShotDesign(string directory,string name){Window.UpdateLayout();var root=(FrameworkElement)Window.Content;var image=new RenderTargetBitmap((int)Math.Ceiling(root.ActualWidth),(int)Math.Ceiling(root.ActualHeight),96,96,PixelFormats.Pbgra32);image.Render(root);var png=new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(image));using(var stream=File.Create(Path.Combine(directory,name)))png.Save(stream);}
 }
}
