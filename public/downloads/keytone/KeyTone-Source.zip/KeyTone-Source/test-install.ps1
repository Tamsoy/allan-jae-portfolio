$ErrorActionPreference='Stop'
$setup=Join-Path $PSScriptRoot 'build/KeyTone-Setup.exe'
$testRoot=Join-Path $PSScriptRoot 'install-audit'
$target=Join-Path $testRoot 'disposable-install'
New-Item -ItemType Directory -Force -Path $testRoot | Out-Null
$checks=[Collections.Generic.List[string]]::new()
function Check([string]$label,[bool]$pass){$checks.Add($(if($pass){'PASS: '}else{'FAIL: '})+$label)}
function RunSetup([string[]]$arguments){$process=Start-Process -FilePath $setup -ArgumentList $arguments -WindowStyle Hidden -Wait -PassThru;return $process.ExitCode}
$quotedTarget='"'+$target+'"'
Check 'install to isolated target' ((RunSetup @('--quiet','--target',$quotedTarget)) -eq 0)
foreach($file in @('KeyTone.exe','KeyTone.exe.config','README.txt','LICENSE.txt','THIRD-PARTY-NOTICES.txt')){Check ('payload matches '+$file) ((Get-FileHash (Join-Path $target $file)).Hash -eq (Get-FileHash (Join-Path $PSScriptRoot ('build/'+$file))).Hash)}
Check 'repeat installation' ((RunSetup @('--quiet','--target',$quotedTarget)) -eq 0)
$running=Start-Process -FilePath (Join-Path $target 'KeyTone.exe') -ArgumentList @('--data-dir',('"'+(Join-Path $testRoot 'disposable-settings')+'"')) -PassThru
try{
 [void]$running.WaitForInputIdle(5000)
 $clock=[Diagnostics.Stopwatch]::StartNew()
 do{$running.Refresh();if($running.HasExited -or $running.MainWindowHandle -ne 0){break};Start-Sleep -Milliseconds 100}while($clock.ElapsedMilliseconds -lt 10000)
 Check 'installed application opens responsive window' ($running.MainWindowHandle -ne 0 -and $running.Responding)
 Check 'in-use update rejected' ((RunSetup @('--quiet','--target',$quotedTarget)) -ne 0)
 Check 'in-use uninstall rejected' ((RunSetup @('--quiet','--uninstall','--target',$quotedTarget)) -ne 0)
}finally{if(-not $running.HasExited){Stop-Process -Id $running.Id -Force;$running.WaitForExit()}}
Set-Content (Join-Path $target 'unrelated.txt') 'keep this unrelated file'
Check 'isolated uninstall succeeds' ((RunSetup @('--quiet','--uninstall','--target',$quotedTarget)) -eq 0)
Check 'uninstall removes app payload' (-not (Test-Path (Join-Path $target 'KeyTone.exe')))
Check 'uninstall preserves unrelated files' (Test-Path (Join-Path $target 'unrelated.txt'))
$settings=Join-Path $env:LOCALAPPDATA 'KeyTone/settings.json'
$before=if(Test-Path $settings){(Get-FileHash $settings).Hash}else{$null}
Check 'real per-user installation succeeds' ((RunSetup @('--quiet')) -eq 0)
$installed=Join-Path $env:LOCALAPPDATA 'Programs/KeyTone/KeyTone.exe'
Check 'real installed executable matches tested build' ((Get-FileHash $installed).Hash -eq (Get-FileHash (Join-Path $PSScriptRoot 'build/KeyTone.exe')).Hash)
$after=if(Test-Path $settings){(Get-FileHash $settings).Hash}else{$null}
Check 'upgrade preserves existing settings' ($before -eq $after)
Check 'Start menu shortcut exists' (Test-Path (Join-Path ([Environment]::GetFolderPath('Programs')) 'KeyTone.lnk'))
Check 'installed version is 1.3.1' ((Get-ItemProperty 'HKCU:/Software/Microsoft/Windows/CurrentVersion/Uninstall/KeyTone').DisplayVersion -eq '1.3.1')
$failed=@($checks | Where-Object {$_ -like 'FAIL:*'}).Count
$checks.Add('RESULT: '+($checks.Count-$failed)+' passed; '+$failed+' failed.')
$checks | Set-Content (Join-Path $testRoot 'install-results.txt')
$checks
if($failed -gt 0){throw 'Installer audit failed'}
