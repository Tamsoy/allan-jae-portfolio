# SheetClean — side quest project

## Project description
SheetClean is a local Windows CSV-cleaning utility for virtual assistants, administrative staff, and IT support workflows. It helps review messy lists before sharing them: trim outer whitespace, optionally remove duplicate and blank rows, flag missing required values, preview the proposed output, and export a separate cleaned copy with a traceable JSON change log. Text values preserve IDs, leading zeros, and date strings inside the application. The original input is protected against accidental overwrite.

Built by Allan Jae Eparwa with AI assistance using C#, WPF, and .NET Framework 4.8. Delivered as a per-user Windows installer, portable package, and MIT-licensed source. No cloud upload, account, or API key is required.

## What this demonstrates
- Practical VA data-preparation workflows and careful handling of client files.
- Desktop UI development, asynchronous operations, cancellation, and accessible native controls.
- Strict CSV parsing, Unicode/encoding handling, resource limits, and traceable transformations.
- Safe file exports, installer packaging, regression testing, and honest release documentation.

## Portfolio copy
Short card: “An offline Windows tool that turns messy CSV files into reviewed, traceable exports. Clean duplicates and whitespace, flag missing values, and keep the original untouched.”

Role: Personal side project · Product planning, implementation and testing with AI assistance.

Stack: C# · WPF · .NET Framework 4.8 · CSV/JSON · Windows installer.

Validation: 331 recorded automated checks passed, including 100 independent Python-generated CSV fixtures and 72 simulated layout combinations. Native Windows import/export dialogs were also exercised. This is tested portfolio software, not independently certified or proven bug-free across all devices.

## Prompt for v0
Add SheetClean to the “Side Quests” or personal-projects section of my existing portfolio. Match my current typography, spacing, colors and card style. Use the short card description above and a detail view explaining the problem, workflow, stack, my role with AI assistance, screenshots, and the tested limitations. Include buttons for Windows installer, portable ZIP, source ZIP, project flow and audit report only when I provide publicly hosted URLs for those assets. Do not invent GitHub/demo links or connect my local C: paths to the public website. Until URLs are supplied, show “Download coming soon” as plain text. Explain Windows 11 x64/.NET 4.8 requirements, CSV/TSV support, local processing, and that the build is unsigned. Make the card responsive and keyboard accessible. Do not claim XLSX/mobile support, cloud integration, universal formula protection, zero bugs, or independent security certification. Preserve the rest of the portfolio.
