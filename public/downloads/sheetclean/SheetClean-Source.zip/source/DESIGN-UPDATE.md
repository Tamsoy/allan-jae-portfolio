# SheetClean UI/UX update

SheetClean now uses a minimal glassmorphism direction grounded in the UI/UX Pro Max design system search and 21st.dev inspiration search.

## Direction

- Pale blue canvas with translucent white surfaces creates a calm data-cleaning workspace.
- Sky blue is reserved for the main action; green marks workflow readiness and successful cleanup.
- Rounded glass cards, fine blue-gray borders, and an 8px spacing rhythm create hierarchy without visual clutter.
- The header keeps the SheetClean CSV mark visible and uses a compact workspace label.
- The theme control sits at the header's right edge as a 38px circular button. Centered outlined moon and eight-ray sun icons match the supplied reference style, with a white face in light mode and charcoal face in night mode.
- The workflow banner makes the three-step path explicit: import, review, and export a copy.
- Soft blurred glow layers provide a quiet background focal point without competing with the data.
- The workspace fades in on launch and the blue glow breathes gently. Theme colors interpolate over 240ms; the icons crossfade over 180ms. Repeated clicks reverse from the currently displayed colors without disabling the button or fading the entire page. Windows animation preferences and high contrast disable theme motion.
- The header toggle switches between light and night palettes using the same semantic resource tokens.

## Interaction and accessibility

- Primary workspace actions are at least 44px high. The compact theme button is 38px as requested, with a circular hover/press state, an explicit keyboard focus ring, and a dynamic accessible name.
- Existing access keys, native controls, live status text, and screen-reader names remain intact.
- Data grids have clearer row separation and alternating surfaces for scanning wide CSV previews.
- Light and night modes keep body text, checkbox labels, tabs, borders, and disabled states legible.
- Empty, loading, stale-result, cancellation, and failure states remain explicit and preserve the current workspace.
- The redesign stays native WPF and does not add web assets, APIs, telemetry, or runtime dependencies.

The 21st.dev search returned glassmorphism metric/card references. Their hierarchy and surface treatment were adapted as visual inspiration for WPF; no React or Tailwind code was pasted into the application.
