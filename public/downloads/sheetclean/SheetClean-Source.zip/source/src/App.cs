using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Automation;
using System.Windows.Data;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using ShapePath = System.Windows.Shapes.Path;
using Microsoft.Win32;

namespace SheetClean {
 public static class Program {
  [STAThread] public static int Main(string[] args) {
   try {
    if(args.Length==2 && args[0]=="--self-test")return Tests.Run(args[1]);
    if(args.Length==2 && args[0]=="--ui-audit")return UiAudit.Run(args[1]);
    if(args.Length!=0)return 2;
    return new Application().Run(new Workspace().Window);
   }catch(Exception e){if(args.Length>0){Console.Error.WriteLine(e);return 1;}MessageBox.Show("SheetClean could not start. "+e.Message,"SheetClean",MessageBoxButton.OK,MessageBoxImage.Error);return 1;}
  }
 }
 public sealed class ColumnChoice {public int Index{get;set;}public string Name{get;set;}}
 public sealed class Workspace {
  public Window Window;public Dataset Data;public CleanResult Result;public bool Stale,Exported;
  public Task CurrentOperation=Task.FromResult(true);CancellationTokenSource cancellation;TaskCompletionSource<bool> finished;bool updating,closing,darkMode;int themeRevision;
  public bool Busy{get{return cancellation!=null;}}
  public T Get<T>(string name) where T:class{return Window.FindName(name) as T;}
  public Workspace() {
   using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("Main.xaml"))Window=(Window)XamlReader.Load(s);
   using(var icon=Assembly.GetExecutingAssembly().GetManifestResourceStream("app.ico"))if(icon!=null)Window.Icon=BitmapFrame.Create(icon,BitmapCreateOptions.PreservePixelFormat,BitmapCacheOption.OnLoad);
   Window.Width=Math.Min(Window.Width,SystemParameters.WorkArea.Width);Window.Height=Math.Min(Window.Height,SystemParameters.WorkArea.Height);ApplyTheme();SystemParameters.StaticPropertyChanged+=ThemeChanged;Window.Loaded+=delegate{StartAnimations();};
   Get<Button>("ThemeToggle").Click+=delegate{ToggleTheme();};
   Get<Button>("OpenButton").Click+=delegate{Open();};Get<Button>("SampleButton").Click+=delegate{if(ConfirmDiscard())CurrentOperation=LoadSample();};
   Get<Button>("ClearButton").Click+=delegate{if(ConfirmDiscard())Clear();};
   Get<Button>("AnalyzeButton").Click+=delegate{CurrentOperation=Analyze();};
   Get<Button>("CancelButton").Click+=delegate{if(cancellation!=null){cancellation.Cancel();SetStatus("Cancelling…");}};
   foreach(string n in new[]{"TrimRule","DuplicatesRule","BlankRule","FormulaRule"}){Get<CheckBox>(n).Checked+=RuleChanged;Get<CheckBox>(n).Unchecked+=RuleChanged;}
   Get<ListBox>("RequiredColumns").SelectionChanged+=delegate{Invalidate();};
   Get<Button>("ExportButton").Click+=delegate{Save(false);};Get<Button>("LogButton").Click+=delegate{Save(true);};
   Window.Closing+=async delegate(object sender,System.ComponentModel.CancelEventArgs e){
    if(Busy){e.Cancel=true;if(closing)return;closing=true;cancellation.Cancel();await finished.Task;closing=false;Window.Close();return;}
    if(!ConfirmDiscard())e.Cancel=true;
   };
   Window.Closed+=delegate{SystemParameters.StaticPropertyChanged-=ThemeChanged;};
  }
  void ThemeChanged(object sender,System.ComponentModel.PropertyChangedEventArgs e){if(e.PropertyName=="HighContrast")Window.Dispatcher.BeginInvoke(new Action(ApplyTheme));}
  void ApplyTheme(){SetTheme(darkMode,false);}
  internal void SetTheme(bool nightMode,bool animate){
   int revision=++themeRevision;
   darkMode=nightMode;
   animate=animate&&SystemParameters.ClientAreaAnimation&&!SystemParameters.HighContrast;
   string[] keys={"Canvas","Surface","Glass","Ink","Muted","Accent","Accent2","OnAccent","Line","Tint","Warning","ThemeSurface","ThemeLine","ThemeInk"};
   string[] light={"#F5FAFD","#F2FFFFFF","#CFFFFFFF","#102A43","#475569","#0EA5E9","#059669","#06263A","#9DBDD0","#DFF2FCF8","#A65D11","#FFFFFF","#D4D4D4","#111111"};
   string[] night={"#081827","#132B3E","#CC14283B","#EAF6FD","#A8BFCE","#49C5F3","#61D7AD","#062032","#3A6177","#243F55","#F6C46B","#111111","#303030","#F4F4F5"};
   Brush[] high={SystemColors.WindowBrush,SystemColors.WindowBrush,SystemColors.WindowBrush,SystemColors.WindowTextBrush,SystemColors.WindowTextBrush,SystemColors.HighlightBrush,SystemColors.HighlightBrush,SystemColors.HighlightTextBrush,SystemColors.WindowTextBrush,SystemColors.WindowBrush,SystemColors.WindowTextBrush,SystemColors.WindowBrush,SystemColors.WindowTextBrush,SystemColors.WindowTextBrush};
   for(int i=0;i<keys.Length;i++){
    var previous=Window.Resources[keys[i]] as SolidColorBrush;
    Color target=SystemParameters.HighContrast?((SolidColorBrush)high[i]).Color:(Color)ColorConverter.ConvertFromString((darkMode?night:light)[i]);
    // Capture the currently displayed color so an interrupted transition reverses without a jump.
    Color from=previous==null?target:previous.Color;
    var brush=new SolidColorBrush(animate?from:target);
    if(animate){
     var transition=new ColorAnimation(from,target,TimeSpan.FromMilliseconds(240)){EasingFunction=new SineEase{EasingMode=EasingMode.EaseInOut}};
     transition.Completed+=delegate{brush.Color=target;brush.BeginAnimation(SolidColorBrush.ColorProperty,null);};
     brush.BeginAnimation(SolidColorBrush.ColorProperty,transition);
    }
    Window.Resources[keys[i]]=brush;
   }
   var toggle=Get<Button>("ThemeToggle");
   toggle.ToolTip=darkMode?"Switch to light mode":"Switch to night mode";
   AutomationProperties.SetName(toggle,(string)toggle.ToolTip);
   FadeThemeIcon(Get<ShapePath>("MoonIcon"),!darkMode,animate,revision);
   FadeThemeIcon(Get<ShapePath>("SunIcon"),darkMode,animate,revision);
  }
  void FadeThemeIcon(ShapePath icon,bool show,bool animate,int revision){
   double from=icon.Opacity;
   icon.BeginAnimation(UIElement.OpacityProperty,null);
   double target=show?1:0;
   icon.Opacity=animate?from:target;
   if(animate){
    var transition=new DoubleAnimation(from,target,TimeSpan.FromMilliseconds(180)){EasingFunction=new SineEase{EasingMode=EasingMode.EaseInOut}};
    transition.Completed+=delegate{if(revision!=themeRevision)return;icon.Opacity=target;icon.BeginAnimation(UIElement.OpacityProperty,null);};
    icon.BeginAnimation(UIElement.OpacityProperty,transition);
   }
  }
  void StartAnimations(){if(!SystemParameters.ClientAreaAnimation||SystemParameters.HighContrast)return;var content=Get<StackPanel>("RootContent");if(content!=null){content.Opacity=1;content.BeginAnimation(UIElement.OpacityProperty,new DoubleAnimation(0,1,new Duration(TimeSpan.FromMilliseconds(260))){EasingFunction=new QuadraticEase{EasingMode=EasingMode.EaseOut},FillBehavior=FillBehavior.Stop});}var glow=Get<FrameworkElement>("AccentGlow");if(glow!=null)glow.BeginAnimation(UIElement.OpacityProperty,new DoubleAnimation(0.08,0.16,new Duration(TimeSpan.FromSeconds(2))){AutoReverse=true,RepeatBehavior=RepeatBehavior.Forever,EasingFunction=new SineEase{EasingMode=EasingMode.EaseInOut}});}
  void ToggleTheme(){SetTheme(!darkMode,true);}
  bool ConfirmDiscard(){return Result==null || Exported || MessageBox.Show(Window,"Discard the current analysis without exporting a cleaned copy? Your original file is unchanged.","Keep your reviewed work",MessageBoxButton.YesNo,MessageBoxImage.Question,MessageBoxResult.No)==MessageBoxResult.Yes;}
  void RuleChanged(object sender,RoutedEventArgs e){Invalidate();}
  public void Invalidate(){if(updating)return;Get<TextBlock>("FormulaNotice").Text=Get<CheckBox>("FormulaRule").IsChecked==true?"Text prefixes change exported values, including negative-looking numbers. Review the Cleaned preview and Changes before exporting.":"Protection is OFF. Spreadsheet applications may interpret formula-like values. Export only if you understand the destination's import behavior.";if(Result!=null){Stale=true;Get<TextBlock>("SummaryTitle").Text="Rules changed — analyze again";Get<TextBlock>("CleanHint").Text="STALE PREVIEW. Run Analyze changes to apply the new rules.";Get<TextBlock>("ExportStatus").Text="Export is disabled until the current rules are analyzed.";}UpdateButtons();}
  public CleanOptions Options(){return new CleanOptions{Trim=Get<CheckBox>("TrimRule").IsChecked==true,RemoveDuplicates=Get<CheckBox>("DuplicatesRule").IsChecked==true,RemoveBlank=Get<CheckBox>("BlankRule").IsChecked==true,ProtectFormulas=Get<CheckBox>("FormulaRule").IsChecked==true,Required=Get<ListBox>("RequiredColumns").SelectedItems.Cast<ColumnChoice>().Select(x=>x.Index).ToArray()};}
  void Begin(string text){cancellation=new CancellationTokenSource();finished=new TaskCompletionSource<bool>();SetStatus(text);UpdateButtons();}
  void End(){cancellation.Dispose();cancellation=null;UpdateButtons();finished.TrySetResult(true);}
  void SetStatus(string text){Get<TextBlock>("Status").Text=text;}
  void UpdateButtons(){
   foreach(string n in new[]{"OpenButton","SampleButton"})Get<Button>(n).IsEnabled=!Busy;
   Get<Expander>("ImportOptions").IsEnabled=!Busy;Get<Button>("ClearButton").IsEnabled=!Busy&&Data!=null;
   Get<StackPanel>("RulePanel").IsEnabled=!Busy&&Data!=null;Get<Button>("AnalyzeButton").IsEnabled=!Busy&&Data!=null;
   Get<Button>("CancelButton").Visibility=Busy?Visibility.Visible:Visibility.Collapsed;
   Get<Button>("ExportButton").IsEnabled=Get<Button>("LogButton").IsEnabled=!Busy&&Result!=null&&!Stale;
  }
  void Open(){if(Busy||!ConfirmDiscard())return;try{var d=new OpenFileDialog{Title="Open a local CSV or TSV",Filter="Delimited text (*.csv;*.tsv)|*.csv;*.tsv",Multiselect=false,CheckFileExists=true};if(d.ShowDialog(Window)==true)CurrentOperation=LoadPath(d.FileName);}catch(Exception e){SetStatus("Could not open the file picker. "+e.Message);}}
  public async Task LoadPath(string path){if(Busy)return;int delimiter=Get<ComboBox>("DelimiterInput").SelectedIndex;char? chosen=delimiter==0?(char?)null:new[]{',',';','\t','|'}[delimiter-1];bool header=Get<CheckBox>("HeaderInput").IsChecked==true,legacy=Get<ComboBox>("EncodingInput").SelectedIndex==1;Begin("Reading and validating the file…");try{var d=await Task.Run(()=>Files.Load(path,chosen,header,legacy,cancellation.Token));cancellation.Token.ThrowIfCancellationRequested();SetData(d);SetStatus("Import complete. Choose cleaning rules and analyze changes.");}catch(OperationCanceledException){SetStatus("Import cancelled. The previous workspace is unchanged.");}catch(Exception e){SetStatus("Import failed: "+e.Message+" The previous workspace is unchanged.");}finally{End();}}
  public async Task LoadSample(){if(Busy)return;Begin("Loading sample data…");try{var d=await Task.Run(()=>Csv.Parse(Cleaner.Sample,',',true,cancellation.Token));cancellation.Token.ThrowIfCancellationRequested();d.DisplayName="Sample client list (fictional)";d.EncodingName="Built-in UTF-8 sample";SetData(d);SetStatus("Fictional sample loaded. Try duplicate removal and select Email as required.");}catch(OperationCanceledException){SetStatus("Sample loading cancelled.");}catch(Exception e){SetStatus("Sample could not load: "+e.Message);}finally{End();}}
  public void SetData(Dataset data){Data=data;Result=null;Stale=false;Exported=false;updating=true;
   Get<ListBox>("RequiredColumns").ItemsSource=Enumerable.Range(0,data.Columns).Select(i=>new ColumnChoice{Index=i,Name=Short(data.Label(i),80)}).ToList();
   updating=false;Get<TextBlock>("FileSummary").Text=data.DisplayName+"\n"+data.Rows.Count+" data rows · "+data.Columns+" columns · "+Csv.DelimiterName(data.Delimiter)+" · "+data.EncodingName+(data.HasHeader?" · Header record":" · No header record");
   FillData(Get<DataGrid>("OriginalGrid"),data.Rows,data.Headers,Enumerable.Range(0,data.Rows.Count).Select(data.Record).ToArray());
   foreach(string n in new[]{"CleanGrid","IssuesGrid","ChangesGrid"}){Get<DataGrid>(n).ItemsSource=null;Get<DataGrid>(n).Columns.Clear();}
   Get<TextBlock>("OriginalHint").Text=PreviewHint(data.Rows.Count,data.Columns);Get<TextBlock>("CleanHint").Text="Analyze changes to build the export preview.";
   Get<TextBlock>("IssuesHint").Text="Run analysis to find issues.";Get<TextBlock>("ChangesHint").Text="Run analysis to list proposed changes.";
   Get<TextBlock>("SummaryTitle").Text="File loaded — ready to analyze";Get<TextBlock>("SummaryDetail").Text="The original remains unchanged. Required fields are flagged, never filled automatically.";Get<TextBlock>("ExportStatus").Text="";UpdateButtons();}
  public async Task Analyze(){if(Busy||Data==null)return;var options=Options();var source=Data;Begin("Analyzing every row and preparing a change log…");try{var r=await Task.Run(()=>Cleaner.Analyze(source,options,cancellation.Token));cancellation.Token.ThrowIfCancellationRequested();Result=r;Stale=false;Exported=false;RenderResult();SetStatus("Analysis complete. Review the preview, issues, and changes before exporting.");}catch(OperationCanceledException){SetStatus("Analysis cancelled. The previous completed result is retained.");}catch(Exception e){SetStatus("Analysis failed: "+e.Message);}finally{End();}}
  void RenderResult(){var r=Result;FillData(Get<DataGrid>("CleanGrid"),r.Rows,r.Headers,r.SourceRecords.ToArray());
   Get<TextBlock>("CleanHint").Text=PreviewHint(r.Rows.Count,r.Headers.Length)+" Displayed values match the proposed export, including text prefixes.";
   FillRecords(Get<DataGrid>("IssuesGrid"),r.Issues.Take(500).Cast<object>().ToArray(),new[]{"Record","Column","Kind","Detail"});
   FillRecords(Get<DataGrid>("ChangesGrid"),r.Changes.Take(500).Cast<object>().ToArray(),new[]{"Record","Column","Action","Before","After"});
   Get<TextBlock>("IssuesHint").Text=r.Issues.Count+" items; showing the first "+Math.Min(500,r.Issues.Count)+". Missing values are retained. Full details are available in the JSON log.";
   Get<TextBlock>("ChangesHint").Text=r.Changes.Count+" change events; showing the first "+Math.Min(500,r.Changes.Count)+". Record numbers refer to original CSV records (a header is record 1). Long values are shortened here; the JSON log retains them.";
   Get<TextBlock>("SummaryTitle").Text=r.Rows.Count+" rows ready for review · "+r.Removed+" removed";
   Get<TextBlock>("SummaryDetail").Text=r.TrimmedCells+" trimmed cells / "+r.Duplicates+" duplicate rows / "+r.BlankRows+" blank rows / "+r.MissingCells+" missing required values / "+r.ProtectedCells+" text prefixes";
   Get<TextBlock>("ExportStatus").Text="Original protected. Export creates a separate copy. The log can contain original client data.";
  }
  static string PreviewHint(int rows,int columns){return "Showing "+Math.Min(200,rows)+" of "+rows+" rows and "+Math.Min(40,columns)+" of "+columns+" columns. Cell previews are limited to 120 characters. Analysis and export include all data.";}
  public static string Short(string s,int n){s=s??"";return s.Length<=n?s:s.Substring(0,n)+"…";}
  static void FillData(DataGrid grid,System.Collections.Generic.List<string[]> rows,string[] headers,int[] records){
   var t=new DataTable();t.Columns.Add("R",typeof(string));grid.Columns.Clear();grid.Columns.Add(Col("Source record","R",100));
   for(int c=0;c<Math.Min(40,headers.Length);c++){string key="C"+c;t.Columns.Add(key,typeof(string));grid.Columns.Add(Col((c+1)+" · "+Short(String.IsNullOrWhiteSpace(headers[c])?"Unnamed":headers[c],50),key,190));}
   for(int i=0;i<Math.Min(200,rows.Count);i++){var r=t.NewRow();r[0]=records[i].ToString();for(int c=0;c<t.Columns.Count-1;c++)r[c+1]=Short(rows[i][c],120);t.Rows.Add(r);}grid.ItemsSource=t.DefaultView;
  }
  static DataGridTextColumn Col(string name,string key,int width){return new DataGridTextColumn{Header=name,Binding=new Binding(key),Width=width};}
  static void FillRecords(DataGrid grid,object[] values,string[] props){var t=new DataTable();grid.Columns.Clear();foreach(string p in props){t.Columns.Add(p,typeof(string));grid.Columns.Add(Col(p,p,p=="Record"?80:220));}foreach(var value in values){t.Rows.Add(props.Select(p=>Short(Convert.ToString(value.GetType().GetProperty(p).GetValue(value,null)),200)).ToArray());}grid.ItemsSource=t.DefaultView;}
  void Save(bool log){if(Busy||Result==null||Stale)return;try{bool tab=Data.Delimiter=='\t';var d=new SaveFileDialog{Title=log?"Save SheetClean change log":"Export a cleaned copy",Filter=log?"JSON change log (*.json)|*.json":tab?"Tab-separated file (*.tsv)|*.tsv":"CSV file (*.csv)|*.csv",DefaultExt=log?".json":tab?".tsv":".csv",AddExtension=true,OverwritePrompt=true,FileName=log?"SheetClean-changes.json":tab?"SheetClean-cleaned.tsv":"SheetClean-cleaned.csv"};if(d.ShowDialog(Window)==true)CurrentOperation=ExportPath(d.FileName,log);}catch(Exception e){Get<TextBlock>("ExportStatus").Text="Export could not start: "+e.Message;}}
  public async Task ExportPath(string path,bool log){if(Busy||Result==null||Stale)return;var r=Result;Begin(log?"Saving the complete change log…":"Writing a new cleaned copy…");try{await Task.Run(()=>Files.Export(path,r,log,cancellation.Token));if(!log)Exported=true;Get<TextBlock>("ExportStatus").Text="Saved "+path;SetStatus("Export complete. Your source file is unchanged.");}catch(OperationCanceledException){SetStatus("Export cancelled before commit. No partial output was kept.");}catch(Exception e){Get<TextBlock>("ExportStatus").Text="Export failed: "+e.Message;SetStatus("Export did not complete. The existing destination was preserved if replacement failed.");}finally{End();}}
  public void Clear(){if(Busy)return;updating=true;Data=null;Result=null;Stale=false;Exported=false;Get<ListBox>("RequiredColumns").ItemsSource=null;foreach(string n in new[]{"OriginalGrid","CleanGrid","IssuesGrid","ChangesGrid"}){Get<DataGrid>(n).ItemsSource=null;Get<DataGrid>(n).Columns.Clear();}updating=false;Get<TextBlock>("FileSummary").Text="No file loaded.";Get<TextBlock>("SummaryTitle").Text="Workspace cleared";Get<TextBlock>("SummaryDetail").Text="No automatic history is kept. Your original file and exported copies are unchanged.";foreach(string n in new[]{"OriginalHint","CleanHint","IssuesHint","ChangesHint","ExportStatus"})Get<TextBlock>(n).Text="";SetStatus("Open another CSV or load the sample.");UpdateButtons();}
 }
}
