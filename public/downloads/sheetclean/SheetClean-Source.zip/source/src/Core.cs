using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

namespace SheetClean {
 public sealed class Dataset {
  public string[] Headers; public List<string[]> Rows; public bool HasHeader; public char Delimiter;
  public string EncodingName,SourcePath,SourceIdentity,DisplayName;
  public int Columns { get { return Headers.Length; } }
  public int Record(int index) { return index+(HasHeader?2:1); }
  string[] labels;
  public string Label(int col) { if(labels==null)labels=new string[Columns];if(labels[col]==null){string name=String.IsNullOrWhiteSpace(Headers[col])?"Unnamed column":Headers[col];labels[col]=(col+1)+" · "+(name.Length>120?name.Substring(0,120)+"…":name);}return labels[col]; }
 }
 public static class Csv {
  public const int MaxBytes=10*1024*1024,MaxRows=50000,MaxColumns=100,MaxCells=250000,MaxField=32768;
  public static bool ValidDelimiter(char c) { return c==',' || c==';' || c=='\t' || c=='|'; }
  public static string DelimiterName(char c) { return c=='\t'?"Tab":c==','?"Comma":c==';'?"Semicolon":"Pipe"; }
  public static Dataset Parse(string text,char delimiter,bool headers,CancellationToken token) {
   if(!ValidDelimiter(delimiter)) throw new InvalidDataException("Choose comma, semicolon, tab, or pipe.");
   if(text==null || text.Length==0) throw new InvalidDataException("The file is empty. Choose a file containing at least one record.");
   if(text.Length>MaxBytes) throw new InvalidDataException("Decoded text exceeds the 10 MiB character limit. Split the file.");
   var records=new List<string[]>();var row=new List<string>();var field=new StringBuilder();int state=0,line=1,cells=0;bool pending=false;
   Action addField=()=>{row.Add(field.ToString());field.Clear();if(row.Count>MaxColumns) throw new InvalidDataException("More than 100 columns. Split the file into narrower tables.");};
   Action addRow=()=>{
    addField();cells+=row.Count;
    if(records.Count>0 && row.Count!=records[0].Length) throw new InvalidDataException("Record "+(records.Count+1)+" near line "+line+" has "+row.Count+" fields; expected "+records[0].Length+". Check the delimiter and quoting.");
    if(cells>MaxCells || records.Count>=MaxRows+(headers?1:0)) throw new InvalidDataException("This file exceeds 50,000 data rows or 250,000 total cells. Split the file.");
    records.Add(row.ToArray());row.Clear();pending=false;
   };
   for(int i=0;i<text.Length;i++) {
    if((i&1023)==0) token.ThrowIfCancellationRequested();char c=text[i];
    if(Char.IsControl(c) && c!='\t' && c!='\r' && c!='\n') throw new InvalidDataException("Unsupported control character near line "+line+". Use a plain-text CSV file.");
    if(state==1) {
     if(c=='"') { if(i+1<text.Length && text[i+1]=='"') {field.Append('"');i++;} else state=2; }
     else {field.Append(c);if(c=='\n' || (c=='\r' && (i+1==text.Length || text[i+1]!='\n'))) line++;}
    } else if(c==delimiter) {addField();state=0;pending=true;}
    else if(c=='\r' || c=='\n') {addRow();state=0;if(c=='\r' && i+1<text.Length && text[i+1]=='\n')i++;line++;}
    else if(state==2) throw new InvalidDataException("Unexpected character after a closing quote near line "+line+". A delimiter or record ending is required.");
    else if(c=='"') {if(field.Length!=0) throw new InvalidDataException("Quote inside an unquoted field near line "+line+". Quote the entire field and escape embedded quotes.");state=1;pending=true;}
    else {field.Append(c);pending=true;}
    if(field.Length>MaxField) throw new InvalidDataException("A field exceeds 32,768 characters. Shorten or split this data.");
   }
   token.ThrowIfCancellationRequested();
   if(state==1) throw new InvalidDataException("An opening quote has no closing quote near line "+line+".");
   if(pending || row.Count>0 || field.Length>0) addRow();
   if(records.Count==0) throw new InvalidDataException("No CSV records were found.");
   int n=records[0].Length;
   return new Dataset {Headers=headers?records[0]:Enumerable.Range(1,n).Select(x=>"Column "+x).ToArray(),Rows=headers?records.Skip(1).ToList():records,HasHeader=headers,Delimiter=delimiter,EncodingName="Text",DisplayName="In-memory data"};
  }
  public static char Detect(string text,CancellationToken token) {
   var counts=new Dictionary<char,List<int>>();foreach(char d in new[]{',',';','\t','|'}) counts[d]=new List<int>();
   var current=counts.Keys.ToDictionary(x=>x,x=>0);bool quoted=false;int records=0;
   for(int i=0;i<text.Length && records<30;i++) {
    if((i&1023)==0)token.ThrowIfCancellationRequested();char c=text[i];
    if(c=='"') {if(quoted && i+1<text.Length && text[i+1]=='"')i++;else quoted=!quoted;}
    else if(!quoted && current.ContainsKey(c))current[c]++;
    else if(!quoted && (c=='\n'||c=='\r')) {foreach(char d in counts.Keys){counts[d].Add(current[d]);current[d]=0;}records++;if(c=='\r'&&i+1<text.Length&&text[i+1]=='\n')i++;}
   }
   if(records==0 || current.Values.Any(x=>x>0))foreach(char d in counts.Keys)counts[d].Add(current[d]);
   var candidates=counts.Where(x=>x.Value.Count>0 && x.Value[0]>0 && x.Value.All(n=>n==x.Value[0])).Select(x=>x.Key).ToArray();
   if(candidates.Length==1)return candidates[0];
   if(candidates.Length>1)throw new InvalidDataException("Delimiter detection is ambiguous. Choose the delimiter explicitly and open the file again.");
   if(counts.Values.Any(x=>x.Any(n=>n>0)))throw new InvalidDataException("Delimiter detection found uneven records. Choose the delimiter explicitly to get a precise parsing error.");
   return ',';
  }
  public static string Row(IEnumerable<string> values,char delimiter) {return String.Join(delimiter.ToString(),values.Select(x=>"\""+(x??"").Replace("\"","\"\"")+"\"").ToArray());}
  public static string Serialize(Dataset d,IEnumerable<string[]> rows,string[] headers) {
   var b=new StringBuilder();if(d.HasHeader)b.Append(Row(headers,d.Delimiter)).Append("\r\n");foreach(var row in rows)b.Append(Row(row,d.Delimiter)).Append("\r\n");return b.ToString();
  }
 }
 public sealed class CleanOptions {
  public bool Trim=true,RemoveDuplicates=false,RemoveBlank=false,ProtectFormulas=true;
  public int[] Required=new int[0];
  public CleanOptions Copy() {return new CleanOptions{Trim=Trim,RemoveDuplicates=RemoveDuplicates,RemoveBlank=RemoveBlank,ProtectFormulas=ProtectFormulas,Required=(int[])Required.Clone()};}
 }
 public sealed class Change {
  public int Record {get;set;} public string Column {get;set;} public string Action {get;set;} public string Before {get;set;} public string After {get;set;}
 }
 public sealed class Issue {
  public int Record {get;set;} public string Column {get;set;} public string Kind {get;set;} public string Detail {get;set;}
 }
 public sealed class CleanResult {
  public Dataset Source; public CleanOptions Options; public List<string[]> Rows=new List<string[]>();public List<int> SourceRecords=new List<int>();
  public string[] Headers;public List<Change> Changes=new List<Change>();public List<Issue> Issues=new List<Issue>();
  public int Removed,Duplicates,BlankRows,MissingCells,TrimmedCells,ProtectedCells; public string AnalyzedUtc=DateTime.UtcNow.ToString("o");
 }
 public sealed class RowComparer:IEqualityComparer<string[]> {
  public bool Equals(string[] a,string[] b) {return a.Length==b.Length && a.SequenceEqual(b,StringComparer.Ordinal);}
  public int GetHashCode(string[] values) {unchecked{int h=17;foreach(string v in values)h=h*31+StringComparer.Ordinal.GetHashCode(v);return h;}}
 }
 public static class Cleaner {
  public static bool FormulaLike(string s) {
   if(String.IsNullOrEmpty(s))return false;
   if(s[0]=='\t'||s[0]=='\r'||s[0]=='\n')return true;
   int i=0;while(i<s.Length && (Char.IsWhiteSpace(s[i]) || CharUnicodeInfo.GetUnicodeCategory(s[i])==UnicodeCategory.Format))i++;
   return i<s.Length && "=+-@＝＋－＠".IndexOf(s[i])>=0;
  }
  static string Protect(CleanResult r,int record,string col,string value) {
   if(!FormulaLike(value))return value;
   r.Issues.Add(new Issue{Record=record,Column=col,Kind=r.Options.ProtectFormulas?"Text prefix applied":"Formula-like value",Detail=r.Options.ProtectFormulas?"Export adds an apostrophe so the value is marked as text. Check behavior in your spreadsheet app.":"Spreadsheet software may treat this value as a formula. Protection is off."});
   if(!r.Options.ProtectFormulas)return value;
   r.ProtectedCells++;string next="'"+value;r.Changes.Add(new Change{Record=record,Column=col,Action="Text prefix",Before=value,After=next});return next;
  }
  public static CleanResult Analyze(Dataset source,CleanOptions options,CancellationToken token) {
   token.ThrowIfCancellationRequested();
   if(options.Required==null || options.Required.Any(x=>x<0 || x>=source.Columns))throw new InvalidDataException("A required-column selection is invalid. Reload the file.");
   var r=new CleanResult{Source=source,Options=options.Copy(),Headers=(string[])source.Headers.Clone()};var seen=new Dictionary<string[],int>(new RowComparer());
   if(source.HasHeader)for(int c=0;c<r.Headers.Length;c++)r.Headers[c]=Protect(r,1,source.Label(c),r.Headers[c]);
   for(int row=0;row<source.Rows.Count;row++) {
    token.ThrowIfCancellationRequested();var input=source.Rows[row];var values=new string[input.Length];int record=source.Record(row);
    for(int c=0;c<input.Length;c++) {
     values[c]=options.Trim?input[c].Trim():input[c];
     if(values[c]!=input[c]){r.TrimmedCells++;r.Changes.Add(new Change{Record=record,Column=source.Label(c),Action="Trim whitespace",Before=input[c],After=values[c]});}
    }
    bool blank=values.All(String.IsNullOrWhiteSpace);
    if(blank)r.BlankRows++;
    if(blank && options.RemoveBlank){Remove(r,record,input,"Remove blank row");continue;}
    int first;bool duplicate=seen.TryGetValue(values,out first);
    if(duplicate) {
     r.Duplicates++;r.Issues.Add(new Issue{Record=record,Column="All columns",Kind=options.RemoveDuplicates?"Duplicate removed":"Duplicate retained",Detail="Matches source record "+first+" after the selected trim rule; comparison is case-sensitive."});
     if(options.RemoveDuplicates){Remove(r,record,input,"Remove duplicate (first record "+first+")");continue;}
    } else seen.Add(values,record);
    foreach(int c in options.Required.Distinct())if(String.IsNullOrWhiteSpace(values[c])){r.MissingCells++;r.Issues.Add(new Issue{Record=record,Column=source.Label(c),Kind="Missing required value",Detail="Row is retained. Review the original data; SheetClean does not invent a replacement."});}
    var output=new string[values.Length];for(int c=0;c<values.Length;c++)output[c]=Protect(r,record,source.Label(c),values[c]);
    r.Rows.Add(output);r.SourceRecords.Add(record);
   }
   token.ThrowIfCancellationRequested();return r;
  }
  static void Remove(CleanResult r,int record,string[] before,string reason){r.Removed++;r.Changes.Add(new Change{Record=record,Column="All columns",Action=reason,Before=Csv.Row(before,r.Source.Delimiter),After="(row removed)"});}
  public const string Sample="Client ID,Name,Email,Notes\r\n001,  Avery Lee  ,avery@example.test, Follow up Friday \r\n002,Jordan Moss,,Needs an email address\r\n001,Avery Lee,avery@example.test,Follow up Friday\r\n003,Sam Rivera,sam@example.test,\"Prefers email, not phone\"\r\n,,,\r\n004,Casey Noor,casey@example.test,=1+1\r\n005,Riley Park,riley@example.test,\"Line one\nLine two\"\r\n";
 }
}
