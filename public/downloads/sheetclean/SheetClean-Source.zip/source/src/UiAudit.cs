using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using ShapePath = System.Windows.Shapes.Path;
namespace SheetClean {
 public static class UiAudit {
  public static int Run(string output){output=Path.GetFullPath(output);Directory.CreateDirectory(output);var log=new AuditLog();var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};
   app.Startup+=async delegate {Workspace ui=null;try{
    ui=new Workspace();ui.Window.Show();await Task.Delay(150);
    log.Check("cold start and disabled actions",ui.Window.IsVisible&&!ui.Get<Button>("AnalyzeButton").IsEnabled&&!ui.Get<Button>("ExportButton").IsEnabled);
    var theme=ui.Get<Button>("ThemeToggle");
    var moon=ui.Get<ShapePath>("MoonIcon");var sun=ui.Get<ShapePath>("SunIcon");
    var viewport=ui.Get<Viewbox>("ThemeIconViewport");
    ui.Window.UpdateLayout();
    var center=viewport.TranslatePoint(new Point(viewport.ActualWidth/2,viewport.ActualHeight/2),theme);
    log.Check("theme icons centered in compact circular button",Math.Abs(theme.ActualWidth-38)<1&&Math.Abs(theme.ActualHeight-38)<1&&Math.Abs(center.X-theme.ActualWidth/2)<1&&Math.Abs(center.Y-theme.ActualHeight/2)<1);
    log.Check("outlined icons fit shared drawing area",new Rect(0,0,24,24).Contains(moon.Data.GetRenderBounds(new Pen(Brushes.Black,moon.StrokeThickness)))&&new Rect(0,0,24,24).Contains(sun.Data.GetRenderBounds(new Pen(Brushes.Black,sun.StrokeThickness)))&&((SolidColorBrush)moon.Fill).Color.A==0);
    bool motion=SystemParameters.ClientAreaAnimation&&!SystemParameters.HighContrast;
    Click(theme);
    await Task.Delay(90);
    var middle=((SolidColorBrush)ui.Window.Resources["Canvas"]).Color;
    log.Check("theme colors interpolate without fading the whole page",(!motion||(middle.R>8&&middle.R<245))&&ui.Get<Grid>("Shell").Opacity==1);
    log.Check("moon and sun crossfade during transition",!motion||(moon.Opacity>0&&moon.Opacity<1&&sun.Opacity>0&&sun.Opacity<1));
    Shot(ui,Path.Combine(output,"sheetclean-transition.png"));
    await Task.Delay(250);
    log.Check("night mode toggles semantic palette ["+AutomationProperties.GetName(theme)+"; sun="+sun.Opacity+"; moon="+moon.Opacity+"; canvas="+((SolidColorBrush)ui.Window.Resources["Canvas"]).Color+"; enabled="+theme.IsEnabled+"]",AutomationProperties.GetName(theme)=="Switch to light mode"&&sun.Opacity==1&&moon.Opacity==0&&((SolidColorBrush)ui.Window.Resources["Canvas"]).Color==Color.FromRgb(8,24,39)&&theme.IsEnabled);
    Shot(ui,Path.Combine(output,"sheetclean-night.png"));ShotTheme(theme,Path.Combine(output,"theme-sun.png"));
    Click(theme);await Task.Delay(320);
    log.Check("light mode restores palette",AutomationProperties.GetName(theme)=="Switch to night mode"&&moon.Opacity==1&&sun.Opacity==0&&((SolidColorBrush)ui.Window.Resources["Canvas"]).Color==Color.FromRgb(245,250,253));
    ShotTheme(theme,Path.Combine(output,"theme-moon.png"));
    Click(theme);await Task.Delay(70);
    var beforeReverse=((SolidColorBrush)ui.Window.Resources["Canvas"]).Color;
    Click(theme);
    var afterReverse=((SolidColorBrush)ui.Window.Resources["Canvas"]).Color;
    log.Check("interrupted transition reverses from current color",!motion||beforeReverse==afterReverse);
    for(int click=0;click<6;click++){Click(theme);await Task.Delay(30);}
    await Task.Delay(320);
    log.Check("rapid toggles honor final click without disabling control",theme.IsEnabled&&moon.Opacity==1&&sun.Opacity==0&&AutomationProperties.GetName(theme)=="Switch to night mode"&&((SolidColorBrush)ui.Window.Resources["Canvas"]).Color==Color.FromRgb(245,250,253));
    theme.Focus();ui.Window.UpdateLayout();
    log.Check("theme button has keyboard focus feedback and accessible action",theme.IsKeyboardFocused&&((FrameworkElement)theme.Template.FindName("FocusRing",theme)).Visibility==Visibility.Visible&&new ButtonAutomationPeer(theme).GetName()=="Switch to night mode");
    Click(theme);await Task.Delay(40);ui.SetTheme(false,false);
    log.Check("nonanimated theme change cancels in-flight animation",((SolidColorBrush)ui.Window.Resources["Canvas"]).Color==Color.FromRgb(245,250,253)&&moon.Opacity==1&&sun.Opacity==0);
    await Task.Delay(320);
    log.Check("completed animations cannot overwrite nonanimated selection",((SolidColorBrush)ui.Window.Resources["Canvas"]).Color==Color.FromRgb(245,250,253)&&sun.Opacity==0);
    ui.Get<Button>("OpenButton").Focus();
    Shot(ui,Path.Combine(output,"sheetclean-ready.png"));
    Click(ui.Get<Button>("SampleButton"));await ui.CurrentOperation;
    log.Check("sample button imports seven fictional rows",ui.Data.Rows.Count==7&&ui.Get<Button>("AnalyzeButton").IsEnabled);
    ui.Get<CheckBox>("DuplicatesRule").IsChecked=true;ui.Get<CheckBox>("BlankRule").IsChecked=true;
    ui.Get<ListBox>("RequiredColumns").SelectedIndex=2;
    Click(ui.Get<Button>("AnalyzeButton"));var pending=ui.CurrentOperation;
    log.Check("loading disables duplicate actions",ui.Busy&&!ui.Get<Button>("OpenButton").IsEnabled&&!ui.Get<Button>("AnalyzeButton").IsEnabled);
    await ui.Analyze();await pending;
    log.Check("analysis and required field selection",ui.Result.Rows.Count==5&&ui.Result.MissingCells==1&&ui.Get<Button>("ExportButton").IsEnabled);
    log.Check("all review tables populate",new[]{"OriginalGrid","CleanGrid","IssuesGrid","ChangesGrid"}.All(n=>ui.Get<DataGrid>(n).Items.Count>0));
    ui.Get<CheckBox>("TrimRule").IsChecked=false;
    log.Check("changed rules invalidate export",ui.Stale&&!ui.Get<Button>("ExportButton").IsEnabled&&ui.Get<TextBlock>("CleanHint").Text.StartsWith("STALE"));
    await ui.ExportPath(Path.Combine(output,"stale.csv"),false);log.Check("stale result cannot export",!File.Exists(Path.Combine(output,"stale.csv")));
    ui.Get<CheckBox>("TrimRule").IsChecked=true;await ui.Analyze();
    await ui.ExportPath(Path.Combine(output,"ui-cleaned.csv"),false);await ui.ExportPath(Path.Combine(output,"ui-changes.json"),true);
    log.Check("UI CSV and log exports finish",ui.Exported&&File.Exists(Path.Combine(output,"ui-cleaned.csv"))&&File.Exists(Path.Combine(output,"ui-changes.json")));
    var old=ui.Data;var result=ui.Result;await ui.LoadPath(Path.Combine(output,"missing.csv"));
    log.Check("failed import preserves workspace",ui.Data==old&&ui.Result==result&&ui.Get<TextBlock>("Status").Text.StartsWith("Import failed"));
    await ui.ExportPath(Path.Combine(output,"missing-directory","out.csv"),false);
    log.Check("failed export shows error and recovers",!ui.Busy&&ui.Get<TextBlock>("ExportStatus").Text.StartsWith("Export failed")&&ui.Get<Button>("ExportButton").IsEnabled);
    pending=ui.LoadSample();Click(ui.Get<Button>("CancelButton"));await pending;
    log.Check("cancel import retains previous result",ui.Data==old&&ui.Result==result&&!ui.Busy);
    log.Check("accessible primary action",new ButtonAutomationPeer(ui.Get<Button>("AnalyzeButton")).GetName().Contains("Analyze changes"));
    log.Check("accessible import fields",new ComboBoxAutomationPeer(ui.Get<ComboBox>("DelimiterInput")).GetName()=="Import delimiter");
    await ui.Analyze();var tabs=ui.Get<TabControl>("Tabs");
    foreach(int width in new[]{500,768,1140,1440})foreach(double scale in new[]{1d,1.5d,2d}){
     ui.Window.Width=width;ui.Window.Height=820;ui.Get<StackPanel>("RootContent").LayoutTransform=new ScaleTransform(scale,scale);
     for(int i=0;i<tabs.Items.Count;i++){tabs.SelectedIndex=i;ui.Window.UpdateLayout();var scroll=ui.Get<ScrollViewer>("OuterScroll");log.Check("tab "+((TabItem)tabs.Items[i]).Header+" fits width "+width+" scale "+scale,scroll.ExtentWidth<=scroll.ViewportWidth+2&&ControlsFit(ui.Get<StackPanel>("RootContent")));}
    }
    ui.Get<StackPanel>("RootContent").LayoutTransform=Transform.Identity;ui.Window.Width=1140;ui.Window.Height=900;
    for(int i=0;i<tabs.Items.Count;i++){tabs.SelectedIndex=i;ui.Window.UpdateLayout();ui.Get<ScrollViewer>("OuterScroll").ScrollToVerticalOffset(i==0?240:380);await Task.Delay(40);Shot(ui,Path.Combine(output,"sheetclean-tab-"+i+".png"));}
    ui.Window.Width=500;tabs.SelectedIndex=0;ui.Window.UpdateLayout();await Task.Delay(40);Shot(ui,Path.Combine(output,"sheetclean-narrow.png"));
    ui.Get<Expander>("ImportOptions").IsExpanded=true;ui.Window.UpdateLayout();log.Check("expanded import controls fit narrow window",ControlsFit(ui.Get<StackPanel>("RootContent")));
    ui.Clear();log.Check("clear drops in-memory data and disables actions",ui.Data==null&&ui.Result==null&&!ui.Get<Button>("ExportButton").IsEnabled&&ui.Get<DataGrid>("OriginalGrid").Items.Count==0);
    var many=Tests.Parse("a,b\n"+String.Join("\n",Enumerable.Range(0,250).Select(i=>i+",value")));many.DisplayName="Large fictional sample";ui.SetData(many);await ui.Analyze();
    log.Check("preview bound does not truncate analysis",ui.Get<DataGrid>("OriginalGrid").Items.Count==200&&ui.Get<DataGrid>("CleanGrid").Items.Count==200&&ui.Result.Rows.Count==250);
    ui.Exported=true;pending=ui.LoadSample();ui.Window.Close();await pending;await Task.Delay(100);log.Check("close cancels active operation",!ui.Busy&&!ui.Window.IsVisible);
   }catch(Exception e){log.Check("UI audit exception: "+e,false);}finally{if(ui!=null&&ui.Window.IsVisible){ui.Exported=true;ui.Window.Close();}log.Finish(Path.Combine(output,"ui-results.txt"));app.Shutdown(log.Failed==0?0:1);}};return app.Run();
  }
  static void Click(Button b){b.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));}
  static bool InTable(DependencyObject x){while(x!=null){if(x is DataGrid)return true;x=VisualTreeHelper.GetParent(x);}return false;}
  static bool ControlsFit(FrameworkElement root){return Descendants(root).OfType<FrameworkElement>().Where(x=>x.IsVisible&&!InTable(x)&&(x is Button||x is TextBlock||x is CheckBox||x is Label||x is TabItem||x is ComboBox)).All(x=>{var b=x.TransformToAncestor(root).TransformBounds(new Rect(0,0,x.ActualWidth,x.ActualHeight));return b.Left>=-2&&b.Right<=root.ActualWidth+2;});}
  static System.Collections.Generic.IEnumerable<DependencyObject> Descendants(DependencyObject root){for(int i=0;i<VisualTreeHelper.GetChildrenCount(root);i++){var child=VisualTreeHelper.GetChild(root,i);yield return child;foreach(var nested in Descendants(child))yield return nested;}}
  static void ShotTheme(FrameworkElement control,string path){var bitmap=new RenderTargetBitmap((int)control.ActualWidth*4,(int)control.ActualHeight*4,384,384,PixelFormats.Pbgra32);var visual=new DrawingVisual();using(var dc=visual.RenderOpen())dc.DrawRectangle(new VisualBrush(control){Stretch=Stretch.Fill},null,new Rect(0,0,control.ActualWidth,control.ActualHeight));bitmap.Render(visual);var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));using(var stream=File.Create(path))encoder.Save(stream);}
  static void Shot(Workspace ui,string path){ui.Window.UpdateLayout();var c=(FrameworkElement)ui.Window.Content;var b=new RenderTargetBitmap((int)Math.Ceiling(c.ActualWidth),(int)Math.Ceiling(c.ActualHeight),96,96,PixelFormats.Pbgra32);b.Render(c);var e=new PngBitmapEncoder();e.Frames.Add(BitmapFrame.Create(b));using(var s=File.Create(path))e.Save(s);}
 }
}

