using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using Microsoft.Win32.SafeHandles;

namespace SheetClean {
 public static class Files {
  [StructLayout(LayoutKind.Sequential)] struct FileInfoNative {public uint Attributes;public System.Runtime.InteropServices.ComTypes.FILETIME Created,Accessed,Written;public uint Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;}
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetFileInformationByHandle(SafeFileHandle handle,out FileInfoNative info);
  public static string Identity(FileStream s){FileInfoNative info;if(!GetFileInformationByHandle(s.SafeFileHandle,out info))throw new IOException("The file identity could not be verified. Choose a regular local file.");return info.Volume+":"+info.IndexHigh+":"+info.IndexLow;}
  public static string LocalPath(string path) {
   if(path!=null && (path.StartsWith(@"\\") || path.IndexOf(':',Math.Min(2,path.Length))>=0))throw new IOException("Use a normal local file path. Network, device, and alternate-stream paths are not supported.");
   path=Path.GetFullPath(path);
   if(path.StartsWith(@"\\") || path.IndexOf(':',2)>=0)throw new IOException("Use a normal local file path. Network, device, and alternate-stream paths are not supported.");
   var drive=new DriveInfo(Path.GetPathRoot(path));if(drive.DriveType==DriveType.Network)throw new IOException("Network drives are not supported. Copy the file locally first.");
   // Reject links and junctions to keep the local-only and source-protection boundary explicit.
   var item=new FileInfo(path) as FileSystemInfo;
   while(item!=null){if(item.Exists && (item.Attributes&FileAttributes.ReparsePoint)!=0)throw new IOException("Linked files or folders are not supported. Choose a regular local folder.");item=item is FileInfo?((FileInfo)item).Directory:((DirectoryInfo)item).Parent;}
   return path;
  }
  public static Dataset Load(string path,char? delimiter,bool header,bool legacy,CancellationToken token) {
   path=LocalPath(path);string ext=Path.GetExtension(path).ToLowerInvariant();if(ext!=".csv" && ext!=".tsv")throw new InvalidDataException("Choose a .csv or .tsv file. Excel workbooks are not supported in this release.");
   byte[] data;string id;
   using(var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read)) {
    if(f.Length>Csv.MaxBytes)throw new InvalidDataException("File exceeds 10 MiB. Split it into smaller CSV files.");
    id=Identity(f);data=new byte[(int)f.Length];int at=0;
    while(at<data.Length){token.ThrowIfCancellationRequested();int n=f.Read(data,at,Math.Min(65536,data.Length-at));if(n==0)throw new IOException("The file changed while reading. Try again.");at+=n;}
   }
   string encoding;string text=Decode(data,legacy,out encoding);var d=Csv.Parse(text,delimiter??Csv.Detect(text,token),header,token);
   d.SourcePath=path;d.SourceIdentity=id;d.DisplayName=Path.GetFileName(path);d.EncodingName=encoding;return d;
  }
  public static string Decode(byte[] bytes,bool legacy,out string encoding) {
   Encoding codec;int skip=0;
   if(bytes.Length>=4 && ((bytes[0]==0xff&&bytes[1]==0xfe&&bytes[2]==0&&bytes[3]==0)||(bytes[0]==0&&bytes[1]==0&&bytes[2]==0xfe&&bytes[3]==0xff)))throw new InvalidDataException("UTF-32 is not supported. Save the file as UTF-8 CSV.");
   if(bytes.Length>=3&&bytes[0]==239&&bytes[1]==187&&bytes[2]==191){codec=new UTF8Encoding(false,true);skip=3;encoding="UTF-8 BOM";}
   else if(bytes.Length>=2&&bytes[0]==255&&bytes[1]==254){codec=new UnicodeEncoding(false,false,true);skip=2;encoding="UTF-16 LE BOM";}
   else if(bytes.Length>=2&&bytes[0]==254&&bytes[1]==255){codec=new UnicodeEncoding(true,false,true);skip=2;encoding="UTF-16 BE BOM";}
   else if(legacy){codec=Encoding.GetEncoding(1252,EncoderFallback.ExceptionFallback,DecoderFallback.ExceptionFallback);encoding="Windows-1252 (selected)";}
   else{codec=new UTF8Encoding(false,true);encoding="UTF-8";}
   try{return codec.GetString(bytes,skip,bytes.Length-skip);}catch(DecoderFallbackException){throw new InvalidDataException("Text encoding is invalid. Try Windows-1252 for a legacy file, or save it as UTF-8 in its original application.");}
  }
  public static void EnsureNewCopy(Dataset d,string path){
   if(!String.IsNullOrEmpty(d.SourcePath)&&String.Equals(Path.GetFullPath(d.SourcePath),path,StringComparison.OrdinalIgnoreCase))throw new IOException("Choose a new filename. SheetClean will not overwrite the imported source.");
   if(File.Exists(path)&&!String.IsNullOrEmpty(d.SourceIdentity))using(var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read))if(Identity(f)==d.SourceIdentity)throw new IOException("This destination refers to the source file. Choose a different file.");
  }
  public static void Export(string path,CleanResult result,bool log,CancellationToken token) {
   path=LocalPath(path);EnsureNewCopy(result.Source,path);string ext=Path.GetExtension(path).ToLowerInvariant();
   if(log?ext!=".json":ext!=".csv"&&ext!=".tsv")throw new IOException(log?"Use a .json change log filename.":"Use a .csv or .tsv filename.");
   if(!log && ext==".tsv" && result.Source.Delimiter!='\t')throw new IOException("Use .csv for this delimiter. Only tab-delimited data can be exported as .tsv.");
   Atomic(path,w=>{
    if(log)WriteLog(w,result,token);
    else {
     if(result.Source.HasHeader)w.Write(Csv.Row(result.Headers,result.Source.Delimiter)+"\r\n");
     foreach(var row in result.Rows){token.ThrowIfCancellationRequested();w.Write(Csv.Row(row,result.Source.Delimiter)+"\r\n");}
    }
   },!log,token);
  }
  public static void Atomic(string path,Action<TextWriter> write,bool bom,CancellationToken token) {
   string temp=Path.Combine(Path.GetDirectoryName(path),".sheetclean-"+Guid.NewGuid().ToString("N")+".tmp");
   try {
    token.ThrowIfCancellationRequested();
    using(var f=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None))using(var w=new StreamWriter(f,new UTF8Encoding(bom,true))){write(w);token.ThrowIfCancellationRequested();w.Flush();f.Flush(true);}
    token.ThrowIfCancellationRequested();if(File.Exists(path))File.Replace(temp,path,null);else File.Move(temp,path);
   }finally{if(File.Exists(temp))File.Delete(temp);}
  }
  static void WriteLog(TextWriter w,CleanResult r,CancellationToken token) {
   var json=new JavaScriptSerializer{MaxJsonLength=64*1024*1024};
   w.Write("{\"product\":\"SheetClean 1.0\",\"sourceName\":"+json.Serialize(r.Source.DisplayName)+",\"analyzedUtc\":"+json.Serialize(r.AnalyzedUtc)+",\"rules\":"+json.Serialize(r.Options)+",\"inputRows\":"+r.Source.Rows.Count+",\"outputRows\":"+r.Rows.Count+",\"removedRows\":"+r.Removed+",\"trimmedCells\":"+r.TrimmedCells+",\"textPrefixedCells\":"+r.ProtectedCells+",\"missingRequiredCells\":"+r.MissingCells+",\"changes\":[");
   bool first=true;foreach(var c in r.Changes){token.ThrowIfCancellationRequested();if(!first)w.Write(',');w.Write(json.Serialize(c));first=false;}
   w.Write("],\"issues\":[");first=true;foreach(var issue in r.Issues){token.ThrowIfCancellationRequested();if(!first)w.Write(',');w.Write(json.Serialize(issue));first=false;}w.Write("]}");
  }
 }
}
