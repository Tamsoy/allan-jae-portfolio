using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

namespace SheetClean {
 public sealed class AuditLog {
  public List<string> Lines=new List<string>();public int Passed,Failed;
  public void Check(string name,bool yes){if(yes){Passed++;Lines.Add("PASS: "+name);}else{Failed++;Lines.Add("FAIL: "+name);}}
  public void Test(string name,Action f){try{f();Check(name,true);}catch(Exception e){Failed++;Lines.Add("FAIL: "+name+" — "+e.GetType().Name+": "+e.Message);}}
  public void Finish(string path){Lines.Add("RESULT: "+Passed+" passed; "+Failed+" failed.");File.WriteAllLines(path,Lines);}
 }
 public static class Tests {
  public static Dataset Parse(string text,char delimiter=',',bool header=true){return Csv.Parse(text,delimiter,header,CancellationToken.None);}
  public static CleanResult Clean(Dataset d,CleanOptions o=null){return Cleaner.Analyze(d,o??new CleanOptions(),CancellationToken.None);}
  static void Require(bool value){if(!value)throw new Exception("Assertion failed");}
  static void Reject<T>(Action f) where T:Exception{try{f();}catch(T){return;}throw new Exception("Expected "+typeof(T).Name);}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool CreateHardLink(string link,string existing,IntPtr reserved);
  public static int Run(string directory){directory=Path.GetFullPath(directory);Directory.CreateDirectory(directory);var log=new AuditLog();
   log.Test("long headers cannot amplify every issue label",()=>{var d=Parse(new string('h',32768)+"\n value \n value ");var r=Clean(d);Require(r.Changes.All(c=>c.Column.Length<130)&&r.Headers[0].Length==32768&&Object.ReferenceEquals(d.Label(0),d.Label(0)));});
   log.Test("basic rows and header",()=>{var d=Parse("id,name\r\n001,Ada\r\n002,Sam\r\n");Require(d.Rows.Count==2&&d.Headers.SequenceEqual(new[]{"id","name"})&&d.Rows[0][0]=="001");});
   log.Test("empty final field",()=>Require(Parse("a,b\n1,").Rows[0][1]==""));
   log.Test("single quoted empty field",()=>Require(Parse("\"\"",',',false).Rows[0][0]==""));
   log.Test("trailing separator retains empty field",()=>Require(Parse("a,b,",',',false).Columns==3));
   log.Test("quoted delimiters and escaped quotes",()=>{var d=Parse("a,b\n\"x,y\",\"said \"\"hi\"\"\"");Require(d.Rows[0][0]=="x,y"&&d.Rows[0][1]=="said \"hi\"");});
   log.Test("quoted multiline value preserved",()=>Require(Parse("a,b\r\n1,\"first\r\nsecond\nthird\"\r\n").Rows[0][1]=="first\r\nsecond\nthird"));
   foreach(string ending in new[]{"\r\n","\n","\r"})log.Test("record endings "+ending.Replace("\r","CR").Replace("\n","LF"),()=>Require(Parse("a,b"+ending+"x,y"+ending).Rows.Count==1));
   log.Test("no-header mode retains first record",()=>{var d=Parse("001,Ada\n002,Sam",',',false);Require(d.Rows.Count==2&&d.Record(0)==1&&d.Headers[0]=="Column 1");});
   log.Test("headers-only input supported",()=>Require(Parse("a,b\n").Rows.Count==0));
   log.Test("duplicate and empty headers preserved",()=>Require(Parse("a,a,\n1,2,3").Headers.SequenceEqual(new[]{"a","a",""})));
   foreach(string bad in new[]{"","a,b\n1","a,b\n1,2,3","a,b\n\"broken,2","a,b\nhi\"x,2","a,b\n\"ok\" x,2","a,b\n\"ok\" ,2","a,b\n1,\0"})log.Test("reject malformed CSV "+bad.Replace("\n"," / "),()=>Reject<InvalidDataException>(()=>Parse(bad)));
   log.Test("errors include record number",()=>{try{Parse("a,b\n1,2\n3");}catch(InvalidDataException e){Require(e.Message.Contains("Record 3"));return;}throw new Exception("No error");});
   foreach(char delimiter in new[]{',',';','\t','|'})log.Test("explicit delimiter "+Csv.DelimiterName(delimiter),()=>{var d=Parse("a"+delimiter+"b\n\"inside"+delimiter+"quoted\""+delimiter+"x",delimiter);Require(d.Columns==2&&d.Rows[0][0].Contains(delimiter));});
   foreach(char delimiter in new[]{',',';','\t','|'})log.Test("auto delimiter "+Csv.DelimiterName(delimiter),()=>Require(Csv.Detect("a"+delimiter+"b\n1"+delimiter+"2",CancellationToken.None)==delimiter));
   log.Test("auto ignores quoted separators",()=>Require(Csv.Detect("a;b\n\"x,y,z\";q",CancellationToken.None)==';'));
   log.Test("ambiguous auto detection rejected",()=>Reject<InvalidDataException>(()=>Csv.Detect("a,b;c\n1,2;3",CancellationToken.None)));
   log.Test("uneven auto detection rejected",()=>Reject<InvalidDataException>(()=>Csv.Detect("a,b\n1,2,3",CancellationToken.None)));
   log.Test("single column auto fallback",()=>Require(Csv.Detect("a\nb",CancellationToken.None)==','));
   log.Test("field limit accepted at boundary",()=>Require(Parse("a\n"+new string('x',Csv.MaxField)).Rows[0][0].Length==Csv.MaxField));
   log.Test("field limit rejected above boundary",()=>Reject<InvalidDataException>(()=>Parse("a\n"+new string('x',Csv.MaxField+1))));
   log.Test("100 columns accepted",()=>Require(Parse(String.Join(",",Enumerable.Repeat("h",100))).Columns==100));
   log.Test("101 columns rejected",()=>Reject<InvalidDataException>(()=>Parse(String.Join(",",Enumerable.Repeat("h",101)))));
   log.Test("50000 data rows accepted",()=>Require(Parse("h\n"+String.Concat(Enumerable.Repeat("x\n",50000))).Rows.Count==50000));
   log.Test("50001 data rows rejected",()=>Reject<InvalidDataException>(()=>Parse("h\n"+String.Concat(Enumerable.Repeat("x\n",50001)))));
   log.Test("cell budget enforced",()=>Reject<InvalidDataException>(()=>Parse(String.Concat(Enumerable.Repeat(String.Join(",",Enumerable.Repeat("x",100))+"\n",2501)))));
   log.Test("decoded text limit enforced",()=>Reject<InvalidDataException>(()=>Parse(new string('x',Csv.MaxBytes+1))));
   log.Test("parser cancellation",()=>{using(var c=new CancellationTokenSource()){c.Cancel();Reject<OperationCanceledException>(()=>Csv.Parse("a\nb",',',true,c.Token));}});
   log.Test("detect cancellation",()=>{using(var c=new CancellationTokenSource()){c.Cancel();Reject<OperationCanceledException>(()=>Csv.Detect("a,b\n1,2",c.Token));}});
   string encoding;
   log.Check("strict UTF-8 preserves Unicode",Files.Decode(Encoding.UTF8.GetBytes("Zoë / 日本語"),false,out encoding)=="Zoë / 日本語");
   log.Check("UTF-8 BOM removed",Files.Decode(new byte[]{239,187,191,97},false,out encoding)=="a");
   log.Check("UTF-16 LE BOM decoded",Files.Decode(new byte[]{255,254,97,0},false,out encoding)=="a");
   log.Check("UTF-16 BE BOM decoded",Files.Decode(new byte[]{254,255,0,97},false,out encoding)=="a");
   log.Check("explicit Windows-1252 decoded",Files.Decode(new byte[]{99,97,102,233},true,out encoding)=="café");
   log.Test("invalid UTF-8 rejected",()=>{string e;Reject<InvalidDataException>(()=>Files.Decode(new byte[]{0xc3,0x28},false,out e));});
   log.Test("invalid UTF-16 rejected",()=>{string e;Reject<InvalidDataException>(()=>Files.Decode(new byte[]{255,254,97},false,out e));});
   log.Test("UTF-32 explicitly rejected",()=>{string e;Reject<InvalidDataException>(()=>Files.Decode(new byte[]{255,254,0,0,97,0,0,0},false,out e));});
   log.Test("no-op clean preserves exact text values",()=>{var d=Parse("id,date,name\n001,03/04/2026, Ada  Lovelace ");var r=Clean(d,new CleanOptions{Trim=false,ProtectFormulas=false});Require(r.Rows[0].SequenceEqual(d.Rows[0])&&r.Changes.Count==0);});
   log.Test("trim outer whitespace only",()=>Require(Clean(Parse("a\n  Ada  Lovelace  ")).Rows[0][0]=="Ada  Lovelace"));
   log.Test("leading zeros and date text preserved",()=>{var r=Clean(Parse("id,date\n001,01/02/03"));Require(r.Rows[0][0]=="001"&&r.Rows[0][1]=="01/02/03");});
   log.Test("header whitespace never trimmed",()=>Require(Clean(Parse(" Header \n x ")).Headers[0]==" Header "));
   log.Test("duplicates after trim keep first",()=>{var r=Clean(Parse("a,b\n x ,1\nx,1\ny,1"),new CleanOptions{RemoveDuplicates=true});Require(r.Duplicates==1&&r.Rows.Count==2&&r.SourceRecords.SequenceEqual(new[]{2,4}));});
   log.Test("duplicates flagged when removal off",()=>{var r=Clean(Parse("a\nx\nx"));Require(r.Rows.Count==2&&r.Duplicates==1&&r.Removed==0);});
   log.Test("duplicate comparison case sensitive",()=>Require(Clean(Parse("a\nA\na"),new CleanOptions{RemoveDuplicates=true}).Rows.Count==2));
   log.Test("delimiter-containing cells cannot collide",()=>{var r=Clean(Parse("a,b\n\"x|y\",z\nx,\"y|z\""),new CleanOptions{RemoveDuplicates=true});Require(r.Rows.Count==2);});
   log.Test("empty-value row keys do not collide",()=>{var r=Clean(Parse("a,b\n,x\nx,"),new CleanOptions{RemoveDuplicates=true});Require(r.Rows.Count==2);});
   log.Test("blank rows retained by default",()=>{var r=Clean(Parse("a,b\n,\nx,y"));Require(r.BlankRows==1&&r.Rows.Count==2);});
   log.Test("blank rows removed only when selected",()=>{var r=Clean(Parse("a,b\n , \nx,y"),new CleanOptions{RemoveBlank=true});Require(r.BlankRows==1&&r.Removed==1&&r.SourceRecords[0]==3);});
   log.Test("all blank rows can be removed",()=>Require(Clean(Parse("a,b\n,\n,"),new CleanOptions{RemoveBlank=true}).Rows.Count==0));
   log.Test("missing required fields retained",()=>{var r=Clean(Parse("a,b\nx,\n ,y"),new CleanOptions{Required=new[]{0,1}});Require(r.MissingCells==2&&r.Rows.Count==2);});
   log.Test("no required fields means no missing flags",()=>Require(Clean(Parse("a,b\n,")).MissingCells==0));
   log.Test("invalid required column rejected",()=>Reject<InvalidDataException>(()=>Clean(Parse("a\nx"),new CleanOptions{Required=new[]{1}})));
   log.Test("analysis snapshots rule selections",()=>{var o=new CleanOptions{Required=new[]{0}};var r=Clean(Parse("a\nx"),o);o.Required[0]=99;Require(r.Options.Required[0]==0);});
   log.Test("source arrays remain unchanged",()=>{var d=Parse("a\n =1+1 \n =1+1 ");var before=Csv.Serialize(d,d.Rows,d.Headers);Clean(d,new CleanOptions{RemoveDuplicates=true});Require(Csv.Serialize(d,d.Rows,d.Headers)==before);});
   log.Test("cleaning repeatable",()=>{var d=Parse(Cleaner.Sample);var a=Clean(d);var b=Clean(d);Require(Csv.Serialize(d,a.Rows,a.Headers)==Csv.Serialize(d,b.Rows,b.Headers));});
   log.Test("analysis cancellation",()=>{using(var c=new CancellationTokenSource()){c.Cancel();Reject<OperationCanceledException>(()=>Cleaner.Analyze(Parse("a\nx"),new CleanOptions(),c.Token));}});
   foreach(string dangerous in new[]{"=1+1","+1","-12","@SUM(A1)","\ttext","\rtext","\ntext","  =1+1","\u200b=1","＝1+1","＋1","－1","＠x"})log.Test("formula-like prefix "+dangerous.Replace("\n","LF").Replace("\r","CR"),()=>{var d=Parse("h\n"+Csv.Row(new[]{dangerous},','));var r=Clean(d,new CleanOptions{Trim=false});Require(r.Rows[0][0]=="'"+dangerous&&r.ProtectedCells==1);});
   foreach(string safe in new[]{"001","2026-09-15","hello =world","' =1","O'Neil","","plain text"})log.Check("ordinary text unchanged "+safe,!Cleaner.FormulaLike(safe));
   log.Test("formula-like headers protected",()=>Require(Clean(Parse("=Header\nvalue")).Headers[0]=="'=Header"));
   log.Test("explicit raw mode flags but preserves value",()=>{var r=Clean(Parse("h\n=1+1"),new CleanOptions{ProtectFormulas=false});Require(r.Rows[0][0]=="=1+1"&&r.ProtectedCells==0&&r.Issues.Count==1);});
   log.Test("source record trace survives multiline data",()=>{var r=Clean(Parse("h\n\"a\nb\"\n\"a\nb\""),new CleanOptions{RemoveDuplicates=true});Require(r.Changes.Last().Record==3);});
   log.Test("300 deterministic CSV round trips",()=>{var random=new Random(4180);string[] pieces={"a","0",",",";","|","\t","\r","\n","\"","é","日"," ","=1"};foreach(char delimiter in new[]{',',';','\t','|'})for(int n=0;n<75;n++){int cols=random.Next(1,8),rows=random.Next(1,12);var values=new List<string[]>();for(int i=0;i<rows;i++)values.Add(Enumerable.Range(0,cols).Select(c=>String.Concat(Enumerable.Range(0,random.Next(0,12)).Select(z=>pieces[random.Next(pieces.Length)]))).ToArray());string txt=String.Join("\r\n",values.Select(x=>Csv.Row(x,delimiter)).ToArray())+"\r\n";var parsed=Parse(txt,delimiter,false);Require(parsed.Rows.Count==rows&&parsed.Rows.Zip(values,(a,b)=>a.SequenceEqual(b)).All(x=>x));}});
   string source=Path.Combine(directory,"fictional-clients.csv");File.WriteAllText(source,Cleaner.Sample,new UTF8Encoding(true));Dataset loaded=null;CleanResult result=null;
   log.Test("file import and metadata",()=>{loaded=Files.Load(source,null,true,false,CancellationToken.None);Require(loaded.Rows.Count==7&&loaded.Columns==4&&loaded.SourceIdentity!=null&&loaded.EncodingName=="UTF-8 BOM");result=Clean(loaded,new CleanOptions{RemoveBlank=true,RemoveDuplicates=true,Required=new[]{2}});});
   if(result!=null){
    log.Test("export full cleaned CSV roundtrip",()=>{string p=Path.Combine(directory,"cleaned.csv");Files.Export(p,result,false,CancellationToken.None);var d=Files.Load(p,',',true,false,CancellationToken.None);Require(d.Rows.Count==result.Rows.Count&&d.Rows.Zip(result.Rows,(a,b)=>a.SequenceEqual(b)).All(x=>x));});
    log.Test("export UTF-8 BOM",()=>Require(File.ReadAllBytes(Path.Combine(directory,"cleaned.csv")).Take(3).SequenceEqual(new byte[]{239,187,191})));
    log.Test("JSON change log preserves counts and escaping",()=>{string p=Path.Combine(directory,"changes.json");Files.Export(p,result,true,CancellationToken.None);var json=new JavaScriptSerializer().DeserializeObject(File.ReadAllText(p)) as Dictionary<string,object>;Require(Convert.ToInt32(json["outputRows"])==result.Rows.Count&&!File.ReadAllText(p).Contains(directory.Replace("\\","\\\\")));});
    log.Test("source cannot be overwritten",()=>{var old=File.ReadAllBytes(source);Reject<IOException>(()=>Files.Export(source,result,false,CancellationToken.None));Require(File.ReadAllBytes(source).SequenceEqual(old));});
    log.Test("hard-link source alias cannot be overwritten",()=>{string p=Path.Combine(directory,"alias-"+Guid.NewGuid().ToString("N")+".csv");if(!CreateHardLink(p,source,IntPtr.Zero))throw new IOException("Cannot create test hard link");try{Reject<IOException>(()=>Files.Export(p,result,false,CancellationToken.None));}finally{File.Delete(p);}});
    log.Test("locked export preserves previous file",()=>{string p=Path.Combine(directory,"locked.csv");File.WriteAllText(p,"old");using(var f=File.Open(p,FileMode.Open,FileAccess.Read,FileShare.None))Reject<IOException>(()=>Files.Export(p,result,false,CancellationToken.None));Require(File.ReadAllText(p)=="old");});
    log.Test("read-only export preserves previous file",()=>{string p=Path.Combine(directory,"readonly.csv");File.WriteAllText(p,"old");File.SetAttributes(p,FileAttributes.ReadOnly);try{Reject<UnauthorizedAccessException>(()=>Files.Export(p,result,false,CancellationToken.None));Require(File.ReadAllText(p)=="old");}finally{File.SetAttributes(p,FileAttributes.Normal);}});
    log.Test("missing output directory fails safely",()=>Reject<DirectoryNotFoundException>(()=>Files.Export(Path.Combine(directory,"missing-"+Guid.NewGuid().ToString("N"),"x.csv"),result,false,CancellationToken.None)));
    log.Test("bad export extension rejected",()=>Reject<IOException>(()=>Files.Export(Path.Combine(directory,"x.exe"),result,false,CancellationToken.None)));
    log.Test("non-tab TSV export rejected",()=>Reject<IOException>(()=>Files.Export(Path.Combine(directory,"x.tsv"),result,false,CancellationToken.None)));
    log.Test("cancelled export preserves destination",()=>{string p=Path.Combine(directory,"cancelled.csv");File.WriteAllText(p,"old");using(var c=new CancellationTokenSource()){c.Cancel();Reject<OperationCanceledException>(()=>Files.Export(p,result,false,c.Token));}Require(File.ReadAllText(p)=="old");});
    log.Test("mid-write failure preserves destination",()=>{string p=Path.Combine(directory,"midwrite.csv");File.WriteAllText(p,"old");Reject<IOException>(()=>Files.Atomic(p,w=>{w.Write("partial");throw new IOException("Simulated full disk");},true,CancellationToken.None));Require(File.ReadAllText(p)=="old");});
    log.Test("mid-write cancellation preserves destination",()=>{string p=Path.Combine(directory,"midcancel.csv");File.WriteAllText(p,"old");using(var c=new CancellationTokenSource())Reject<OperationCanceledException>(()=>Files.Atomic(p,w=>{w.Write("partial");c.Cancel();},true,c.Token));Require(File.ReadAllText(p)=="old");});
    log.Test("successful atomic overwrite",()=>{string p=Path.Combine(directory,"overwrite.csv");File.WriteAllText(p,"old");Files.Export(p,result,false,CancellationToken.None);Require(File.ReadAllText(p).Contains("Client ID"));});
   }
   log.Test("tab-delimited file export",()=>{var d=Parse("a\tb\n1\t2",'\t');var r=Clean(d);var p=Path.Combine(directory,"tab.tsv");Files.Export(p,r,false,CancellationToken.None);Require(Files.Load(p,null,true,false,CancellationToken.None).Delimiter=='\t');});
   log.Test("no-header export does not add names",()=>{var d=Parse("001,Ada",',',false);string p=Path.Combine(directory,"no-header.csv");Files.Export(p,Clean(d),false,CancellationToken.None);Require(!File.ReadAllText(p).Contains("Column 1"));});
   log.Test("network paths rejected without opening",()=>Reject<IOException>(()=>Files.LocalPath(@"\\server\share\file.csv")));
   log.Test("alternate streams rejected",()=>Reject<IOException>(()=>Files.LocalPath(source+":stream")));
   log.Test("unsupported input extension rejected",()=>Reject<InvalidDataException>(()=>Files.Load(Path.Combine(directory,"book.xlsx"),null,true,false,CancellationToken.None)));
   log.Test("file byte budget enforced",()=>{string p=Path.Combine(directory,"large.csv");using(var f=File.Create(p))f.SetLength(Csv.MaxBytes+1);try{Reject<InvalidDataException>(()=>Files.Load(p,null,true,false,CancellationToken.None));}finally{File.Delete(p);}});
   log.Test("pre-cancelled file load",()=>{using(var c=new CancellationTokenSource()){c.Cancel();Reject<OperationCanceledException>(()=>Files.Load(source,null,true,false,c.Token));}});
   log.Check("no abandoned atomic temporary files",!Directory.GetFiles(directory,".sheetclean-*.tmp").Any());
   log.Test("large bounded dataset analysis",()=>{var text="id,value\n"+String.Join("\n",Enumerable.Range(0,20000).Select(x=>x+", text ").ToArray());var sw=Stopwatch.StartNew();var r=Clean(Parse(text));Require(r.Rows.Count==20000&&r.TrimmedCells==20000);log.Lines.Add("MEASURE: 20,000 rows parsed and cleaned in "+sw.ElapsedMilliseconds+" ms on this PC.");});
   log.Finish(Path.Combine(directory,"test-results.txt"));return log.Failed==0?0:1;
  }
 }
}
