using System.Reflection;
[assembly:AssemblyTitle("SheetClean")]
[assembly:AssemblyDescription("Local CSV cleaning with traceable changes")]
[assembly:AssemblyCompany("Allan Jae Eparwa")]
[assembly:AssemblyProduct("SheetClean")]
[assembly:AssemblyVersion("1.0.0.0")]
[assembly:AssemblyFileVersion("1.0.0.0")]
