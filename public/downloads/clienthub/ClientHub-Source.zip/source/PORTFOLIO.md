# ClientHub portfolio description

ClientHub is a privacy-first desktop client workspace I designed for virtual assistant, admin, and support workflows. It centralizes contacts, statuses, follow-up dates, priority clients, and notes in a focused two-column interface.

The project demonstrates native WPF UI development, responsive layout, light/dark theming, animation, local JSON persistence, safe import/export validation, clipboard workflows, per-user installation, and automated regression auditing. It deliberately avoids accounts, API keys, telemetry, and automatic uploads.
