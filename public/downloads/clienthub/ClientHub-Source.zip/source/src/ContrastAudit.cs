using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;
namespace ClientHub {
 static class ContrastAudit {
  public static async Task Run(Window window,string directory,Action<string,bool> check) {
   var combos=Descendants(window).OfType<ComboBox>().ToArray();
   var theme=(Button)window.FindName("ThemeButton");
   foreach(string mode in new[]{"dark","light"}) {
    if(mode=="light"){theme.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));await Task.Delay(300);}
    foreach(var combo in combos) {
     if(!combo.IsEnabled||combo.Items.Count==0)continue;
     int selected=combo.SelectedIndex;if(selected<0)combo.SelectedIndex=0;
     combo.ApplyTemplate();combo.UpdateLayout();await Task.Delay(30);
     string expected=combo.SelectedItem is ComboBoxItem?Convert.ToString(((ComboBoxItem)combo.SelectedItem).Content):Convert.ToString(combo.SelectedItem);
     var presenter=combo.Template.FindName("SelectionPresenter",combo) as ContentPresenter;
     check(mode+" "+combo.Name+" selected text actually renders",presenter!=null&&Descendants(presenter).OfType<TextBlock>().Any(t=>t.Text==expected&&t.ActualWidth>0));
     var ink=((SolidColorBrush)combo.Foreground).Color;
     var background=((SolidColorBrush)window.Resources["Canvas"]).Color;
     check(mode+" "+combo.Name+" text contrast >= 4.5:1",Contrast(ink,background)>=4.5);
     combo.IsDropDownOpen=true;await Task.Delay(50);combo.UpdateLayout();
     var popup=combo.Template.FindName("PART_Popup",combo) as Popup;
     check(mode+" "+combo.Name+" popup opens",popup!=null&&popup.IsOpen&&popup.Child!=null&&popup.Child.IsVisible);
     if(popup!=null&&popup.Child!=null)Shot((FrameworkElement)popup.Child,Path.Combine(directory,mode+"-"+combo.Name+"-dropdown.png"));
     combo.IsDropDownOpen=false;combo.SelectedIndex=selected;
    }
    Shot((FrameworkElement)window.Content,Path.Combine(directory,mode+"-workspace.png"));
   }
   theme.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));await Task.Delay(300);
  }
  static double Channel(byte x){double c=x/255.0;return c<=.04045?c/12.92:Math.Pow((c+.055)/1.055,2.4);}
  static double Contrast(Color a,Color b){double x=.2126*Channel(a.R)+.7152*Channel(a.G)+.0722*Channel(a.B),y=.2126*Channel(b.R)+.7152*Channel(b.G)+.0722*Channel(b.B);return (Math.Max(x,y)+.05)/(Math.Min(x,y)+.05);}
  static IEnumerable<DependencyObject> Descendants(DependencyObject root){for(int i=0;i<VisualTreeHelper.GetChildrenCount(root);i++){var child=VisualTreeHelper.GetChild(root,i);yield return child;foreach(var nested in Descendants(child))yield return nested;}}
  static void Shot(FrameworkElement c,string file){c.UpdateLayout();var b=new RenderTargetBitmap((int)Math.Ceiling(c.ActualWidth),(int)Math.Ceiling(c.ActualHeight),96,96,PixelFormats.Pbgra32);b.Render(c);var e=new PngBitmapEncoder();e.Frames.Add(BitmapFrame.Create(b));using(var s=File.Create(file))e.Save(s);}
 }
}
