using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
namespace ClientHub {
 public sealed class ClientRecord {
  public string Id{get;set;} public string Name{get;set;} public string Company{get;set;} public string Email{get;set;} public string Status{get;set;} public string NextFollowUp{get;set;} public string Notes{get;set;} public bool Favorite{get;set;} public DateTime EditedUtc{get;set;}
  public ClientRecord Clone(){return new ClientRecord{Id=Id,Name=Name,Company=Company,Email=Email,Status=Status,NextFollowUp=NextFollowUp,Notes=Notes,Favorite=Favorite,EditedUtc=EditedUtc};}
 }
 public static class ClientRules {
  public const int MaxClients=500,MaxText=160,MaxNotes=32768,MaxFile=10*1024*1024;
  static readonly string[] Statuses={"Lead","Active","Paused","Closed"};
  public static string Validate(ClientRecord c){
   if(c==null)return "Choose a client.";if(String.IsNullOrWhiteSpace(c.Name))return "Add a client name.";if(c.Name.Trim().Length>MaxText)return "Client name is limited to 160 characters.";
   if((c.Company??"").Trim().Length>MaxText)return "Company is limited to 160 characters.";if((c.Email??"").Trim().Length>MaxText)return "Email is limited to 160 characters.";
   if(!String.IsNullOrWhiteSpace(c.Email)&&!Regex.IsMatch(c.Email.Trim(),@"^[^\s@]+@[^\s@]+\.[^\s@]+$"))return "Enter a valid email address or leave it blank.";
   if(!Statuses.Contains(c.Status??""))return "Choose a valid client status.";DateTime due;if(!String.IsNullOrWhiteSpace(c.NextFollowUp)&&!DateTime.TryParse(c.NextFollowUp,out due))return "Next follow-up must be a valid date.";
   if((c.Notes??"").Length>MaxNotes)return "Notes are limited to 32,768 characters.";return null;
  }
  public static bool IsOverdue(ClientRecord c){DateTime d;return c!=null&&!String.IsNullOrWhiteSpace(c.NextFollowUp)&&DateTime.TryParse(c.NextFollowUp,out d)&&d.Date<DateTime.Today&&!String.Equals(c.Status,"Closed",StringComparison.OrdinalIgnoreCase);}
  public static List<ClientRecord> Sample(){return new List<ClientRecord>{Item("Maya Chen","Northstar Studio","maya@northstar.example","Active",DateTime.Today.AddDays(2),"Website refresh · confirm final assets."),Item("Jordan Lee","BrightPath VA","jordan@brightpath.example","Lead",DateTime.Today.AddDays(7),"Discovery call · ask about their intake workflow."),Item("Riley Santos","Harbor & Co.","riley@harbor.example","Paused",DateTime.Today.AddDays(-3),"Waiting on budget approval before the next milestone."),Item("Avery Morgan","Pine & Paper","avery@pinepaper.example","Closed","","Project completed and handoff archived.")};}
  static ClientRecord Item(string n,string co,string e,string s,DateTime d,string notes){return new ClientRecord{Id=Guid.NewGuid().ToString("N"),Name=n,Company=co,Email=e,Status=s,NextFollowUp=d==DateTime.MinValue?"":d.ToString("yyyy-MM-dd"),Notes=notes,Favorite=s=="Active",EditedUtc=DateTime.UtcNow};}
  static ClientRecord Item(string n,string co,string e,string s,string d,string notes){return new ClientRecord{Id=Guid.NewGuid().ToString("N"),Name=n,Company=co,Email=e,Status=s,NextFollowUp=d,Notes=notes,Favorite=false,EditedUtc=DateTime.UtcNow};}
  public static string Summary(ClientRecord c){var b=new StringBuilder();b.AppendLine(c.Name);if(!String.IsNullOrWhiteSpace(c.Company))b.AppendLine(c.Company);if(!String.IsNullOrWhiteSpace(c.Email))b.AppendLine(c.Email);b.AppendLine("Status: "+c.Status);if(!String.IsNullOrWhiteSpace(c.NextFollowUp))b.AppendLine("Next follow-up: "+c.NextFollowUp);if(!String.IsNullOrWhiteSpace(c.Notes)){b.AppendLine();b.AppendLine(c.Notes);}return b.ToString().Trim();}
  public static string[] AllStatuses(){return Statuses.ToArray();}
 }
 public static class Clients {
  public static List<ClientRecord> Filter(IEnumerable<ClientRecord> all,string query,string status,bool favorites,CancellationToken token){var q=(query??"").Trim().ToLowerInvariant();var result=new List<ClientRecord>();foreach(var c in all??Enumerable.Empty<ClientRecord>()){token.ThrowIfCancellationRequested();if(favorites&&!c.Favorite)continue;if(!String.IsNullOrEmpty(status)&&status!="All"&&!String.Equals(c.Status,status,StringComparison.OrdinalIgnoreCase))continue;string hay=(c.Name+"\n"+c.Company+"\n"+c.Email+"\n"+c.Status+"\n"+c.NextFollowUp+"\n"+c.Notes).ToLowerInvariant();if(q.Length==0||hay.Contains(q))result.Add(c);}return result.OrderByDescending(x=>x.Favorite).ThenBy(x=>x.NextFollowUp??"9999",StringComparer.OrdinalIgnoreCase).ThenBy(x=>x.Name,StringComparer.OrdinalIgnoreCase).ToList();}
 }
}
