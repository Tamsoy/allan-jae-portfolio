using System.Reflection;
[assembly: AssemblyTitle("ClientHub")]
[assembly: AssemblyDescription("Offline client workspace for contacts, requests, deadlines, and notes")]
[assembly: AssemblyCompany("Allan Jae Eparwa")]
[assembly: AssemblyProduct("ClientHub")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
