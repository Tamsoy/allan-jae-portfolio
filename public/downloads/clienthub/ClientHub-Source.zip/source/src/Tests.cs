using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
namespace ClientHub {
 public sealed class AuditLog{public List<string>Lines=new List<string>();public int Passed,Failed;public void Check(string n,bool ok){if(ok){Passed++;Lines.Add("PASS: "+n);}else{Failed++;Lines.Add("FAIL: "+n);}}public void Test(string n,Action a){try{a();Check(n,true);}catch(Exception e){Failed++;Lines.Add("FAIL: "+n+" — "+e.GetType().Name+": "+e.Message);}}public void Finish(string p){Lines.Add("RESULT: "+Passed+" passed; "+Failed+" failed.");File.WriteAllLines(p,Lines);}}
 public static class Tests{
  static void Need(bool b){if(!b)throw new Exception("Assertion failed");}static void Reject<T>(Action a)where T:Exception{try{a();}catch(T){return;}throw new Exception("Expected "+typeof(T).Name);}
  public static int Run(string dir){dir=Path.GetFullPath(dir);Directory.CreateDirectory(dir);var l=new AuditLog();var sample=ClientRules.Sample();
   l.Test("sample clients",()=>Need(sample.Count==4&&sample.Any(x=>x.Favorite)&&sample.Any(ClientRules.IsOverdue)));
   l.Test("required name",()=>{var c=ClientRules.Sample()[0];c.Name=" ";Need(ClientRules.Validate(c)=="Add a client name.");});
   l.Test("email validation",()=>{var c=ClientRules.Sample()[0];c.Email="bad";Need(ClientRules.Validate(c).Contains("valid email"));});
   l.Test("date validation",()=>{var c=ClientRules.Sample()[0];c.NextFollowUp="tomorrow-ish";Need(ClientRules.Validate(c).Contains("valid date"));});
   l.Test("closed overdue excluded",()=>{var c=sample[3];Need(!ClientRules.IsOverdue(c));});
   l.Test("summary includes fields",()=>Need(ClientRules.Summary(sample[0]).Contains(sample[0].Company)&&ClientRules.Summary(sample[0]).Contains(sample[0].NextFollowUp)));
   l.Test("search company",()=>Need(Clients.Filter(sample,"northstar","All",false,CancellationToken.None).Count==1));
   l.Test("status filter",()=>Need(Clients.Filter(sample,"","Lead",false,CancellationToken.None).Count==1));
   l.Test("priority filter",()=>Need(Clients.Filter(sample,"","All",true,CancellationToken.None).Count==1));
   l.Test("no results",()=>Need(Clients.Filter(sample,"missing","All",false,CancellationToken.None).Count==0));
   l.Test("clone independent",()=>{var c=sample[0].Clone();c.Name="Changed";Need(sample[0].Name!="Changed");});
   l.Test("json roundtrip",()=>{var p=Path.Combine(dir,"workspace.json");Files.Save(p,sample,CancellationToken.None);Need(Files.Load(p,CancellationToken.None).Count==4);});
   l.Test("invalid json",()=>{var p=Path.Combine(dir,"bad.json");File.WriteAllText(p,"bad");Reject<InvalidDataException>(()=>Files.Load(p,CancellationToken.None));});
   l.Test("duplicate IDs",()=>{var p=Path.Combine(dir,"dup.json");var x=sample.Select(c=>c.Clone()).ToList();x[1].Id=x[0].Id;File.WriteAllText(p,new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(x));Reject<InvalidDataException>(()=>Files.Load(p,CancellationToken.None));});
   l.Test("network path rejected",()=>Reject<IOException>(()=>Files.Load(@"\\server\share\clients.json",CancellationToken.None)));
   l.Test("extension rejected",()=>Reject<IOException>(()=>Files.Save(Path.Combine(dir,"clients.txt"),sample,CancellationToken.None)));
   l.Test("cancelled export",()=>{var c=new CancellationTokenSource();c.Cancel();Reject<OperationCanceledException>(()=>Files.Save(Path.Combine(dir,"cancel.json"),sample,c.Token));});
   var many=Enumerable.Range(0,ClientRules.MaxClients+1).Select(i=>new ClientRecord{Id=Guid.NewGuid().ToString(),Name="x",Status="Lead"}).ToList();l.Test("client count limit",()=>Reject<InvalidDataException>(()=>Files.Validate(many)));
   for(int i=0;i<35;i++)l.Test("round trip "+i,()=>{var p=Path.Combine(dir,"round"+i+".json");var x=ClientRules.Sample();x[0].Notes="note "+i+" with \"quotes\"";Files.Save(p,x,CancellationToken.None);Need(Files.Load(p,CancellationToken.None)[0].Notes==x[0].Notes);});
   l.Finish(Path.Combine(dir,"test-results.txt"));return l.Failed==0?0:1;}
 }
}
