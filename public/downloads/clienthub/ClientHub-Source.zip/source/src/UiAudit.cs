using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;
namespace ClientHub {
 public static class UiAudit {
  public static int Run(string output){
   output=Path.GetFullPath(output);Directory.CreateDirectory(output);var log=new AuditLog();var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};
   app.Startup+=async delegate{Workspace ui=null;try{
    ui=new Workspace();ui.Window.Show();await Task.Delay(140);log.Check("cold start",ui.Window.IsVisible&&ui.Items.Count==0&&!ui.Get<Button>("CopyButton").IsEnabled);
    var theme=ui.Get<Button>("ThemeButton");log.Check("theme accessible",new ButtonAutomationPeer(theme).GetName().Contains("light"));theme.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));await Task.Delay(40);log.Check("light theme tokens",((SolidColorBrush)ui.Window.Resources["Canvas"]).Color==Color.FromRgb(0xF4,0xF7,0xFC)&&new ButtonAutomationPeer(theme).GetName().Contains("dark"));log.Check("theme transition feedback",ui.Get<Border>("ThemeFlash").Opacity>0);theme.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));await Task.Delay(40);log.Check("dark theme tokens",((SolidColorBrush)ui.Window.Resources["Canvas"]).Color==Color.FromRgb(0x11,0x1A,0x38));Shot(ui,Path.Combine(output,"clienthub-ready.png"));
    ui.LoadSampleAction();await ui.CurrentOperation;log.Check("sample load",ui.Items.Count==4&&ui.Get<ListBox>("ClientList").Items.Count==4);await ContrastAudit.Run(ui.Window,output,log.Check);log.Check("accessible search",new TextBoxAutomationPeer(ui.Get<TextBox>("SearchInput")).GetName()=="Search clients");ui.Get<TextBox>("SearchInput").Text="northstar";log.Check("search filters",ui.Get<ListBox>("ClientList").Items.Count==1);ui.Get<TextBox>("SearchInput").Text="";ui.Get<ListBox>("ClientList").SelectedIndex=0;log.Check("selection fills editor",ui.Selected!=null&&ui.Get<TextBox>("NameInput").Text.Length>0);ui.Get<Button>("CopyButton").RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));log.Check("copy action updates status",ui.Get<TextBlock>("Status").Text.Contains("copied"));ui.Get<CheckBox>("FavoritesInput").IsChecked=true;log.Check("priority filter",ui.Get<ListBox>("ClientList").Items.Count==1);ui.Get<CheckBox>("FavoritesInput").IsChecked=false;ui.DuplicateItem();log.Check("duplicate action",ui.Items.Count==5);ui.Get<TextBox>("NameInput").Text="";ui.Get<Button>("SaveButton").RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));log.Check("invalid save visible",ui.Get<TextBlock>("Status").Text.Contains("Cannot save"));ui.Get<TextBox>("NameInput").Text="Copied client";ui.Get<Button>("SaveButton").RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));log.Check("valid save",ui.Items.Any(x=>x.Name=="Copied client"));
    var file=Path.Combine(output,"ui-workspace.json");await ui.ExportPath(file);log.Check("export path",File.Exists(file));var old=ui.Items;await ui.ImportPath(file);log.Check("import path",ui.Items.Count==old.Count);var bad=Path.Combine(output,"bad.json");File.WriteAllText(bad,"bad");await ui.ImportPath(bad);log.Check("bad import preserves",ui.Items.Count==old.Count&&ui.Get<TextBlock>("Status").Text.Contains("previous workspace"));foreach(int width in new[]{500,768,1140,1440}){ui.Window.Width=width;ui.Window.UpdateLayout();log.Check("layout "+width,ui.Get<ScrollViewer>("OuterScroll").ExtentWidth<=ui.Get<ScrollViewer>("OuterScroll").ViewportWidth+2);}Shot(ui,Path.Combine(output,"clienthub-final.png"));ui.Window.Close();
   }catch(Exception e){log.Check("UI audit exception: "+e,false);}finally{if(ui!=null&&ui.Window.IsVisible)ui.Window.Close();log.Finish(Path.Combine(output,"ui-results.txt"));app.Shutdown(log.Failed==0?0:1);}};return app.Run();}
  static void Shot(Workspace ui,string p){ui.Window.UpdateLayout();var c=(FrameworkElement)ui.Window.Content;var b=new RenderTargetBitmap((int)Math.Ceiling(c.ActualWidth),(int)Math.Ceiling(c.ActualHeight),96,96,PixelFormats.Pbgra32);b.Render(c);var e=new PngBitmapEncoder();e.Frames.Add(BitmapFrame.Create(b));using(var s=File.Create(p))e.Save(s);}
 }
}
