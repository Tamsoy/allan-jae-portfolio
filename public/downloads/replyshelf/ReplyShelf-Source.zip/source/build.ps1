$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$framework = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319'
$compiler = Join-Path $framework 'csc.exe'
$buildDir = Join-Path $projectRoot 'build'
New-Item -ItemType Directory -Force $buildDir | Out-Null
$refs = @('System.dll','System.Core.dll','System.Data.dll','System.Xml.dll','System.Web.Extensions.dll','System.Xaml.dll') | ForEach-Object { '/r:' + (Join-Path $framework $_) }
$refs += @('PresentationCore.dll','PresentationFramework.dll','WindowsBase.dll','UIAutomationProvider.dll','UIAutomationTypes.dll') | ForEach-Object { '/r:' + (Join-Path $framework "WPF/$_") }
$sources = @('Core.cs','Files.cs','App.cs','Tests.cs','UiAudit.cs','ContrastAudit.cs','Version.cs') | ForEach-Object { Join-Path $projectRoot "src/$_" }
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /warnaserror+ /utf8output "/out:$buildDir/ReplyShelf.exe" "/win32manifest:$projectRoot/src/app.manifest" "/win32icon:$projectRoot/src/ReplyShelf.ico" "/resource:$projectRoot/src/Main.xaml,Main.xaml" "/resource:$projectRoot/src/ReplyShelf.ico,app.ico" @refs @sources
if ($LASTEXITCODE -ne 0) { throw 'App compilation failed' }
Copy-Item -LiteralPath (Join-Path $projectRoot 'src/ReplyShelf.exe.config'),(Join-Path $projectRoot 'README.md'),(Join-Path $projectRoot 'LICENSE.txt') -Destination $buildDir
$resources = @()
foreach ($name in @('ReplyShelf.exe','ReplyShelf.exe.config','README.md','LICENSE.txt')) {
    $inputStream = [IO.File]::OpenRead((Join-Path $buildDir $name))
    $outputStream = [IO.File]::Create((Join-Path $buildDir "$name.gz"))
    $gzip = New-Object IO.Compression.GZipStream($outputStream, [IO.Compression.CompressionMode]::Compress)
    try { $inputStream.CopyTo($gzip) } finally { $gzip.Dispose(); $outputStream.Dispose(); $inputStream.Dispose() }
    $resources += "/resource:$buildDir/$name.gz,$name.gz"
}
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /warnaserror+ "/out:$buildDir/ReplyShelf-Setup.exe" "/win32manifest:$projectRoot/src/app.manifest" "/win32icon:$projectRoot/src/ReplyShelf.ico" /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:Microsoft.CSharp.dll @resources (Join-Path $projectRoot 'src/Setup.cs') (Join-Path $projectRoot 'src/Version.cs')
if ($LASTEXITCODE -ne 0) { throw 'Installer compilation failed' }
Write-Output "Built ReplyShelf app and installer in $buildDir"

