# ReplyShelf — side quest project

ReplyShelf is an offline Windows response library for virtual assistants, customer support, and IT help desks. It makes repeated communication faster without sending client content to a server: search reusable replies, filter favorites, replace plain-text placeholders, copy a prepared message, and export a portable JSON library.

Built by Allan Jae Eparwa with AI assistance using C#, WPF, and .NET Framework 4.8. It demonstrates local-first product design, accessible desktop UI, safe text templating, JSON validation, clipboard workflows, installer packaging, and regression testing.

Suggested card: “A private response shelf for support and VA workflows. Find the right reply, fill in the details, and copy a ready-to-send message in seconds.”

Suggested v0 prompt: Add ReplyShelf to my portfolio’s “Side Quests” section. Match the existing visual system and keep the card responsive and keyboard accessible. Describe it as an offline Windows C# WPF app for reusable support/VA replies with search, categories, favorites, plain-text variables, clipboard copy, and JSON import/export. Mention that it has no account, API key, cloud sync, or email sending. Include buttons for installer, portable ZIP, source ZIP, development flow, and audit report only when I provide public URLs; never invent links or expose local C: paths. Do not claim mobile, web, team permissions, help-desk integrations, or zero bugs.
