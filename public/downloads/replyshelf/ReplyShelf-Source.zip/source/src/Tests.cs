using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
namespace ReplyShelf {
 public sealed class AuditLog {public List<string> Lines=new List<string>();public int Passed,Failed;public void Check(string n,bool ok){if(ok){Passed++;Lines.Add("PASS: "+n);}else{Failed++;Lines.Add("FAIL: "+n);}}public void Test(string n,Action a){try{a();Check(n,true);}catch(Exception e){Failed++;Lines.Add("FAIL: "+n+" — "+e.GetType().Name+": "+e.Message);}}public void Finish(string p){Lines.Add("RESULT: "+Passed+" passed; "+Failed+" failed.");File.WriteAllLines(p,Lines);}}
 public static class Tests {
  static void Need(bool b){if(!b)throw new Exception("Assertion failed");}static void Reject<T>(Action a)where T:Exception{try{a();}catch(T){return;}throw new Exception("Expected "+typeof(T).Name);}
  public static int Run(string dir){dir=Path.GetFullPath(dir);Directory.CreateDirectory(dir);var l=new AuditLog();
   l.Test("sample is useful",()=>{var x=LibraryRules.Sample();Need(x.Count==4&&x[0].Variables.Count==2&&x.Any(r=>r.Favorite));});
   l.Test("required title and body",()=>{var r=LibraryRules.Sample()[0];r.Title=" ";Need(LibraryRules.Validate(r)=="Add a title.");r.Title="x";r.Body="";Need(LibraryRules.Validate(r)=="Add response text.");});
   l.Test("bounds",()=>{var r=LibraryRules.Sample()[0];r.Body=new string('x',LibraryRules.MaxBody+1);Need(LibraryRules.Validate(r).Contains("32,768"));});
   l.Test("variable extraction",()=>Need(LibraryRules.Extract("Hi {{name}} {{agent}} {{name}} {{bad value}}").SequenceEqual(new[]{"name","agent"})));l.Test("variable render",()=>{var r=LibraryRules.Sample()[0];r.Variables[0].Value="Ada";r.Variables[1].Value="Lee";Need(LibraryRules.Render(r).Contains("Ada")&&LibraryRules.Render(r).Contains("Lee"));});
   l.Test("unknown placeholder retained",()=>Need(LibraryRules.Render(new ResponseItem{Body="{{unknown}}"}).Contains("{{unknown}}")));
   var all=LibraryRules.Sample();l.Test("search title",()=>Need(Library.Filter(all,"meeting","All",false,CancellationToken.None).Count==1));l.Test("search body",()=>Need(Library.Filter(all,"ticket","All",false,CancellationToken.None).Count==1));l.Test("category filter",()=>Need(Library.Filter(all,"","Customer Care",false,CancellationToken.None).Count==2));l.Test("favorites filter",()=>Need(Library.Filter(all,"","All",true,CancellationToken.None).Count==1));l.Test("no results",()=>Need(Library.Filter(all,"not-a-match","All",false,CancellationToken.None).Count==0));l.Test("case insensitive",()=>Need(Library.Filter(all,"WELCOME","All",false,CancellationToken.None).Count==1));
   l.Test("clone deep copy",()=>{var r=all[0].Clone();r.Variables[0].Value="x";Need(all[0].Variables[0].Value!="x");});
   l.Test("json export import",()=>{var p=Path.Combine(dir,"library.json");Files.Save(p,all,CancellationToken.None);var copy=Files.Load(p,CancellationToken.None);Need(copy.Count==4&&copy[0].Title==all[0].Title);});
   l.Test("json BOM",()=>{var p=Path.Combine(dir,"library.json");Need(File.ReadAllBytes(p).Length>2&&File.ReadAllBytes(p)[0]==239);});
   l.Test("invalid json",()=>{var p=Path.Combine(dir,"bad.json");File.WriteAllText(p,"{bad");Reject<InvalidDataException>(()=>Files.Load(p,CancellationToken.None));});
   l.Test("duplicate IDs rejected",()=>{var p=Path.Combine(dir,"dup.json");var a=all.Select(x=>x.Clone()).ToList();a[1].Id=a[0].Id;File.WriteAllText(p,new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(a));Reject<InvalidDataException>(()=>Files.Load(p,CancellationToken.None));});
   l.Test("source remains after failed import",()=>{var p=Path.Combine(dir,"bad.json");Reject<InvalidDataException>(()=>Files.Load(p,CancellationToken.None));Need(all.Count==4);});
   l.Test("cancelled search",()=>{var c=new CancellationTokenSource();c.Cancel();Reject<OperationCanceledException>(()=>Library.Filter(all,"","All",false,c.Token));});
   l.Test("cancelled export",()=>{var c=new CancellationTokenSource();c.Cancel();Reject<OperationCanceledException>(()=>Files.Save(Path.Combine(dir,"cancel.json"),all,c.Token));});
   l.Test("bad export extension",()=>Reject<IOException>(()=>Files.Save(Path.Combine(dir,"library.txt"),all,CancellationToken.None)));
   l.Test("network rejected",()=>Reject<IOException>(()=>Files.Load(@"\\server\share\x.json",CancellationToken.None)));
   l.Test("alternate stream rejected",()=>Reject<IOException>(()=>Files.Load(Path.Combine(dir,"library.json:secret"),CancellationToken.None)));
   var many=Enumerable.Range(0,LibraryRules.MaxResponses+1).Select(i=>new ResponseItem{Id=Guid.NewGuid().ToString("N"),Title="x",Body="x"}).ToList();l.Test("response count limit",()=>Reject<InvalidDataException>(()=>Files.Validate(many)));
   for(int i=0;i<35;i++)l.Test("round trip "+i,()=>{var p=Path.Combine(dir,"round"+i+".json");var a=LibraryRules.Sample();a[0].Body="line "+i+"\r\nquoted \"text\"";Files.Save(p,a,CancellationToken.None);Need(Files.Load(p,CancellationToken.None)[0].Body==a[0].Body);});
   l.Finish(Path.Combine(dir,"test-results.txt"));return l.Failed==0?0:1;}
 }
}

