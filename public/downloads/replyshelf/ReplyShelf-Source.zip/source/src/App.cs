using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace ReplyShelf {
 public static class Program {
  [STAThread] public static int Main(string[] args) {
   try {
    if(args.Length==2&&args[0]=="--self-test") return Tests.Run(args[1]);
    if(args.Length==2&&args[0]=="--ui-audit") return UiAudit.Run(args[1]);
    if(args.Length!=0) return 2;
    return new Application{ShutdownMode=ShutdownMode.OnMainWindowClose}.Run(new Workspace().Window);
   } catch(Exception e) {
    if(args.Length>0){Console.Error.WriteLine(e);return 1;}
    MessageBox.Show("ReplyShelf could not start. "+e.Message,"ReplyShelf",MessageBoxButton.OK,MessageBoxImage.Error);return 1;
   }
  }
 }
 public sealed class Workspace {
  public Window Window;
  public List<ResponseItem> Items=new List<ResponseItem>();
  public ResponseItem Selected;
  public Task CurrentOperation=Task.FromResult(true);
  CancellationTokenSource cancel;
  TaskCompletionSource<bool> finished;
  bool updating,closing,darkTheme=true;
  public bool Busy{get{return cancel!=null;}}
  public T Get<T>(string n) where T:class{return Window.FindName(n) as T;}
  public Workspace() {
   using(var s=System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Main.xaml")) Window=(Window)XamlReader.Load(s);
   using(var icon=System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("app.ico"))if(icon!=null)Window.Icon=BitmapFrame.Create(icon,BitmapCreateOptions.PreservePixelFormat,BitmapCacheOption.OnLoad);
   ApplyTheme(darkTheme);
   Window.Width=Math.Min(Window.Width,SystemParameters.WorkArea.Width);Window.Height=Math.Min(Window.Height,SystemParameters.WorkArea.Height);
   SystemParameters.StaticPropertyChanged+=OnSystemChanged;
   Get<Button>("ThemeButton").Click+=delegate{darkTheme=!darkTheme;ApplyTheme(darkTheme);AnimateTheme();};
   Get<Button>("LoadSampleButton").Click+=delegate{LoadSampleAction();};
   Get<Button>("NewButton").Click+=delegate{NewItem();};
   Get<Button>("SaveButton").Click+=delegate{SaveItem();};
   Get<Button>("DuplicateButton").Click+=delegate{DuplicateItem();};
   Get<Button>("DeleteButton").Click+=delegate{DeleteItem();};
   Get<Button>("FavoriteButton").Click+=delegate{ToggleFavorite();};
   Get<Button>("CopyButton").Click+=delegate{CopyRendered();};
   Get<Button>("ExportButton").Click+=delegate{Export(false);};
   Get<Button>("ImportButton").Click+=delegate{Import();};
   Get<Button>("CancelButton").Click+=delegate{if(cancel!=null)cancel.Cancel();};
   Get<TextBox>("SearchInput").TextChanged+=delegate{RefreshFilter();};
   Get<ComboBox>("CategoryInput").SelectionChanged+=delegate{RefreshFilter();};
   Get<CheckBox>("FavoritesInput").Checked+=delegate{RefreshFilter();};
   Get<CheckBox>("FavoritesInput").Unchecked+=delegate{RefreshFilter();};
   Get<ListBox>("ShelfList").SelectionChanged+=delegate{if(!updating&&Get<ListBox>("ShelfList").SelectedItem is ResponseItem)Select((ResponseItem)Get<ListBox>("ShelfList").SelectedItem);};
   Window.Closing+=async delegate(object s,System.ComponentModel.CancelEventArgs e){if(Busy){e.Cancel=true;if(closing)return;closing=true;cancel.Cancel();await finished.Task;closing=false;Window.Close();}};
   Window.Closed+=delegate{SystemParameters.StaticPropertyChanged-=OnSystemChanged;};
   UpdateButtons();
  }
  void OnSystemChanged(object sender,System.ComponentModel.PropertyChangedEventArgs e){if(e.PropertyName=="HighContrast")Window.Dispatcher.BeginInvoke(new Action(delegate{ApplyTheme(darkTheme);}));}
  void ApplyTheme(bool dark){
   string[] keys={"Canvas","Surface","Glass","Ink","Muted","Primary","Accent","OnPrimary","Line","Tint","Glow","Danger"};
   string[] colors=dark?new[]{"#0B2735","#E61B3E46","#D9163945","#F4FFFD","#B8D2D0","#2DD4BF","#FB923C","#062B31","#4B8586","#123D49","#2DD4BF","#FB8D83"}:new[]{"#F3FAF9","#F2FFFFFF","#E6FFFFFF","#12343D","#52717A","#0F8F86","#D95F16","#FFFFFF","#A8C7C5","#E3F1EF","#34BFA6","#B43F36"};
   Brush[] high={SystemColors.WindowBrush,SystemColors.WindowBrush,SystemColors.WindowBrush,SystemColors.WindowTextBrush,SystemColors.WindowTextBrush,SystemColors.HighlightBrush,SystemColors.HighlightBrush,SystemColors.HighlightTextBrush,SystemColors.WindowTextBrush,SystemColors.WindowBrush,SystemColors.HighlightBrush,SystemColors.WindowTextBrush};
   for(int i=0;i<keys.Length;i++)Window.Resources[keys[i]]=SystemParameters.HighContrast?high[i]:(Brush)new BrushConverter().ConvertFromString(colors[i]);
   var sun=Get<FrameworkElement>("ThemeSun");var moon=Get<FrameworkElement>("ThemeMoon");if(sun!=null)sun.Visibility=dark?Visibility.Visible:Visibility.Collapsed;if(moon!=null)moon.Visibility=dark?Visibility.Collapsed:Visibility.Visible;
   var toggle=Get<Button>("ThemeButton");if(toggle!=null){toggle.ToolTip=dark?"Switch to light mode":"Switch to dark mode";AutomationProperties.SetName(toggle,dark?"Switch to light mode":"Switch to dark mode");}
  }
  void AnimateTheme(){var flash=Get<Border>("ThemeFlash");if(flash==null)return;flash.BeginAnimation(UIElement.OpacityProperty,null);flash.Opacity=.2;flash.BeginAnimation(UIElement.OpacityProperty,new DoubleAnimation(.2,0,TimeSpan.FromMilliseconds(360)){EasingFunction=new CubicEase{EasingMode=EasingMode.EaseOut}});}
  void Begin(string s){cancel=new CancellationTokenSource();finished=new TaskCompletionSource<bool>();SetStatus(s);UpdateButtons();}
  void End(){cancel.Dispose();cancel=null;finished.TrySetResult(true);UpdateButtons();}
  void SetStatus(string s){Get<TextBlock>("Status").Text=s;}
  void UpdateButtons(){
   foreach(string n in new[]{"LoadSampleButton","ImportButton","ExportButton"})Get<Button>(n).IsEnabled=!Busy;
   Get<Button>("NewButton").IsEnabled=!Busy;Get<StackPanel>("EditorPanel").IsEnabled=!Busy&&Selected!=null;
   foreach(string n in new[]{"CopyButton","SaveButton","DeleteButton","DuplicateButton","FavoriteButton"})Get<Button>(n).IsEnabled=!Busy&&Selected!=null;
   Get<TextBox>("SearchInput").IsEnabled=!Busy;Get<ComboBox>("CategoryInput").IsEnabled=!Busy;Get<CheckBox>("FavoritesInput").IsEnabled=!Busy;Get<Button>("CancelButton").Visibility=Busy?Visibility.Visible:Visibility.Collapsed;
   var progress=Get<ProgressBar>("BusyProgress");if(progress!=null)progress.Visibility=Busy?Visibility.Visible:Visibility.Collapsed;
   var pulse=Get<Border>("BusyPulse");if(pulse!=null){pulse.BeginAnimation(UIElement.OpacityProperty,null);pulse.Opacity=Busy ? .42 : 0;if(Busy)pulse.BeginAnimation(UIElement.OpacityProperty,new DoubleAnimation(.15,.8,TimeSpan.FromMilliseconds(900)){AutoReverse=true,RepeatBehavior=RepeatBehavior.Forever});}
   Get<TextBlock>("CountText").Text=Items.Count+" saved responses · "+Get<ListBox>("ShelfList").Items.Count+" shown";
  }
  public void LoadSampleAction(){CurrentOperation=LoadSample();}
  public async Task LoadSample(){if(Busy)return;Begin("Loading fictional sample responses…");try{var list=await Task.Run(()=>LibraryRules.Sample(),cancel.Token);cancel.Token.ThrowIfCancellationRequested();Items=list;RefreshCategories();Select(Items[0]);SetStatus("Sample library loaded. Responses stay in memory until you export.");}catch(OperationCanceledException){SetStatus("Load cancelled.");}finally{End();}}
  public void RefreshCategories(){updating=true;var cats=new[]{"All"}.Concat(Items.Select(x=>x.Category??"").Where(x=>x.Length>0).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x=>x)).ToList();Get<ComboBox>("CategoryInput").ItemsSource=cats;Get<ComboBox>("CategoryInput").SelectedIndex=0;updating=false;RefreshFilter();}
  public void RefreshFilter(){if(updating)return;var q=Get<TextBox>("SearchInput").Text;var cat=Convert.ToString(Get<ComboBox>("CategoryInput").SelectedItem);var result=Library.Filter(Items,q,cat,Get<CheckBox>("FavoritesInput").IsChecked==true,CancellationToken.None);updating=true;Get<ListBox>("ShelfList").ItemsSource=result;updating=false;UpdateButtons();}
  public void Select(ResponseItem r){Selected=r;updating=true;Get<TextBox>("TitleInput").Text=r.Title??"";Get<TextBox>("CategoryEdit").Text=r.Category??"";Get<TextBox>("ShortcutEdit").Text=r.Shortcut??"";Get<TextBox>("BodyInput").Text=r.Body??"";Get<ListBox>("VariablesList").ItemsSource=(r.Variables??new List<Variable>()).Select(v=>new Variable{Name=v.Name,Value=v.Value}).ToList();Get<TextBlock>("EditorTitle").Text=r.Title;Get<TextBlock>("PreviewText").Text=LibraryRules.Render(r);Get<TextBlock>("EditedText").Text="Edited "+r.EditedUtc.ToLocalTime().ToString("g");Get<Button>("FavoriteButton").Content=r.Favorite?"Unfavorite":"Favorite";updating=false;UpdateButtons();}
  public void NewItem(){var r=new ResponseItem{Id=Guid.NewGuid().ToString("N"),Title="",Category="General",Shortcut="",Body="",Variables=new List<Variable>(),EditedUtc=DateTime.UtcNow};Items.Insert(0,r);RefreshCategories();Select(r);Get<TextBox>("TitleInput").Focus();SetStatus("New draft. Add a title and response text, then save.");}
  ResponseItem ReadEditor(){var r=Selected.Clone();r.Title=Get<TextBox>("TitleInput").Text.Trim();r.Category=Get<TextBox>("CategoryEdit").Text.Trim();r.Shortcut=Get<TextBox>("ShortcutEdit").Text.Trim();r.Body=Get<TextBox>("BodyInput").Text;var vars=Get<ListBox>("VariablesList").Items.Cast<Variable>().Select(v=>new Variable{Name=v.Name,Value=v.Value}).ToList();r.Variables=vars;return r;}
  public void SaveItem(){if(Selected==null)return;var r=ReadEditor();var e=LibraryRules.Validate(r);if(e!=null){SetStatus("Cannot save: "+e);return;}r.EditedUtc=DateTime.UtcNow;int i=Items.FindIndex(x=>x.Id==Selected.Id);if(i<0){SetStatus("This draft no longer exists.");return;}Items[i]=r;Selected=r;RefreshCategories();Select(r);SetStatus("Response saved in memory. Export the library to keep a backup.");}
  public void DuplicateItem(){if(Selected==null)return;var r=Selected.Clone();r.Id=Guid.NewGuid().ToString("N");r.Title=(r.Title??"")+" copy";r.Favorite=false;r.EditedUtc=DateTime.UtcNow;Items.Insert(0,r);RefreshCategories();Select(r);SetStatus("Response duplicated. Edit it, then save.");}
  public void DeleteItem(){if(Selected==null)return;if(MessageBox.Show(Window,"Delete ‘"+Selected.Title+"’? This removes it from the current library.","Delete response",MessageBoxButton.YesNo,MessageBoxImage.Warning,MessageBoxResult.No)!=MessageBoxResult.Yes)return;Items.RemoveAll(x=>x.Id==Selected.Id);Selected=null;RefreshCategories();ClearEditor();SetStatus("Response deleted from the current library.");}
  void ClearEditor(){updating=true;foreach(string n in new[]{"TitleInput","CategoryEdit","ShortcutEdit","BodyInput"})Get<TextBox>(n).Text="";Get<ListBox>("VariablesList").ItemsSource=null;Get<TextBlock>("EditorTitle").Text="Select a response";Get<TextBlock>("PreviewText").Text="";updating=false;UpdateButtons();}
  public void ToggleFavorite(){if(Selected==null)return;Selected.Favorite=!Selected.Favorite;Selected.EditedUtc=DateTime.UtcNow;Select(Selected);RefreshFilter();SetStatus(Selected.Favorite?"Added to favorites.":"Removed from favorites.");}
  public void CopyRendered(){if(Selected==null)return;try{Clipboard.SetText(LibraryRules.Render(ReadEditor()));SetStatus("Prepared response copied to the clipboard.");AnimateCopy();}catch(Exception e){SetStatus("Clipboard unavailable: "+e.Message);}}
  void AnimateCopy(){var flash=Get<Border>("CopyFlash");if(flash==null)return;flash.BeginAnimation(UIElement.OpacityProperty,null);flash.Opacity=.25;flash.BeginAnimation(UIElement.OpacityProperty,new DoubleAnimation(.25,0,TimeSpan.FromMilliseconds(300)));}
  public void Export(bool unused){var d=new SaveFileDialog{Title="Export ReplyShelf library",Filter="JSON library (*.json)|*.json",DefaultExt=".json",FileName="ReplyShelf-library.json",OverwritePrompt=true};if(d.ShowDialog(Window)==true)CurrentOperation=ExportPath(d.FileName);}
  public async Task ExportPath(string path){if(Busy)return;Begin("Exporting library…");try{await Task.Run(()=>Files.Save(path,Items,cancel.Token));SetStatus("Library exported to "+path);}catch(OperationCanceledException){SetStatus("Export cancelled; destination was not committed.");}catch(Exception e){SetStatus("Export failed: "+e.Message);}finally{End();}}
  public void Import(){var d=new OpenFileDialog{Title="Import ReplyShelf library",Filter="JSON library (*.json)|*.json",CheckFileExists=true};if(d.ShowDialog(Window)==true)CurrentOperation=ImportPath(d.FileName);}
  public async Task ImportPath(string path){if(Busy)return;Begin("Validating library before import…");try{var list=await Task.Run(()=>Files.Load(path,cancel.Token));Items=list;Selected=null;RefreshCategories();ClearEditor();SetStatus("Library imported after complete validation.");}catch(OperationCanceledException){SetStatus("Import cancelled; the previous library is unchanged.");}catch(Exception e){SetStatus("Import failed; the previous library is unchanged: "+e.Message);}finally{End();}}
 }
}
