using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
namespace ReplyShelf {
 public sealed class Variable { public string Name{get;set;} public string Value{get;set;} }
 public sealed class ResponseItem { public string Id{get;set;} public string Title{get;set;} public string Category{get;set;} public string Shortcut{get;set;} public string Body{get;set;} public List<Variable> Variables{get;set;} public bool Favorite{get;set;} public DateTime EditedUtc{get;set;} public ResponseItem Clone(){return new ResponseItem{Id=Id,Title=Title,Category=Category,Shortcut=Shortcut,Body=Body,Favorite=Favorite,EditedUtc=EditedUtc,Variables=(Variables??new List<Variable>()).Select(v=>new Variable{Name=v.Name,Value=v.Value}).ToList()};} }
 public static class LibraryRules {
  public const int MaxResponses=500,MaxVariables=20,MaxBody=32768,MaxShort=160,MaxFile=10*1024*1024;
  static readonly Regex VariableName=new Regex("^[A-Za-z0-9_-]{1,40}$",RegexOptions.CultureInvariant);
  public static string Validate(ResponseItem r){if(r==null)return "Choose a response.";if(String.IsNullOrWhiteSpace(r.Title))return "Add a title.";if(r.Title.Trim().Length>MaxShort)return "Title is limited to 160 characters.";if((r.Category??"").Trim().Length>MaxShort)return "Category is limited to 160 characters.";if((r.Shortcut??"").Trim().Length>MaxShort)return "Shortcut is limited to 160 characters.";if(String.IsNullOrEmpty(r.Body))return "Add response text.";if(r.Body.Length>MaxBody)return "Response text is limited to 32,768 characters.";if((r.Variables??new List<Variable>()).Count>MaxVariables)return "A response can have at most 20 variables.";var names=new HashSet<string>(StringComparer.OrdinalIgnoreCase);foreach(var v in r.Variables??new List<Variable>()){if(v==null||!VariableName.IsMatch(v.Name??""))return "Variable names use letters, numbers, hyphens, or underscores.";if(!names.Add(v.Name))return "Variable names must be unique.";if((v.Value??"").Length>MaxBody)return "Variable values are too long.";}return null;}
  public static List<string> Extract(string body){var result=new List<string>();if(body==null)return result;foreach(Match m in Regex.Matches(body,"\\{\\{([A-Za-z0-9_-]{1,40})\\}\\}")){if(!result.Contains(m.Groups[1].Value,StringComparer.OrdinalIgnoreCase))result.Add(m.Groups[1].Value);}return result;}
  public static string Render(ResponseItem r){var body=r.Body??"";foreach(var v in r.Variables??new List<Variable>()){string token="{{"+v.Name+"}}";body=Regex.Replace(body,Regex.Escape(token),new MatchEvaluator(delegate(Match m){return v.Value??"";}),RegexOptions.IgnoreCase);}return body;}
  public static List<ResponseItem> Sample(){return new List<ResponseItem>{Item("Welcome reply","Customer Care","welcome","Hi {{name}},\r\n\r\nThanks for reaching out. I’ve received your message and will review it shortly.\r\n\r\nBest,\r\n{{agent}}",new[]{"name","agent"}),Item("Follow-up request","Customer Care","followup","Hi {{name}},\r\n\r\nCould you share your {{detail}} so I can move this forward?\r\n\r\nThank you,\r\n{{agent}}",new[]{"name","detail","agent"}),Item("Meeting confirmation","Operations","meeting","Hello {{name}},\r\n\r\nYour meeting is confirmed for {{date}} at {{time}}.\r\n\r\nI’ll send the link before the call.",new[]{"name","date","time"}),Item("Ticket handoff","IT Support","handoff","Hi {{name}},\r\n\r\nI’m handing ticket {{ticket}} to {{team}} for the next step. We’ll update you by {{date}}.",new[]{"name","ticket","team","date"})};}
  static ResponseItem Item(string title,string category,string shortcut,string body,string[] names){return new ResponseItem{Id=Guid.NewGuid().ToString("N"),Title=title,Category=category,Shortcut=shortcut,Body=body,Favorite=title=="Welcome reply",EditedUtc=DateTime.UtcNow,Variables=names.Select(n=>new Variable{Name=n,Value=""}).ToList()};}
 }
 public static class Library {
  public static List<ResponseItem> Filter(IEnumerable<ResponseItem> all,string query,string category,bool favorites,CancellationToken token){var q=(query??"").Trim();var result=new List<ResponseItem>();foreach(var r in all??Enumerable.Empty<ResponseItem>()){token.ThrowIfCancellationRequested();if(favorites&&!r.Favorite)continue;if(!String.IsNullOrEmpty(category)&&category!="All"&&!String.Equals(r.Category,category,StringComparison.OrdinalIgnoreCase))continue;string hay=(r.Title+"\n"+r.Category+"\n"+r.Shortcut+"\n"+r.Body+"\n"+String.Join(" ",(r.Variables??new List<Variable>()).Select(v=>v.Name))).ToLowerInvariant();if(q.Length==0||hay.Contains(q.ToLowerInvariant()))result.Add(r);}return result.OrderByDescending(x=>x.Favorite).ThenBy(x=>x.Title,StringComparer.OrdinalIgnoreCase).ToList();}
 }
}



