using System.Reflection;
[assembly: AssemblyTitle("ReplyShelf")]
[assembly: AssemblyDescription("Offline reusable response library for support and VA workflows")]
[assembly: AssemblyCompany("Allan Jae Eparwa")]
[assembly: AssemblyProduct("ReplyShelf")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
