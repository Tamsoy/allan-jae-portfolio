using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace ReplyShelfSetup {
    static class Program {
        static readonly string productDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Programs","ReplyShelf");
        static readonly string maintenanceDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"ReplyShelf","Installer");
        static readonly string registryKey=@"Software\Microsoft\Windows\CurrentVersion\Uninstall\ReplyShelf";
        static readonly string shortcut=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs),"ReplyShelf.lnk");
        static readonly string[] files={"ReplyShelf.exe","ReplyShelf.exe.config","README.md","LICENSE.txt"};
        [STAThread] static int Main(string[] args) {
            if(args.Any(x=>x!="--quiet" && x!="--uninstall")) return 2;
            bool remove=args.Contains("--uninstall");
            Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
            if(args.Contains("--quiet")) { try { if(remove) Uninstall(); else Install(); return 0; } catch(Exception e) { Console.Error.WriteLine(e.Message); return 1; } }
            var form=new Form { Text=remove?"Remove ReplyShelf":"Install ReplyShelf",ClientSize=new Size(560,410),MinimumSize=new Size(500,400),StartPosition=FormStartPosition.CenterScreen,Font=new Font("Segoe UI",10),AutoScaleMode=AutoScaleMode.Dpi,BackColor=Color.White };
            var panel=new TableLayoutPanel { Dock=DockStyle.Fill,Padding=new Padding(24),ColumnCount=1,RowCount=5,AutoScroll=true };
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));panel.RowStyles.Add(new RowStyle(SizeType.Percent,100));panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.Controls.Add(new Label { Text=remove?"Remove ReplyShelf":"Clean data. Clear changes.",Font=new Font("Segoe UI",20,FontStyle.Bold),AutoSize=true,Dock=DockStyle.Fill,Margin=new Padding(0,0,0,18) },0,0);
            panel.Controls.Add(new Label { Text=remove?"Removes application files and the Start menu shortcut. Your CSV files, exports, and unrelated files are kept.":"ReplyShelf 1.0 for Windows 11 x64\nLocal CSV cleanup with previews and change logs.\nInstalls for your account without administrator access.",AutoSize=true,Dock=DockStyle.Fill,Margin=new Padding(0,0,0,16) },0,1);
            panel.Controls.Add(new Label { Text=productDir,AutoSize=true,Dock=DockStyle.Fill,Margin=new Padding(0,0,0,16) },0,2);
            var buttons=new FlowLayoutPanel { AutoSize=true,Dock=DockStyle.Fill,WrapContents=true };
            var action=new Button { Text=remove?"Uninstall":"Install and open",AutoSize=true,Padding=new Padding(12,8,12,8) };
            var cancel=new Button { Text="Cancel",AutoSize=true,Padding=new Padding(12,8,12,8),DialogResult=DialogResult.Cancel };
            buttons.Controls.Add(action);buttons.Controls.Add(cancel);panel.Controls.Add(buttons,0,3);
            var status=new Label { AutoSize=true,Dock=DockStyle.Fill,Margin=new Padding(0,12,0,0) };panel.Controls.Add(status,0,4);
            form.Controls.Add(panel);form.CancelButton=cancel;
            action.Click+=delegate {
                action.Enabled=false; status.Text="Working…"; form.Refresh();
                try { if(remove) { Uninstall(); MessageBox.Show(form,"ReplyShelf was removed. Exported files were kept.","ReplyShelf"); } else { Install(); Process.Start(new ProcessStartInfo(Path.Combine(productDir,"ReplyShelf.exe")) { UseShellExecute=true }); } form.Close(); }
                catch(Exception e) { status.Text="Setup could not finish: "+e.Message; action.Enabled=true; }
            };
            Application.Run(form);return 0;
        }
        static void CheckDirectory(string path) {
            var d=new DirectoryInfo(path);
            while(d!=null) { if(d.Exists && (d.Attributes&FileAttributes.ReparsePoint)!=0) throw new IOException("Setup cannot use a redirected or linked application folder."); d=d.Parent; }
        }
        static void CheckNotRunning() {
            foreach(var p in Process.GetProcessesByName("ReplyShelf")) {
                try { if(String.Equals(p.MainModule.FileName,Path.Combine(productDir,"ReplyShelf.exe"),StringComparison.OrdinalIgnoreCase)) throw new IOException("Close ReplyShelf before installing or removing it."); }
                catch(System.ComponentModel.Win32Exception) { throw new IOException("A ReplyShelf process could not be inspected. Close it before running setup."); }
                finally { p.Dispose(); }
            }
        }
        static void Install() {
            CheckDirectory(productDir);CheckDirectory(maintenanceDir);CheckNotRunning();
            using(var key=Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full")) if(key==null || Convert.ToInt32(key.GetValue("Release",0))<528040) throw new IOException("Install Microsoft .NET Framework 4.8 or newer first.");
            byte[] oldShortcut=File.Exists(shortcut)?File.ReadAllBytes(shortcut):null;
            var oldValues=new System.Collections.Generic.Dictionary<string,object>();var oldKinds=new System.Collections.Generic.Dictionary<string,RegistryValueKind>();bool hadRegistry;
            using(var prior=Registry.CurrentUser.OpenSubKey(registryKey)){hadRegistry=prior!=null;if(prior!=null)foreach(var name in prior.GetValueNames()){oldValues[name]=prior.GetValue(name,null,RegistryValueOptions.DoNotExpandEnvironmentNames);oldKinds[name]=prior.GetValueKind(name);}}
            Directory.CreateDirectory(productDir);
            string stage=Path.Combine(productDir,".install-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(stage);
            var changed=new System.Collections.Generic.List<string>();
            bool retainStage=false;
            try {
                foreach(string name in files) using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream(name+".gz")) using(var gzip=new GZipStream(s,CompressionMode.Decompress)) using(var dst=File.Create(Path.Combine(stage,name))) gzip.CopyTo(dst);
                foreach(string name in files) {
                    string dest=Path.Combine(productDir,name);
                    if(File.Exists(dest)) File.Copy(dest,Path.Combine(stage,name+".backup"));
                    if(File.Exists(dest)) File.Replace(Path.Combine(stage,name),dest,null); else File.Move(Path.Combine(stage,name),dest);
                    changed.Add(name);
                }
                Directory.CreateDirectory(maintenanceDir);
                string maintenance=Path.Combine(maintenanceDir,"ReplyShelf-Setup.exe");
                if(!String.Equals(Assembly.GetExecutingAssembly().Location,maintenance,StringComparison.OrdinalIgnoreCase)) File.Copy(Assembly.GetExecutingAssembly().Location,maintenance,true);
                object shell=null,link=null;
                try { shell=Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell")); dynamic sh=shell; link=sh.CreateShortcut(shortcut); dynamic l=link; l.TargetPath=Path.Combine(productDir,"ReplyShelf.exe");l.WorkingDirectory=productDir;l.Description="Offline response library";l.Save(); }
                finally { if(link!=null) Marshal.FinalReleaseComObject(link); if(shell!=null) Marshal.FinalReleaseComObject(shell); }
                using(var k=Registry.CurrentUser.CreateSubKey(registryKey)) { k.SetValue("DisplayName","ReplyShelf");k.SetValue("DisplayVersion","1.0.0");k.SetValue("Publisher","Allan Jae Eparwa");k.SetValue("InstallLocation",productDir);k.SetValue("DisplayIcon",Path.Combine(productDir,"ReplyShelf.exe"));k.SetValue("UninstallString","\""+maintenance+"\" --uninstall");k.SetValue("QuietUninstallString","\""+maintenance+"\" --uninstall --quiet");k.SetValue("NoModify",1);k.SetValue("NoRepair",1); }
            } catch {
                try { foreach(string name in changed) { string backup=Path.Combine(stage,name+".backup"),dest=Path.Combine(productDir,name); if(File.Exists(backup)) File.Copy(backup,dest,true);else if(File.Exists(dest)) File.Delete(dest); }
                    if(oldShortcut!=null)File.WriteAllBytes(shortcut,oldShortcut);else if(File.Exists(shortcut))File.Delete(shortcut);
                    if(hadRegistry)using(var prior=Registry.CurrentUser.CreateSubKey(registryKey)){foreach(var name in prior.GetValueNames())if(!oldValues.ContainsKey(name))prior.DeleteValue(name,false);foreach(var pair in oldValues)prior.SetValue(pair.Key,pair.Value,oldKinds[pair.Key]);}
                    else Registry.CurrentUser.DeleteSubKeyTree(registryKey,false);
                }
                catch { retainStage=true; throw new IOException("Setup could not restore every previous file. Recovery copies are kept at "+stage+". Close ReplyShelf and rerun setup."); }
                throw;
            } finally {
                if(!retainStage) {
                    foreach(string name in files) foreach(string suffix in new[]{"",".backup"}) { string path=Path.Combine(stage,name+suffix); if(File.Exists(path)) File.Delete(path); }
                    if(!Directory.EnumerateFileSystemEntries(stage).Any()) Directory.Delete(stage);
                }
            }
        }
        static void Uninstall() {
            CheckDirectory(productDir);CheckNotRunning();
            foreach(string name in files) { string p=Path.Combine(productDir,name);if(File.Exists(p)) File.Delete(p); }
            if(Directory.Exists(productDir) && !Directory.EnumerateFileSystemEntries(productDir).Any()) Directory.Delete(productDir);
            if(File.Exists(shortcut)) File.Delete(shortcut);
            Registry.CurrentUser.DeleteSubKeyTree(registryKey,false);
            // The small cached maintenance executable is retained because it may be running.
        }
    }
}


